// AutoAlerta - Detalle del auto (5 secciones)
import { useMemo, useState } from 'react';
import {
  ScrollView,
  StyleSheet,
  View,
  Image,
  Alert,
  Pressable,
} from 'react-native';
import {
  Text,
  Button,
  SegmentedButtons,
  IconButton,
  Portal,
  Modal,
  FAB,
} from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useApp, useAuto } from '@/hooks/AppContext';
import {
  actualizarAuto,
  eliminarAuto,
  agregarMantenimiento,
  actualizarMantenimiento,
  eliminarMantenimiento,
  agregarCambioPieza,
  eliminarCambioPieza,
  nuevoId,
} from '@/services/mutations';
import { calcularAlertasAuto } from '@/services/alertEngine';
import { DocumentCard } from '@/components/DocumentCard';
import { TextField, NumberField, DateField, SelectField } from '@/components/Form';
import { FotoCapture } from '@/components/FotoCapture';
import { EmptyState } from '@/components/EmptyState';
import { MESES_CALCOMANIA, VIGENCIAS_PANAMA } from '@/constants/leyes-panama';
import { TIPOS_MANTENIMIENTO } from '@/constants/mantenimientos';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';
import { addMonths, format, parseISO, isValid } from 'date-fns';
import type {
  Auto,
  Mantenimiento,
  CambioPieza,
  PolizaSeguro,
  Calcomania,
  RevisadoVehicular,
  PlacaMetalica,
  RegistroUnico,
} from '@/types';

type SeccionId = 'info' | 'docs' | 'mant' | 'piezas' | 'reportes';

export default function DetalleAuto() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { setDatos, datos } = useApp();
  const auto = useAuto(id);
  const [seccion, setSeccion] = useState<SeccionId>('info');

  const alertas = useMemo(() => (auto ? calcularAlertasAuto(auto) : []), [auto]);

  if (!auto) {
    return (
      <View style={styles.center}>
        <EmptyState
          icono="car-off"
          titulo="Auto no encontrado"
          ctaLabel="Volver"
          onCta={() => router.back()}
        />
      </View>
    );
  }

  const titulo = `${auto.marca} ${auto.modelo}`.trim() || 'Auto';
  const choferes = datos?.choferes.filter((c) => auto.choferesIds.includes(c.id)) ?? [];

  const onEliminar = () => {
    Alert.alert(
      'Eliminar auto',
      `Esto eliminara ${titulo} y todos sus mantenimientos. ?Continuar?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Eliminar',
          style: 'destructive',
          onPress: async () => {
            await setDatos((d) => eliminarAuto(d, auto.id));
            router.replace('/(tabs)/autos');
          },
        },
      ],
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: PALETA.background }}>
      <Stack.Screen
        options={{
          title: titulo,
          headerRight: () => (
            <IconButton icon="delete" iconColor={PALETA.error} onPress={onEliminar} />
          ),
        }}
      />

      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Header con foto */}
        <View style={styles.header}>
          {auto.foto?.uri ? (
            <Image source={{ uri: auto.foto.uri }} style={styles.fotoHeader} />
          ) : (
            <View style={[styles.fotoHeader, styles.fotoPlaceholder]}>
              <MaterialCommunityIcons name="car" size={80} color={PALETA.outline} />
            </View>
          )}
          <View style={styles.headerInfo}>
            <Text style={styles.headerTitulo}>{titulo}</Text>
            <Text style={styles.headerSub}>
              {auto.anio} · {auto.color || 'sin color'}
            </Text>
            <Text style={styles.headerPlaca}>
              {auto.placa || 'sin placa'} · {auto.kilometrajeActual.toLocaleString()} km
            </Text>
            {alertas.filter((a) => a.severidad !== 'aldia').length > 0 && (
              <View style={styles.headerAlerta}>
                <MaterialCommunityIcons
                  name="alert"
                  size={14}
                  color={PALETA.semaforo.urgente}
                />
                <Text style={styles.headerAlertaTxt}>
                  {alertas.filter((a) => a.severidad !== 'aldia').length} documento(s)
                  por atender
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Selector de seccion */}
        <SegmentedButtons
          value={seccion}
          onValueChange={(v) => setSeccion(v as SeccionId)}
          density="small"
          style={styles.seg}
          buttons={[
            { value: 'info', label: 'Info', icon: 'information' },
            { value: 'docs', label: 'Docs', icon: 'file-document' },
            { value: 'mant', label: 'Mant.', icon: 'wrench' },
            { value: 'piezas', label: 'Piezas', icon: 'cog' },
            { value: 'reportes', label: 'Gastos', icon: 'chart-bar' },
          ]}
        />

        {/* Contenido */}
        {seccion === 'info' && (
          <SeccionInfo auto={auto} choferesIds={auto.choferesIds} choferes={choferes} />
        )}
        {seccion === 'docs' && <SeccionDocumentos auto={auto} alertas={alertas} />}
        {seccion === 'mant' && <SeccionMantenimientos auto={auto} />}
        {seccion === 'piezas' && <SeccionPiezas auto={auto} />}
        {seccion === 'reportes' && <SeccionReportes auto={auto} />}
      </ScrollView>
    </View>
  );
}

// ============ INFO ============
function SeccionInfo({
  auto,
  choferes,
}: {
  auto: Auto;
  choferesIds: string[];
  choferes: Array<{ id: string; nombre: string; apellido: string }>;
}) {
  const router = useRouter();
  const { setDatos } = useApp();
  const [editando, setEditando] = useState(false);
  const [borrador, setBorrador] = useState(auto);

  const guardar = async () => {
    await setDatos((d) => actualizarAuto(d, auto.id, borrador));
    setEditando(false);
  };

  if (!editando) {
    return (
      <View style={styles.cardCol}>
        <Row label="Marca" value={auto.marca || '-'} />
        <Row label="Modelo" value={auto.modelo || '-'} />
        <Row label="Anio" value={String(auto.anio)} />
        <Row label="Color" value={auto.color || '-'} />
        <Row label="Placa" value={auto.placa || '-'} />
        <Row label="VIN" value={auto.vin || '-'} />
        <Row label="Kilometraje" value={`${auto.kilometrajeActual.toLocaleString()} km`} />
        {auto.notas ? <Row label="Notas" value={auto.notas} /> : null}

        <Text style={styles.subSeccion}>Choferes asignados</Text>
        {choferes.length === 0 ? (
          <Text style={styles.placeholderTxt}>Sin choferes asignados</Text>
        ) : (
          choferes.map((c) => (
            <Pressable
              key={c.id}
              onPress={() => router.push(`/chofer/${c.id}`)}
              style={styles.choferLink}
            >
              <MaterialCommunityIcons
                name="account"
                size={20}
                color={PALETA.primary}
              />
              <Text style={styles.choferLinkTxt}>
                {c.nombre} {c.apellido}
              </Text>
              <MaterialCommunityIcons
                name="chevron-right"
                size={20}
                color={PALETA.outline}
              />
            </Pressable>
          ))
        )}

        <Button
          mode="contained-tonal"
          onPress={() => setEditando(true)}
          icon="pencil"
          style={{ marginTop: ESPACIADO.stackMd }}
        >
          Editar datos
        </Button>
      </View>
    );
  }

  return (
    <View style={styles.cardCol}>
      <FotoCapture
        foto={borrador.foto}
        carpeta="autos"
        prefijo={`auto_${borrador.id}`}
        etiqueta="Foto del vehiculo"
        onChange={(f) => setBorrador((b) => ({ ...b, foto: f }))}
        ratio={16 / 9}
      />
      <TextField
        label="Marca"
        value={borrador.marca}
        onChange={(v) => setBorrador((b) => ({ ...b, marca: v }))}
      />
      <TextField
        label="Modelo"
        value={borrador.modelo}
        onChange={(v) => setBorrador((b) => ({ ...b, modelo: v }))}
      />
      <NumberField
        label="Anio"
        value={borrador.anio}
        onChange={(v) => setBorrador((b) => ({ ...b, anio: v }))}
      />
      <TextField
        label="Color"
        value={borrador.color}
        onChange={(v) => setBorrador((b) => ({ ...b, color: v }))}
      />
      <TextField
        label="Placa"
        value={borrador.placa}
        onChange={(v) => setBorrador((b) => ({ ...b, placa: v.toUpperCase() }))}
      />
      <TextField
        label="VIN"
        value={borrador.vin}
        onChange={(v) => setBorrador((b) => ({ ...b, vin: v.toUpperCase() }))}
      />
      <NumberField
        label="Kilometraje actual"
        value={borrador.kilometrajeActual}
        onChange={(v) => setBorrador((b) => ({ ...b, kilometrajeActual: v }))}
        suffix="km"
      />
      <TextField
        label="Notas"
        value={borrador.notas}
        onChange={(v) => setBorrador((b) => ({ ...b, notas: v }))}
        multiline
      />
      <View style={styles.rowBtns}>
        <Button mode="outlined" onPress={() => { setBorrador(auto); setEditando(false); }}>
          Cancelar
        </Button>
        <Button mode="contained" onPress={guardar}>
          Guardar cambios
        </Button>
      </View>
    </View>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.infoRow}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={styles.infoValue}>{value}</Text>
    </View>
  );
}

// ============ DOCUMENTOS ============
import type { Alerta } from '@/types';

function SeccionDocumentos({ auto, alertas }: { auto: Auto; alertas: Alerta[] }) {
  const [editando, setEditando] = useState<
    | null
    | { tipo: 'registro' }
    | { tipo: 'poliza' }
    | { tipo: 'revisado' }
    | { tipo: 'calcomania' }
    | { tipo: 'placa' }
  >(null);

  const sevPara = (tipo: string) => {
    const a = alertas.find((x) => x.tipo === tipo);
    return a?.severidad ?? 'aldia';
  };
  const diasPara = (tipo: string) => {
    const a = alertas.find((x) => x.tipo === tipo);
    return a?.diasRestantes;
  };

  return (
    <View style={styles.cardCol}>
      <DocumentCard
        icono="card-account-details"
        titulo="Registro unico vehicular"
        detalle={auto.registroUnico?.numero || 'No registrado'}
        fechaVencimiento={auto.registroUnico?.fechaEmision}
        severidad={auto.registroUnico ? 'aldia' : 'vencido'}
        onPress={() => setEditando({ tipo: 'registro' })}
      />
      <DocumentCard
        icono="shield-check"
        titulo="Poliza de seguro"
        detalle={auto.polizaSeguro?.aseguradora || 'No registrada'}
        fechaVencimiento={auto.polizaSeguro?.fechaVencimiento}
        diasRestantes={diasPara('poliza')}
        severidad={sevPara('poliza')}
        onPress={() => setEditando({ tipo: 'poliza' })}
      />
      <DocumentCard
        icono="clipboard-check"
        titulo="Revisado vehicular"
        detalle={
          auto.revisadoVehicular?.taller ||
          (auto.revisadoVehicular ? 'Registrado' : 'No registrado')
        }
        fechaVencimiento={auto.revisadoVehicular?.fechaProximoRevisado}
        diasRestantes={diasPara('revisado')}
        severidad={sevPara('revisado')}
        onPress={() => setEditando({ tipo: 'revisado' })}
      />
      <DocumentCard
        icono="sticker-check"
        titulo="Calcomania"
        detalle={auto.calcomania ? `Mes: ${auto.calcomania.mes}` : 'No registrada'}
        fechaVencimiento={auto.calcomania?.fechaVencimiento}
        diasRestantes={diasPara('calcomania')}
        severidad={sevPara('calcomania')}
        onPress={() => setEditando({ tipo: 'calcomania' })}
      />
      <DocumentCard
        icono="card-text"
        titulo="Placa metalica (5 anos)"
        detalle={auto.placaMetalica?.numero || 'No registrada'}
        fechaVencimiento={auto.placaMetalica?.fechaVencimiento}
        diasRestantes={diasPara('placa_metalica')}
        severidad={sevPara('placa_metalica')}
        onPress={() => setEditando({ tipo: 'placa' })}
      />

      {editando?.tipo === 'registro' && (
        <ModalRegistro auto={auto} onClose={() => setEditando(null)} />
      )}
      {editando?.tipo === 'poliza' && (
        <ModalPoliza auto={auto} onClose={() => setEditando(null)} />
      )}
      {editando?.tipo === 'revisado' && (
        <ModalRevisado auto={auto} onClose={() => setEditando(null)} />
      )}
      {editando?.tipo === 'calcomania' && (
        <ModalCalcomania auto={auto} onClose={() => setEditando(null)} />
      )}
      {editando?.tipo === 'placa' && (
        <ModalPlaca auto={auto} onClose={() => setEditando(null)} />
      )}
    </View>
  );
}

// ----- Modal generico -----
function ModalContainer({
  visible,
  titulo,
  onClose,
  children,
  onGuardar,
  guardando,
}: {
  visible: boolean;
  titulo: string;
  onClose: () => void;
  children: React.ReactNode;
  onGuardar: () => void;
  guardando?: boolean;
}) {
  return (
    <Portal>
      <Modal
        visible={visible}
        onDismiss={onClose}
        contentContainerStyle={styles.modalSheet}
      >
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitulo}>{titulo}</Text>
          <IconButton icon="close" onPress={onClose} />
        </View>
        <ScrollView>{children}</ScrollView>
        <View style={styles.rowBtns}>
          <Button mode="outlined" onPress={onClose}>
            Cancelar
          </Button>
          <Button mode="contained" onPress={onGuardar} loading={guardando}>
            Guardar
          </Button>
        </View>
      </Modal>
    </Portal>
  );
}

function ModalRegistro({ auto, onClose }: { auto: Auto; onClose: () => void }) {
  const { setDatos } = useApp();
  const [v, setV] = useState<RegistroUnico>(
    auto.registroUnico ?? { numero: '', fechaEmision: '' },
  );
  const [guardando, setGuardando] = useState(false);
  const guardar = async () => {
    setGuardando(true);
    await setDatos((d) => actualizarAuto(d, auto.id, { registroUnico: v }));
    setGuardando(false);
    onClose();
  };
  return (
    <ModalContainer
      visible
      titulo="Registro unico vehicular"
      onClose={onClose}
      onGuardar={guardar}
      guardando={guardando}
    >
      <TextField label="Numero" value={v.numero} onChange={(t) => setV({ ...v, numero: t })} />
      <DateField
        label="Fecha de emision"
        value={v.fechaEmision}
        onChange={(t) => setV({ ...v, fechaEmision: t })}
      />
      <FotoCapture
        foto={v.foto}
        carpeta="documentos"
        prefijo={`registro_${auto.id}`}
        etiqueta="Foto del documento"
        onChange={(f) => setV({ ...v, foto: f })}
      />
    </ModalContainer>
  );
}

function ModalPoliza({ auto, onClose }: { auto: Auto; onClose: () => void }) {
  const { setDatos } = useApp();
  const [v, setV] = useState<PolizaSeguro>(
    auto.polizaSeguro ?? {
      aseguradora: '',
      numeroPoliza: '',
      fechaInicio: '',
      fechaVencimiento: '',
      monto: 0,
      cobertura: '',
    },
  );
  const [guardando, setGuardando] = useState(false);
  const guardar = async () => {
    setGuardando(true);
    await setDatos((d) => actualizarAuto(d, auto.id, { polizaSeguro: v }));
    setGuardando(false);
    onClose();
  };
  return (
    <ModalContainer
      visible
      titulo="Poliza de seguro"
      onClose={onClose}
      onGuardar={guardar}
      guardando={guardando}
    >
      <TextField
        label="Aseguradora"
        value={v.aseguradora}
        onChange={(t) => setV({ ...v, aseguradora: t })}
      />
      <TextField
        label="Numero de poliza"
        value={v.numeroPoliza}
        onChange={(t) => setV({ ...v, numeroPoliza: t })}
      />
      <DateField
        label="Fecha de inicio"
        value={v.fechaInicio}
        onChange={(t) => setV({ ...v, fechaInicio: t })}
      />
      <DateField
        label="Fecha de vencimiento"
        value={v.fechaVencimiento}
        onChange={(t) => setV({ ...v, fechaVencimiento: t })}
      />
      <NumberField
        label="Monto"
        value={v.monto}
        onChange={(t) => setV({ ...v, monto: t })}
        suffix="B/."
      />
      <TextField
        label="Cobertura"
        value={v.cobertura}
        onChange={(t) => setV({ ...v, cobertura: t })}
        multiline
      />
      <FotoCapture
        foto={v.foto}
        carpeta="documentos"
        prefijo={`poliza_${auto.id}`}
        etiqueta="Foto de la poliza"
        onChange={(f) => setV({ ...v, foto: f })}
      />
    </ModalContainer>
  );
}

function ModalRevisado({ auto, onClose }: { auto: Auto; onClose: () => void }) {
  const { setDatos } = useApp();
  const [v, setV] = useState<RevisadoVehicular>(
    auto.revisadoVehicular ?? {
      fechaUltimoRevisado: '',
      fechaProximoRevisado: '',
      taller: '',
      costo: 0,
    },
  );
  const [guardando, setGuardando] = useState(false);

  // Sugerir proximo revisado +12 meses cuando se cambia "ultimo"
  const onUltimoChange = (iso: string) => {
    const d = parseISO(iso);
    if (isValid(d)) {
      const next = addMonths(d, VIGENCIAS_PANAMA.revisadoVehicular.meses);
      setV({
        ...v,
        fechaUltimoRevisado: iso,
        fechaProximoRevisado: format(next, 'yyyy-MM-dd'),
      });
    } else {
      setV({ ...v, fechaUltimoRevisado: iso });
    }
  };

  const guardar = async () => {
    setGuardando(true);
    await setDatos((d) => actualizarAuto(d, auto.id, { revisadoVehicular: v }));
    setGuardando(false);
    onClose();
  };
  return (
    <ModalContainer
      visible
      titulo="Revisado vehicular"
      onClose={onClose}
      onGuardar={guardar}
      guardando={guardando}
    >
      <DateField
        label="Fecha del ultimo revisado"
        value={v.fechaUltimoRevisado}
        onChange={onUltimoChange}
      />
      <DateField
        label="Proximo revisado"
        value={v.fechaProximoRevisado}
        onChange={(t) => setV({ ...v, fechaProximoRevisado: t })}
        helper="Sugerido: +12 meses desde el ultimo"
      />
      <TextField label="Taller" value={v.taller} onChange={(t) => setV({ ...v, taller: t })} />
      <NumberField
        label="Costo"
        value={v.costo}
        onChange={(t) => setV({ ...v, costo: t })}
        suffix="B/."
      />
      <FotoCapture
        foto={v.foto}
        carpeta="documentos"
        prefijo={`revisado_${auto.id}`}
        etiqueta="Foto del comprobante"
        onChange={(f) => setV({ ...v, foto: f })}
      />
    </ModalContainer>
  );
}

function ModalCalcomania({ auto, onClose }: { auto: Auto; onClose: () => void }) {
  const { setDatos } = useApp();
  const [v, setV] = useState<Calcomania>(
    auto.calcomania ?? {
      mes: 'Enero',
      fechaPago: '',
      fechaVencimiento: '',
      costo: 0,
    },
  );
  const [guardando, setGuardando] = useState(false);

  const onPagoChange = (iso: string) => {
    const d = parseISO(iso);
    if (isValid(d)) {
      const next = addMonths(d, VIGENCIAS_PANAMA.calcomania.meses);
      setV({ ...v, fechaPago: iso, fechaVencimiento: format(next, 'yyyy-MM-dd') });
    } else {
      setV({ ...v, fechaPago: iso });
    }
  };

  const guardar = async () => {
    setGuardando(true);
    await setDatos((d) => actualizarAuto(d, auto.id, { calcomania: v }));
    setGuardando(false);
    onClose();
  };
  return (
    <ModalContainer
      visible
      titulo="Calcomania vehicular"
      onClose={onClose}
      onGuardar={guardar}
      guardando={guardando}
    >
      <SelectField
        label="Mes asignado"
        value={v.mes}
        onChange={(m) => setV({ ...v, mes: m as string })}
        options={MESES_CALCOMANIA.map((m) => ({ value: m, label: m }))}
      />
      <DateField
        label="Fecha de pago"
        value={v.fechaPago}
        onChange={onPagoChange}
      />
      <DateField
        label="Fecha de vencimiento"
        value={v.fechaVencimiento}
        onChange={(t) => setV({ ...v, fechaVencimiento: t })}
        helper="Vigencia 12 meses (Ley 214/2021)"
      />
      <NumberField
        label="Costo"
        value={v.costo}
        onChange={(t) => setV({ ...v, costo: t })}
        suffix="B/."
      />
      <TextField
        label="Numero de recibo"
        value={v.numeroRecibo ?? ''}
        onChange={(t) => setV({ ...v, numeroRecibo: t })}
      />
      <FotoCapture
        foto={v.foto}
        carpeta="documentos"
        prefijo={`calcomania_${auto.id}`}
        etiqueta="Foto de la calcomania o recibo"
        onChange={(f) => setV({ ...v, foto: f })}
      />
    </ModalContainer>
  );
}

function ModalPlaca({ auto, onClose }: { auto: Auto; onClose: () => void }) {
  const { setDatos } = useApp();
  const [v, setV] = useState<PlacaMetalica>(
    auto.placaMetalica ?? {
      fechaEmision: '',
      fechaVencimiento: '',
      numero: auto.placa || '',
      costo: 0,
    },
  );
  const [guardando, setGuardando] = useState(false);

  const onEmisionChange = (iso: string) => {
    const d = parseISO(iso);
    if (isValid(d)) {
      const next = addMonths(d, VIGENCIAS_PANAMA.placaMetalica.meses);
      setV({ ...v, fechaEmision: iso, fechaVencimiento: format(next, 'yyyy-MM-dd') });
    } else {
      setV({ ...v, fechaEmision: iso });
    }
  };

  const guardar = async () => {
    setGuardando(true);
    await setDatos((d) => actualizarAuto(d, auto.id, { placaMetalica: v }));
    setGuardando(false);
    onClose();
  };
  return (
    <ModalContainer
      visible
      titulo="Placa metalica"
      onClose={onClose}
      onGuardar={guardar}
      guardando={guardando}
    >
      <TextField label="Numero" value={v.numero} onChange={(t) => setV({ ...v, numero: t })} />
      <DateField
        label="Fecha de emision"
        value={v.fechaEmision}
        onChange={onEmisionChange}
      />
      <DateField
        label="Fecha de renovacion (5 anos)"
        value={v.fechaVencimiento}
        onChange={(t) => setV({ ...v, fechaVencimiento: t })}
      />
      <NumberField
        label="Costo"
        value={v.costo}
        onChange={(t) => setV({ ...v, costo: t })}
        suffix="B/."
      />
      <FotoCapture
        foto={v.foto}
        carpeta="documentos"
        prefijo={`placa_${auto.id}`}
        etiqueta="Foto de la placa"
        onChange={(f) => setV({ ...v, foto: f })}
      />
    </ModalContainer>
  );
}

// ============ MANTENIMIENTOS ============
function SeccionMantenimientos({ auto }: { auto: Auto }) {
  const { setDatos } = useApp();
  const [crear, setCrear] = useState<Mantenimiento | null>(null);
  const [editar, setEditar] = useState<Mantenimiento | null>(null);

  const pendientes = auto.mantenimientos.filter((m) => !m.completado);
  const completados = auto.mantenimientos.filter((m) => m.completado);

  const iniciarCrear = (tipo?: string) => {
    const preset = TIPOS_MANTENIMIENTO.find((t) => t.tipo === tipo);
    const ahora = new Date();
    const next = preset
      ? addMonths(ahora, preset.intervalMesesDefault)
      : addMonths(ahora, 6);
    setCrear({
      id: nuevoId(),
      tipo: tipo ?? 'Personalizado',
      fechaRealizado: format(ahora, 'yyyy-MM-dd'),
      kilometrajeRealizado: auto.kilometrajeActual,
      proximaFecha: format(next, 'yyyy-MM-dd'),
      proximoKilometraje: auto.kilometrajeActual + (preset?.intervalKmDefault ?? 5000),
      intervalMeses: preset?.intervalMesesDefault ?? 6,
      intervalKm: preset?.intervalKmDefault ?? 5000,
      costo: 0,
      taller: '',
      notas: '',
      completado: false,
    });
  };

  const guardarCrear = async () => {
    if (!crear) return;
    await setDatos((d) => agregarMantenimiento(d, auto.id, crear));
    setCrear(null);
  };

  const guardarEditar = async () => {
    if (!editar) return;
    await setDatos((d) => actualizarMantenimiento(d, auto.id, editar.id, editar));
    setEditar(null);
  };

  const marcarHecho = async (m: Mantenimiento) => {
    const ahora = new Date();
    const nextFecha = addMonths(ahora, m.intervalMeses);
    const ciclado: Mantenimiento = {
      ...m,
      completado: true,
    };
    const nuevoCiclo: Mantenimiento = {
      ...m,
      id: nuevoId(),
      fechaRealizado: format(ahora, 'yyyy-MM-dd'),
      kilometrajeRealizado: auto.kilometrajeActual,
      proximaFecha: format(nextFecha, 'yyyy-MM-dd'),
      proximoKilometraje: auto.kilometrajeActual + m.intervalKm,
      completado: false,
    };
    await setDatos((d) => {
      const d1 = actualizarMantenimiento(d, auto.id, m.id, { completado: true });
      return agregarMantenimiento(d1, auto.id, nuevoCiclo);
    });
  };

  const eliminar = (m: Mantenimiento) => {
    Alert.alert('Eliminar mantenimiento', `?Eliminar ${m.tipo}?`, [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Eliminar',
        style: 'destructive',
        onPress: () => setDatos((d) => eliminarMantenimiento(d, auto.id, m.id)),
      },
    ]);
  };

  return (
    <View style={styles.cardCol}>
      {/* Tipos rapidos */}
      <Text style={styles.subSeccion}>Agregar rapido</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chips}>
        {TIPOS_MANTENIMIENTO.slice(0, 8).map((t) => (
          <Pressable key={t.tipo} onPress={() => iniciarCrear(t.tipo)} style={styles.chip}>
            <MaterialCommunityIcons name={t.icono as any} size={16} color={PALETA.primary} />
            <Text style={styles.chipTxt}>{t.tipo.split(' ')[0]}</Text>
          </Pressable>
        ))}
        <Pressable onPress={() => iniciarCrear()} style={[styles.chip, styles.chipAcento]}>
          <MaterialCommunityIcons name="plus" size={16} color="#fff" />
          <Text style={[styles.chipTxt, { color: '#fff' }]}>Personalizado</Text>
        </Pressable>
      </ScrollView>

      <Text style={styles.subSeccion}>Pendientes ({pendientes.length})</Text>
      {pendientes.length === 0 && (
        <Text style={styles.placeholderTxt}>Sin mantenimientos pendientes</Text>
      )}
      {pendientes.map((m) => (
        <MantenimientoItem
          key={m.id}
          item={m}
          onEdit={() => setEditar(m)}
          onDone={() => marcarHecho(m)}
          onDel={() => eliminar(m)}
          kmActual={auto.kilometrajeActual}
        />
      ))}

      {completados.length > 0 && (
        <>
          <Text style={styles.subSeccion}>Historico ({completados.length})</Text>
          {completados.slice(0, 20).map((m) => (
            <MantenimientoItem
              key={m.id}
              item={m}
              onEdit={() => setEditar(m)}
              onDel={() => eliminar(m)}
              kmActual={auto.kilometrajeActual}
              historico
            />
          ))}
        </>
      )}

      {crear && (
        <FormMantenimientoModal
          item={crear}
          onChange={setCrear}
          onGuardar={guardarCrear}
          onClose={() => setCrear(null)}
          titulo="Nuevo mantenimiento"
        />
      )}
      {editar && (
        <FormMantenimientoModal
          item={editar}
          onChange={setEditar}
          onGuardar={guardarEditar}
          onClose={() => setEditar(null)}
          titulo="Editar mantenimiento"
        />
      )}
    </View>
  );
}

function MantenimientoItem({
  item,
  onEdit,
  onDone,
  onDel,
  kmActual,
  historico,
}: {
  item: Mantenimiento;
  onEdit: () => void;
  onDone?: () => void;
  onDel: () => void;
  kmActual: number;
  historico?: boolean;
}) {
  const fecha = isValid(parseISO(item.proximaFecha))
    ? format(parseISO(item.proximaFecha), 'dd/MM/yyyy')
    : item.proximaFecha;
  const kmRest = item.proximoKilometraje - kmActual;

  return (
    <View style={[styles.itemRow, historico && { opacity: 0.7 }]}>
      <View style={{ flex: 1 }}>
        <Text style={styles.itemTitulo}>{item.tipo}</Text>
        <Text style={styles.itemSub}>
          {historico ? 'Realizado' : 'Proximo'}: {fecha} · {item.proximoKilometraje.toLocaleString()} km
        </Text>
        {!historico && (
          <Text style={styles.itemSub}>
            Faltan {kmRest > 0 ? `${kmRest.toLocaleString()} km` : 'cumplido'}
          </Text>
        )}
        {item.taller && <Text style={styles.itemSub}>Taller: {item.taller}</Text>}
        {item.costo > 0 && <Text style={styles.itemSub}>B/. {item.costo.toFixed(2)}</Text>}
      </View>
      <View style={styles.itemActions}>
        {!historico && onDone && (
          <IconButton icon="check-bold" iconColor={PALETA.semaforo.aldia} onPress={onDone} />
        )}
        <IconButton icon="pencil" onPress={onEdit} />
        <IconButton icon="delete" iconColor={PALETA.error} onPress={onDel} />
      </View>
    </View>
  );
}

function FormMantenimientoModal({
  item,
  onChange,
  onGuardar,
  onClose,
  titulo,
}: {
  item: Mantenimiento;
  onChange: (m: Mantenimiento) => void;
  onGuardar: () => void;
  onClose: () => void;
  titulo: string;
}) {
  const [guardando, setGuardando] = useState(false);
  const guardar = async () => {
    setGuardando(true);
    await onGuardar();
    setGuardando(false);
  };
  return (
    <ModalContainer
      visible
      titulo={titulo}
      onClose={onClose}
      onGuardar={guardar}
      guardando={guardando}
    >
      <SelectField
        label="Tipo"
        value={item.tipo}
        onChange={(v) => onChange({ ...item, tipo: v as string })}
        options={[
          ...TIPOS_MANTENIMIENTO.map((t) => ({ value: t.tipo, label: t.tipo })),
          { value: 'Personalizado', label: 'Personalizado' },
        ]}
      />
      <DateField
        label="Fecha realizado"
        value={item.fechaRealizado}
        onChange={(v) => onChange({ ...item, fechaRealizado: v })}
      />
      <NumberField
        label="Kilometraje al realizar"
        value={item.kilometrajeRealizado}
        onChange={(v) => onChange({ ...item, kilometrajeRealizado: v })}
        suffix="km"
      />
      <DateField
        label="Proxima fecha"
        value={item.proximaFecha}
        onChange={(v) => onChange({ ...item, proximaFecha: v })}
      />
      <NumberField
        label="Proximo kilometraje"
        value={item.proximoKilometraje}
        onChange={(v) => onChange({ ...item, proximoKilometraje: v })}
        suffix="km"
      />
      <NumberField
        label="Intervalo en meses"
        value={item.intervalMeses}
        onChange={(v) => onChange({ ...item, intervalMeses: v })}
      />
      <NumberField
        label="Intervalo en km"
        value={item.intervalKm}
        onChange={(v) => onChange({ ...item, intervalKm: v })}
        suffix="km"
      />
      <TextField
        label="Taller"
        value={item.taller}
        onChange={(v) => onChange({ ...item, taller: v })}
      />
      <NumberField
        label="Costo"
        value={item.costo}
        onChange={(v) => onChange({ ...item, costo: v })}
        suffix="B/."
      />
      <TextField
        label="Notas"
        value={item.notas}
        onChange={(v) => onChange({ ...item, notas: v })}
        multiline
      />
      <FotoCapture
        foto={item.fotoRecibo}
        carpeta="documentos"
        prefijo={`mant_${item.id}`}
        etiqueta="Foto del recibo (opcional)"
        onChange={(f) => onChange({ ...item, fotoRecibo: f })}
      />
    </ModalContainer>
  );
}

// ============ PIEZAS ============
function SeccionPiezas({ auto }: { auto: Auto }) {
  const { setDatos } = useApp();
  const [crear, setCrear] = useState<CambioPieza | null>(null);

  const iniciarCrear = () => {
    const ahora = new Date();
    setCrear({
      id: nuevoId(),
      pieza: '',
      marca: '',
      fechaCambio: format(ahora, 'yyyy-MM-dd'),
      kilometrajeCambio: auto.kilometrajeActual,
      vidaUtilKm: 50000,
      vidaUtilMeses: 36,
      proximoCambioFecha: format(addMonths(ahora, 36), 'yyyy-MM-dd'),
      proximoCambioKm: auto.kilometrajeActual + 50000,
      costo: 0,
      taller: '',
      notas: '',
    });
  };

  const guardarCrear = async () => {
    if (!crear) return;
    await setDatos((d) => agregarCambioPieza(d, auto.id, crear));
    setCrear(null);
  };

  const eliminar = (p: CambioPieza) => {
    Alert.alert('Eliminar', `?Eliminar el cambio de ${p.pieza}?`, [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Eliminar',
        style: 'destructive',
        onPress: () => setDatos((d) => eliminarCambioPieza(d, auto.id, p.id)),
      },
    ]);
  };

  return (
    <View style={styles.cardCol}>
      <View style={styles.rowBetween}>
        <Text style={styles.subSeccion}>Cambios de piezas</Text>
        <Button mode="contained-tonal" icon="plus" onPress={iniciarCrear}>
          Agregar
        </Button>
      </View>

      {auto.cambiosPiezas.length === 0 && (
        <Text style={styles.placeholderTxt}>Sin cambios registrados</Text>
      )}

      {auto.cambiosPiezas.map((p) => (
        <View key={p.id} style={styles.itemRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.itemTitulo}>
              {p.pieza} {p.marca ? `· ${p.marca}` : ''}
            </Text>
            <Text style={styles.itemSub}>
              Cambiado: {p.fechaCambio} @ {p.kilometrajeCambio.toLocaleString()} km
            </Text>
            <Text style={styles.itemSub}>
              Proximo: {p.proximoCambioFecha} @ {p.proximoCambioKm.toLocaleString()} km
            </Text>
            {p.taller && <Text style={styles.itemSub}>Taller: {p.taller}</Text>}
            {p.costo > 0 && <Text style={styles.itemSub}>B/. {p.costo.toFixed(2)}</Text>}
          </View>
          <IconButton icon="delete" iconColor={PALETA.error} onPress={() => eliminar(p)} />
        </View>
      ))}

      {crear && (
        <FormPiezaModal
          item={crear}
          onChange={setCrear}
          onGuardar={guardarCrear}
          onClose={() => setCrear(null)}
        />
      )}
    </View>
  );
}

function FormPiezaModal({
  item,
  onChange,
  onGuardar,
  onClose,
}: {
  item: CambioPieza;
  onChange: (p: CambioPieza) => void;
  onGuardar: () => void;
  onClose: () => void;
}) {
  const [guardando, setGuardando] = useState(false);

  const onVidaUtilMesesChange = (m: number) => {
    const d = parseISO(item.fechaCambio);
    const next = isValid(d) ? addMonths(d, m) : new Date();
    onChange({
      ...item,
      vidaUtilMeses: m,
      proximoCambioFecha: format(next, 'yyyy-MM-dd'),
    });
  };
  const onVidaUtilKmChange = (km: number) => {
    onChange({
      ...item,
      vidaUtilKm: km,
      proximoCambioKm: item.kilometrajeCambio + km,
    });
  };

  return (
    <ModalContainer
      visible
      titulo="Cambio de pieza"
      onClose={onClose}
      onGuardar={async () => {
        setGuardando(true);
        await onGuardar();
        setGuardando(false);
      }}
      guardando={guardando}
    >
      <TextField
        label="Pieza"
        value={item.pieza}
        onChange={(v) => onChange({ ...item, pieza: v })}
        placeholder="Pastillas de freno, Bateria, Llantas..."
      />
      <TextField
        label="Marca"
        value={item.marca}
        onChange={(v) => onChange({ ...item, marca: v })}
      />
      <DateField
        label="Fecha de cambio"
        value={item.fechaCambio}
        onChange={(v) => onChange({ ...item, fechaCambio: v })}
      />
      <NumberField
        label="Kilometraje al cambio"
        value={item.kilometrajeCambio}
        onChange={(v) => onChange({ ...item, kilometrajeCambio: v })}
        suffix="km"
      />
      <NumberField
        label="Vida util (meses)"
        value={item.vidaUtilMeses}
        onChange={onVidaUtilMesesChange}
      />
      <NumberField
        label="Vida util (km)"
        value={item.vidaUtilKm}
        onChange={onVidaUtilKmChange}
        suffix="km"
      />
      <DateField
        label="Proximo cambio (fecha)"
        value={item.proximoCambioFecha}
        onChange={(v) => onChange({ ...item, proximoCambioFecha: v })}
      />
      <NumberField
        label="Proximo cambio (km)"
        value={item.proximoCambioKm}
        onChange={(v) => onChange({ ...item, proximoCambioKm: v })}
        suffix="km"
      />
      <TextField
        label="Taller"
        value={item.taller}
        onChange={(v) => onChange({ ...item, taller: v })}
      />
      <NumberField
        label="Costo"
        value={item.costo}
        onChange={(v) => onChange({ ...item, costo: v })}
        suffix="B/."
      />
      <TextField
        label="Notas"
        value={item.notas}
        onChange={(v) => onChange({ ...item, notas: v })}
        multiline
      />
      <FotoCapture
        foto={item.fotoRecibo}
        carpeta="documentos"
        prefijo={`pieza_${item.id}`}
        etiqueta="Foto del recibo (opcional)"
        onChange={(f) => onChange({ ...item, fotoRecibo: f })}
      />
    </ModalContainer>
  );
}

// ============ REPORTES ============
function SeccionReportes({ auto }: { auto: Auto }) {
  const totales = useMemo(() => {
    const mant = auto.mantenimientos.reduce((s, m) => s + m.costo, 0);
    const piezas = auto.cambiosPiezas.reduce((s, p) => s + p.costo, 0);
    const docs =
      (auto.polizaSeguro?.monto ?? 0) +
      (auto.calcomania?.costo ?? 0) +
      (auto.revisadoVehicular?.costo ?? 0) +
      (auto.placaMetalica?.costo ?? 0);
    return { mant, piezas, docs, total: mant + piezas + docs };
  }, [auto]);

  return (
    <View style={styles.cardCol}>
      <Text style={styles.subSeccion}>Gastos acumulados</Text>
      <Row label="Mantenimientos" value={`B/. ${totales.mant.toFixed(2)}`} />
      <Row label="Piezas" value={`B/. ${totales.piezas.toFixed(2)}`} />
      <Row label="Documentos" value={`B/. ${totales.docs.toFixed(2)}`} />
      <View style={styles.totalRow}>
        <Text style={styles.totalLabel}>TOTAL</Text>
        <Text style={styles.totalValor}>B/. {totales.total.toFixed(2)}</Text>
      </View>

      <Text style={styles.subSeccion}>Historial cronologico</Text>
      {[...auto.mantenimientos, ...auto.cambiosPiezas]
        .sort((a, b) => {
          const fa = 'fechaRealizado' in a ? a.fechaRealizado : a.fechaCambio;
          const fb = 'fechaRealizado' in b ? b.fechaRealizado : b.fechaCambio;
          return fb.localeCompare(fa);
        })
        .slice(0, 30)
        .map((it) => {
          const fecha = 'fechaRealizado' in it ? it.fechaRealizado : it.fechaCambio;
          const titulo = 'tipo' in it ? it.tipo : `Pieza: ${it.pieza}`;
          return (
            <View key={it.id} style={styles.histRow}>
              <Text style={styles.histFecha}>{fecha}</Text>
              <Text style={styles.histTit}>{titulo}</Text>
              <Text style={styles.histCosto}>B/. {it.costo.toFixed(2)}</Text>
            </View>
          );
        })}
    </View>
  );
}

// ============ ESTILOS ============
const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  scroll: { paddingBottom: 64 },
  header: {
    padding: ESPACIADO.marginMobile,
    backgroundColor: PALETA.surfaceContainerLowest,
    flexDirection: 'row',
    gap: ESPACIADO.gutter,
    alignItems: 'center',
  },
  fotoHeader: {
    width: 100,
    height: 80,
    borderRadius: RADIO.md,
    backgroundColor: PALETA.surfaceContainer,
  },
  fotoPlaceholder: { alignItems: 'center', justifyContent: 'center' },
  headerInfo: { flex: 1 },
  headerTitulo: { ...TIPO.titleLg, color: PALETA.primary },
  headerSub: { ...TIPO.bodyMd, color: PALETA.onSurfaceVariant },
  headerPlaca: { ...TIPO.bodyMd, color: PALETA.onSurface, fontWeight: '600' as const },
  headerAlerta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  headerAlertaTxt: { ...TIPO.labelLg, color: PALETA.semaforo.urgente },
  seg: {
    margin: ESPACIADO.marginMobile,
  },
  cardCol: {
    paddingHorizontal: ESPACIADO.marginMobile,
    gap: ESPACIADO.gutter,
  },
  subSeccion: {
    ...TIPO.titleLg,
    color: PALETA.onSurface,
    fontSize: 16,
    marginTop: ESPACIADO.gutter,
  },
  placeholderTxt: { ...TIPO.bodyMd, color: PALETA.outline, fontStyle: 'italic' },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: PALETA.outlineVariant,
  },
  infoLabel: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant },
  infoValue: {
    ...TIPO.bodyLg,
    color: PALETA.onSurface,
    fontWeight: '600' as const,
    maxWidth: '60%',
    textAlign: 'right',
  },
  choferLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
  },
  choferLinkTxt: { ...TIPO.bodyLg, color: PALETA.onSurface, flex: 1 },
  rowBtns: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: ESPACIADO.gutter,
    marginTop: ESPACIADO.stackMd,
  },
  rowBetween: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  chips: { flexGrow: 0 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: PALETA.primaryFixed,
    borderRadius: RADIO.full,
    marginRight: 8,
  },
  chipAcento: { backgroundColor: PALETA.secondaryContainer },
  chipTxt: { ...TIPO.labelLg, color: PALETA.primary },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    padding: ESPACIADO.cardPadding,
    elevation: 1,
  },
  itemTitulo: { ...TIPO.titleLg, color: PALETA.onSurface, fontSize: 16 },
  itemSub: { ...TIPO.bodyMd, color: PALETA.onSurfaceVariant },
  itemActions: { flexDirection: 'row' },
  modalSheet: {
    backgroundColor: PALETA.background,
    margin: 16,
    borderRadius: RADIO.lg,
    padding: ESPACIADO.cardPadding,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  modalTitulo: { ...TIPO.titleLg, color: PALETA.primary, flex: 1 },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: ESPACIADO.cardPadding,
    backgroundColor: PALETA.primaryFixed,
    borderRadius: RADIO.md,
    marginTop: ESPACIADO.gutter,
  },
  totalLabel: { ...TIPO.titleLg, color: PALETA.primary },
  totalValor: { ...TIPO.headlineMd, color: PALETA.primary },
  histRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: PALETA.outlineVariant,
  },
  histFecha: { ...TIPO.labelLg, color: PALETA.outline, width: 90 },
  histTit: { ...TIPO.bodyMd, color: PALETA.onSurface, flex: 1 },
  histCosto: { ...TIPO.bodyMd, color: PALETA.primary, fontWeight: '600' as const },
});
