// AutoAlerta - Crear nuevo auto
import { useState } from 'react';
import { ScrollView, StyleSheet, View, Alert } from 'react-native';
import { Button, Text } from 'react-native-paper';
import { useRouter } from 'expo-router';
import { useApp } from '@/hooks/AppContext';
import { autoNuevo, agregarAuto } from '@/services/mutations';
import { TextField, NumberField, SelectField } from '@/components/Form';
import { FotoCapture } from '@/components/FotoCapture';
import { COLORES_VEHICULO } from '@/constants/mantenimientos';
import { PALETA, ESPACIADO, TIPO } from '@/constants/tema';
import type { Auto, DocumentoFoto } from '@/types';

export default function NuevoAuto() {
  const router = useRouter();
  const { setDatos } = useApp();
  const [auto, setAuto] = useState<Auto>(() => autoNuevo());
  const [guardando, setGuardando] = useState(false);

  const upd = <K extends keyof Auto>(k: K, v: Auto[K]) =>
    setAuto((a) => ({ ...a, [k]: v }));

  const guardar = async () => {
    if (!auto.marca.trim() || !auto.modelo.trim()) {
      Alert.alert('Faltan datos', 'Marca y modelo son obligatorios');
      return;
    }
    try {
      setGuardando(true);
      await setDatos((d) => agregarAuto(d, auto));
      router.replace(`/auto/${auto.id}`);
    } catch (err: any) {
      Alert.alert('Error', err?.message ?? 'No se pudo guardar');
    } finally {
      setGuardando(false);
    }
  };

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.contenido}>
      <Text style={styles.titulo}>Datos del vehiculo</Text>

      <FotoCapture
        foto={auto.foto}
        carpeta="autos"
        prefijo={`auto_${auto.id}`}
        etiqueta="Foto del vehiculo"
        onChange={(f) => upd('foto', f)}
        ratio={16 / 9}
      />

      <TextField
        label="Marca *"
        value={auto.marca}
        onChange={(v) => upd('marca', v)}
        placeholder="Toyota, Honda, Hyundai..."
        autoCapitalize="words"
      />
      <TextField
        label="Modelo *"
        value={auto.modelo}
        onChange={(v) => upd('modelo', v)}
        placeholder="Yaris, Civic, Tucson..."
        autoCapitalize="words"
      />

      <View style={styles.row}>
        <View style={{ flex: 1 }}>
          <NumberField
            label="Anio"
            value={auto.anio}
            onChange={(v) => upd('anio', v)}
            min={1950}
            max={new Date().getFullYear() + 1}
          />
        </View>
        <View style={{ flex: 1 }}>
          <SelectField
            label="Color"
            value={auto.color}
            onChange={(v) => upd('color', v as string)}
            options={COLORES_VEHICULO.map((c) => ({ value: c, label: c }))}
          />
        </View>
      </View>

      <TextField
        label="Placa"
        value={auto.placa}
        onChange={(v) => upd('placa', v.toUpperCase())}
        placeholder="AB-1234"
        autoCapitalize="characters"
        maxLength={10}
      />

      <TextField
        label="VIN"
        value={auto.vin}
        onChange={(v) => upd('vin', v.toUpperCase())}
        placeholder="17 caracteres"
        autoCapitalize="characters"
        maxLength={17}
      />

      <NumberField
        label="Kilometraje actual"
        value={auto.kilometrajeActual}
        onChange={(v) => upd('kilometrajeActual', v)}
        suffix="km"
      />

      <TextField
        label="Notas"
        value={auto.notas}
        onChange={(v) => upd('notas', v)}
        multiline
        placeholder="Observaciones (opcional)"
      />

      <Button
        mode="contained"
        onPress={guardar}
        loading={guardando}
        disabled={guardando}
        style={styles.btn}
        contentStyle={{ height: 52 }}
      >
        Guardar auto
      </Button>
      <Button
        mode="text"
        onPress={() => router.back()}
        disabled={guardando}
      >
        Cancelar
      </Button>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: PALETA.background },
  contenido: { padding: ESPACIADO.marginMobile, paddingBottom: 64 },
  titulo: {
    ...TIPO.titleLg,
    color: PALETA.primary,
    marginBottom: ESPACIADO.gutter,
  },
  row: { flexDirection: 'row', gap: ESPACIADO.gutter },
  btn: { marginTop: ESPACIADO.stackMd, backgroundColor: PALETA.primary },
});
