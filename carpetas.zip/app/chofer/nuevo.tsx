// AutoAlerta - Crear nuevo chofer
import { useState } from 'react';
import { ScrollView, StyleSheet, Alert } from 'react-native';
import { Button, Text } from 'react-native-paper';
import { useRouter } from 'expo-router';
import { useApp } from '@/hooks/AppContext';
import { choferNuevo, agregarChofer } from '@/services/mutations';
import { TextField, DateField } from '@/components/Form';
import { FotoCapture } from '@/components/FotoCapture';
import { PALETA, ESPACIADO, TIPO } from '@/constants/tema';
import type { Chofer } from '@/types';

export default function NuevoChofer() {
  const router = useRouter();
  const { setDatos } = useApp();
  const [c, setC] = useState<Chofer>(() => choferNuevo());
  const [guardando, setGuardando] = useState(false);

  const upd = <K extends keyof Chofer>(k: K, v: Chofer[K]) => setC((p) => ({ ...p, [k]: v }));

  const guardar = async () => {
    if (!c.nombre.trim() || !c.apellido.trim()) {
      Alert.alert('Faltan datos', 'Nombre y apellido son obligatorios');
      return;
    }
    try {
      setGuardando(true);
      await setDatos((d) => agregarChofer(d, c));
      router.replace(`/chofer/${c.id}`);
    } catch (err: any) {
      Alert.alert('Error', err?.message ?? 'No se pudo guardar');
    } finally {
      setGuardando(false);
    }
  };

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.contenido}>
      <Text style={styles.titulo}>Datos del chofer</Text>

      <FotoCapture
        foto={c.foto}
        carpeta="choferes"
        prefijo={`chofer_${c.id}`}
        etiqueta="Foto del chofer"
        onChange={(f) => upd('foto', f)}
        ratio={1}
      />

      <TextField
        label="Nombre *"
        value={c.nombre}
        onChange={(v) => upd('nombre', v)}
        autoCapitalize="words"
      />
      <TextField
        label="Apellido *"
        value={c.apellido}
        onChange={(v) => upd('apellido', v)}
        autoCapitalize="words"
      />
      <TextField
        label="Telefono"
        value={c.telefono}
        onChange={(v) => upd('telefono', v)}
        keyboardType="phone-pad"
      />
      <TextField
        label="Email"
        value={c.email}
        onChange={(v) => upd('email', v)}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <DateField
        label="Fecha de nacimiento"
        value={c.fechaNacimiento ?? ''}
        onChange={(v) => upd('fechaNacimiento', v)}
        helper="Determina vigencia de cedula y licencia"
      />
      <TextField
        label="Direccion"
        value={c.direccion ?? ''}
        onChange={(v) => upd('direccion', v)}
        multiline
      />
      <TextField
        label="Notas"
        value={c.notas}
        onChange={(v) => upd('notas', v)}
        multiline
      />

      <Button
        mode="contained"
        onPress={guardar}
        loading={guardando}
        disabled={guardando}
        style={styles.btn}
        contentStyle={{ height: 52 }}
      >
        Guardar chofer
      </Button>
      <Button mode="text" onPress={() => router.back()} disabled={guardando}>
        Cancelar
      </Button>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: PALETA.background },
  contenido: { padding: ESPACIADO.marginMobile, paddingBottom: 64 },
  titulo: {
    ...TIPO.titleLg,
    color: PALETA.primary,
    marginBottom: ESPACIADO.gutter,
  },
  btn: { marginTop: ESPACIADO.stackMd, backgroundColor: PALETA.primary },
});
