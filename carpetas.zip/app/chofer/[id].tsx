// AutoAlerta - Detalle del chofer
import { useState, useMemo } from 'react';
import {
  ScrollView,
  StyleSheet,
  View,
  Image,
  Alert,
  Pressable,
  Linking,
} from 'react-native';
import {
  Text,
  Button,
  IconButton,
  Portal,
  Modal,
  Switch,
  Chip,
} from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useApp, useChofer } from '@/hooks/AppContext';
import {
  actualizarChofer,
  eliminarChofer,
  asignarChoferAuto,
  desasignarChoferAuto,
} from '@/services/mutations';
import { calcularAlertasChofer } from '@/services/alertEngine';
import { DocumentCard } from '@/components/DocumentCard';
import { TextField, DateField, SelectField } from '@/components/Form';
import { FotoCapture } from '@/components/FotoCapture';
import { EmptyState } from '@/components/EmptyState';
import { CATEGORIAS_LICENCIA, VIGENCIAS_PANAMA } from '@/constants/leyes-panama';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';
import type { Chofer, Cedula, LicenciaConducir, CategoriaLicencia } from '@/types';
import { addMonths, format, parseISO, isValid, differenceInYears } from 'date-fns';

export default function DetalleChofer() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { setDatos, datos } = useApp();
  const chofer = useChofer(id);
  const [editandoBasico, setEditandoBasico] = useState(false);
  const [editandoDoc, setEditandoDoc] = useState<'cedula' | 'licencia' | null>(null);
  const [borrador, setBorrador] = useState<Chofer | null>(null);

  const alertas = useMemo(() => (chofer ? calcularAlertasChofer(chofer) : []), [chofer]);
  const autosAsignados =
    datos?.autos.filter((a) => chofer?.autosAsignados.includes(a.id)) ?? [];
  const autosDisponibles =
    datos?.autos.filter((a) => !chofer?.autosAsignados.includes(a.id)) ?? [];

  if (!chofer) {
    return (
      <View style={styles.center}>
        <EmptyState
          icono="account-off"
          titulo="Chofer no encontrado"
          ctaLabel="Volver"
          onCta={() => router.back()}
        />
      </View>
    );
  }

  const nombre = `${chofer.nombre} ${chofer.apellido}`.trim();
  const sevPara = (tipo: string) => alertas.find((a) => a.tipo === tipo)?.severidad ?? 'aldia';
  const diasPara = (tipo: string) => alertas.find((a) => a.tipo === tipo)?.diasRestantes;

  const onEliminar = () => {
    Alert.alert('Eliminar chofer', `?Eliminar ${nombre}?`, [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Eliminar',
        style: 'destructive',
        onPress: async () => {
          await setDatos((d) => eliminarChofer(d, chofer.id));
          router.replace('/(tabs)/choferes');
        },
      },
    ]);
  };

  const guardarBasico = async () => {
    if (!borrador) return;
    await setDatos((d) => actualizarChofer(d, chofer.id, borrador));
    setEditandoBasico(false);
    setBorrador(null);
  };

  return (
    <View style={{ flex: 1, backgroundColor: PALETA.background }}>
      <Stack.Screen
        options={{
          title: nombre,
          headerRight: () => (
            <IconButton icon="delete" iconColor={PALETA.error} onPress={onEliminar} />
          ),
        }}
      />

      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.foto}>
            {chofer.foto?.uri ? (
              <Image source={{ uri: chofer.foto.uri }} style={styles.fotoImg} />
            ) : (
              <MaterialCommunityIcons name="account" size={72} color={PALETA.outline} />
            )}
          </View>
          <Text style={styles.headerTitulo}>{nombre}</Text>
          {chofer.telefono ? (
            <Pressable onPress={() => Linking.openURL(`tel:${chofer.telefono}`)}>
              <Text style={styles.headerSub}>{chofer.telefono}</Text>
            </Pressable>
          ) : null}
          {chofer.email ? (
            <Pressable onPress={() => Linking.openURL(`mailto:${chofer.email}`)}>
              <Text style={styles.headerSub}>{chofer.email}</Text>
            </Pressable>
          ) : null}
          <View style={styles.statusRow}>
            <Chip
              icon={chofer.activo ? 'check-circle' : 'pause-circle'}
              compact
              selectedColor={
                chofer.activo ? PALETA.semaforo.aldia : PALETA.outline
              }
            >
              {chofer.activo ? 'Activo' : 'Inactivo'}
            </Chip>
            <Button
              mode="contained-tonal"
              icon="pencil"
              compact
              onPress={() => {
                setBorrador(chofer);
                setEditandoBasico(true);
              }}
            >
              Editar
            </Button>
          </View>
        </View>

        {/* Documentos */}
        <View style={styles.cardCol}>
          <Text style={styles.subSeccion}>Documentos</Text>

          <DocumentCard
            icono="card-account-details"
            titulo="Cedula de identidad"
            detalle={chofer.cedula?.numero || 'No registrada'}
            fechaVencimiento={chofer.cedula?.fechaVencimiento}
            diasRestantes={diasPara('cedula')}
            severidad={sevPara('cedula')}
            onPress={() => setEditandoDoc('cedula')}
          />
          <Pressable
            onPress={() => Linking.openURL(`https://tribunalcontigo.com`)}
            style={styles.linkExt}
          >
            <MaterialCommunityIcons name="open-in-new" size={14} color={PALETA.primary} />
            <Text style={styles.linkExtTxt}>Renovar cedula en tribunalcontigo.com</Text>
          </Pressable>

          <DocumentCard
            icono="card-bulleted"
            titulo="Licencia de conducir"
            detalle={
              chofer.licenciaConducir
                ? `Cat. ${chofer.licenciaConducir.categoria}`
                : 'No registrada'
            }
            fechaVencimiento={chofer.licenciaConducir?.fechaVencimiento}
            diasRestantes={diasPara('licencia')}
            severidad={sevPara('licencia')}
            onPress={() => setEditandoDoc('licencia')}
          />
          <Pressable
            onPress={() => Linking.openURL(`https://sertracen.com.pa`)}
            style={styles.linkExt}
          >
            <MaterialCommunityIcons name="open-in-new" size={14} color={PALETA.primary} />
            <Text style={styles.linkExtTxt}>Renovar licencia en sertracen.com.pa</Text>
          </Pressable>

          {/* Asignacion de autos */}
          <Text style={styles.subSeccion}>Autos asignados</Text>
          {autosAsignados.length === 0 && (
            <Text style={styles.placeholderTxt}>Sin autos asignados</Text>
          )}
          {autosAsignados.map((a) => (
            <View key={a.id} style={styles.autoRow}>
              <Pressable
                onPress={() => router.push(`/auto/${a.id}`)}
                style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 }}
              >
                <MaterialCommunityIcons name="car" size={20} color={PALETA.primary} />
                <Text style={styles.autoTxt}>
                  {a.marca} {a.modelo} · {a.placa}
                </Text>
              </Pressable>
              <IconButton
                icon="link-off"
                onPress={() => setDatos((d) => desasignarChoferAuto(d, a.id, chofer.id))}
              />
            </View>
          ))}

          {autosDisponibles.length > 0 && (
            <SelectField
              label="Asignar auto"
              value={null}
              onChange={(v) => setDatos((d) => asignarChoferAuto(d, v as string, chofer.id))}
              options={autosDisponibles.map((a) => ({
                value: a.id,
                label: `${a.marca} ${a.modelo} - ${a.placa || 'sin placa'}`,
              }))}
            />
          )}
        </View>

        {/* Modales */}
        {editandoBasico && borrador && (
          <ModalEditarBasico
            borrador={borrador}
            setBorrador={setBorrador}
            onClose={() => {
              setEditandoBasico(false);
              setBorrador(null);
            }}
            onGuardar={guardarBasico}
          />
        )}
        {editandoDoc === 'cedula' && (
          <ModalCedula chofer={chofer} onClose={() => setEditandoDoc(null)} />
        )}
        {editandoDoc === 'licencia' && (
          <ModalLicencia chofer={chofer} onClose={() => setEditandoDoc(null)} />
        )}
      </ScrollView>
    </View>
  );
}

function ModalEditarBasico({
  borrador,
  setBorrador,
  onClose,
  onGuardar,
}: {
  borrador: Chofer;
  setBorrador: (c: Chofer) => void;
  onClose: () => void;
  onGuardar: () => void;
}) {
  return (
    <Portal>
      <Modal
        visible
        onDismiss={onClose}
        contentContainerStyle={styles.modalSheet}
      >
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitulo}>Editar datos del chofer</Text>
          <IconButton icon="close" onPress={onClose} />
        </View>
        <ScrollView>
          <FotoCapture
            foto={borrador.foto}
            carpeta="choferes"
            prefijo={`chofer_${borrador.id}`}
            etiqueta="Foto"
            onChange={(f) => setBorrador({ ...borrador, foto: f })}
            ratio={1}
          />
          <TextField
            label="Nombre"
            value={borrador.nombre}
            onChange={(v) => setBorrador({ ...borrador, nombre: v })}
          />
          <TextField
            label="Apellido"
            value={borrador.apellido}
            onChange={(v) => setBorrador({ ...borrador, apellido: v })}
          />
          <TextField
            label="Telefono"
            value={borrador.telefono}
            onChange={(v) => setBorrador({ ...borrador, telefono: v })}
            keyboardType="phone-pad"
          />
          <TextField
            label="Email"
            value={borrador.email}
            onChange={(v) => setBorrador({ ...borrador, email: v })}
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <DateField
            label="Fecha de nacimiento"
            value={borrador.fechaNacimiento ?? ''}
            onChange={(v) => setBorrador({ ...borrador, fechaNacimiento: v })}
          />
          <TextField
            label="Direccion"
            value={borrador.direccion ?? ''}
            onChange={(v) => setBorrador({ ...borrador, direccion: v })}
            multiline
          />
          <TextField
            label="Notas"
            value={borrador.notas}
            onChange={(v) => setBorrador({ ...borrador, notas: v })}
            multiline
          />
          <View style={styles.switchRow}>
            <Text style={{ flex: 1 }}>Activo</Text>
            <Switch
              value={borrador.activo}
              onValueChange={(v) => setBorrador({ ...borrador, activo: v })}
            />
          </View>
        </ScrollView>
        <View style={styles.rowBtns}>
          <Button mode="outlined" onPress={onClose}>
            Cancelar
          </Button>
          <Button mode="contained" onPress={onGuardar}>
            Guardar
          </Button>
        </View>
      </Modal>
    </Portal>
  );
}

function ModalCedula({ chofer, onClose }: { chofer: Chofer; onClose: () => void }) {
  const { setDatos } = useApp();
  const [v, setV] = useState<Cedula>(
    chofer.cedula ?? { numero: '', fechaEmision: '', fechaVencimiento: '' },
  );
  const [guardando, setGuardando] = useState(false);

  const onEmisionChange = (iso: string) => {
    const d = parseISO(iso);
    if (isValid(d) && chofer.fechaNacimiento) {
      const edad = differenceInYears(d, parseISO(chofer.fechaNacimiento));
      const meses =
        edad >= 70
          ? VIGENCIAS_PANAMA.cedulaIdentidad.mesesMayor70
          : VIGENCIAS_PANAMA.cedulaIdentidad.mesesMenor70;
      const next = addMonths(d, meses);
      setV({ ...v, fechaEmision: iso, fechaVencimiento: format(next, 'yyyy-MM-dd') });
    } else {
      setV({ ...v, fechaEmision: iso });
    }
  };

  const guardar = async () => {
    setGuardando(true);
    await setDatos((d) => actualizarChofer(d, chofer.id, { cedula: v }));
    setGuardando(false);
    onClose();
  };

  return (
    <Portal>
      <Modal visible onDismiss={onClose} contentContainerStyle={styles.modalSheet}>
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitulo}>Cedula</Text>
          <IconButton icon="close" onPress={onClose} />
        </View>
        <ScrollView>
          <TextField
            label="Numero"
            value={v.numero}
            onChange={(t) => setV({ ...v, numero: t })}
            placeholder="8-NNNN-NNN"
          />
          <DateField
            label="Fecha de emision"
            value={v.fechaEmision}
            onChange={onEmisionChange}
          />
          <DateField
            label="Fecha de vencimiento"
            value={v.fechaVencimiento}
            onChange={(t) => setV({ ...v, fechaVencimiento: t })}
            helper="Vigencia: 15 anos (30 si >=70). Decreto n.4/2021 - TE"
          />
          <FotoCapture
            foto={v.fotoFrontal}
            carpeta="documentos"
            prefijo={`cedula_${chofer.id}_frontal`}
            etiqueta="Foto frontal"
            onChange={(f) => setV({ ...v, fotoFrontal: f })}
          />
          <FotoCapture
            foto={v.fotoTrasera}
            carpeta="documentos"
            prefijo={`cedula_${chofer.id}_trasera`}
            etiqueta="Foto trasera"
            onChange={(f) => setV({ ...v, fotoTrasera: f })}
          />
        </ScrollView>
        <View style={styles.rowBtns}>
          <Button mode="outlined" onPress={onClose}>
            Cancelar
          </Button>
          <Button mode="contained" onPress={guardar} loading={guardando}>
            Guardar
          </Button>
        </View>
      </Modal>
    </Portal>
  );
}

function ModalLicencia({ chofer, onClose }: { chofer: Chofer; onClose: () => void }) {
  const { setDatos } = useApp();
  const [v, setV] = useState<LicenciaConducir>(
    chofer.licenciaConducir ?? {
      numero: '',
      categoria: 'B',
      fechaEmision: '',
      fechaVencimiento: '',
    },
  );
  const [guardando, setGuardando] = useState(false);

  const onEmisionChange = (iso: string) => {
    const d = parseISO(iso);
    if (isValid(d) && chofer.fechaNacimiento) {
      const edad = differenceInYears(d, parseISO(chofer.fechaNacimiento));
      const meses =
        edad >= 70
          ? VIGENCIAS_PANAMA.licenciaConducir.mesesMayor70
          : VIGENCIAS_PANAMA.licenciaConducir.mesesMenor70;
      const next = addMonths(d, meses);
      setV({ ...v, fechaEmision: iso, fechaVencimiento: format(next, 'yyyy-MM-dd') });
    } else {
      setV({ ...v, fechaEmision: iso });
    }
  };

  const guardar = async () => {
    setGuardando(true);
    await setDatos((d) => actualizarChofer(d, chofer.id, { licenciaConducir: v }));
    setGuardando(false);
    onClose();
  };

  return (
    <Portal>
      <Modal visible onDismiss={onClose} contentContainerStyle={styles.modalSheet}>
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitulo}>Licencia de conducir</Text>
          <IconButton icon="close" onPress={onClose} />
        </View>
        <ScrollView>
          <TextField
            label="Numero"
            value={v.numero}
            onChange={(t) => setV({ ...v, numero: t })}
          />
          <SelectField
            label="Categoria"
            value={v.categoria}
            onChange={(c) => setV({ ...v, categoria: c as CategoriaLicencia })}
            options={CATEGORIAS_LICENCIA.map((c) => ({ value: c.value, label: c.label }))}
          />
          <DateField
            label="Fecha de emision"
            value={v.fechaEmision}
            onChange={onEmisionChange}
          />
          <DateField
            label="Fecha de vencimiento"
            value={v.fechaVencimiento}
            onChange={(t) => setV({ ...v, fechaVencimiento: t })}
            helper="Vigencia: 4 anos (2 si >=70). Reglamento ATTT/Sertracen"
          />
          <FotoCapture
            foto={v.fotoFrontal}
            carpeta="documentos"
            prefijo={`lic_${chofer.id}_frontal`}
            etiqueta="Foto frontal"
            onChange={(f) => setV({ ...v, fotoFrontal: f })}
          />
          <FotoCapture
            foto={v.fotoTrasera}
            carpeta="documentos"
            prefijo={`lic_${chofer.id}_trasera`}
            etiqueta="Foto trasera"
            onChange={(f) => setV({ ...v, fotoTrasera: f })}
          />
        </ScrollView>
        <View style={styles.rowBtns}>
          <Button mode="outlined" onPress={onClose}>
            Cancelar
          </Button>
          <Button mode="contained" onPress={guardar} loading={guardando}>
            Guardar
          </Button>
        </View>
      </Modal>
    </Portal>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  scroll: { paddingBottom: 64 },
  header: {
    padding: ESPACIADO.marginMobile,
    backgroundColor: PALETA.surfaceContainerLowest,
    alignItems: 'center',
    gap: 6,
  },
  foto: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: PALETA.surfaceContainer,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    marginBottom: 8,
  },
  fotoImg: { width: '100%', height: '100%' },
  headerTitulo: { ...TIPO.headlineMd, color: PALETA.primary },
  headerSub: {
    ...TIPO.bodyMd,
    color: PALETA.primary,
    textDecorationLine: 'underline',
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: ESPACIADO.gutter,
    marginTop: ESPACIADO.gutter,
  },
  cardCol: {
    padding: ESPACIADO.marginMobile,
    gap: ESPACIADO.gutter,
  },
  subSeccion: {
    ...TIPO.titleLg,
    color: PALETA.onSurface,
    fontSize: 16,
    marginTop: ESPACIADO.gutter,
  },
  placeholderTxt: { ...TIPO.bodyMd, color: PALETA.outline, fontStyle: 'italic' },
  linkExt: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: -8,
    marginBottom: 8,
    paddingHorizontal: 4,
  },
  linkExtTxt: { ...TIPO.labelLg, color: PALETA.primary },
  autoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    paddingLeft: ESPACIADO.cardPadding,
    elevation: 1,
  },
  autoTxt: { ...TIPO.bodyLg, color: PALETA.onSurface },
  modalSheet: {
    backgroundColor: PALETA.background,
    margin: 16,
    borderRadius: RADIO.lg,
    padding: ESPACIADO.cardPadding,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  modalTitulo: { ...TIPO.titleLg, color: PALETA.primary, flex: 1 },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  rowBtns: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: ESPACIADO.gutter,
    marginTop: ESPACIADO.stackMd,
  },
});
