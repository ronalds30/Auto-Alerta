// AutoAlerta - Root layout (tema oscuro Claude Design)
import { useEffect } from 'react';
import { View } from 'react-native';
import { Stack } from 'expo-router';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { PaperProvider } from 'react-native-paper';
import { StatusBar } from 'expo-status-bar';
import * as Notifications from 'expo-notifications';
import { useRouter } from 'expo-router';
import { useFonts, BebasNeue_400Regular } from '@expo-google-fonts/bebas-neue';
import {
  Rajdhani_500Medium,
  Rajdhani_600SemiBold,
  Rajdhani_700Bold,
} from '@expo-google-fonts/rajdhani';
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_700Bold,
} from '@expo-google-fonts/dm-sans';
import {
  JetBrainsMono_400Regular,
  JetBrainsMono_500Medium,
  JetBrainsMono_700Bold,
} from '@expo-google-fonts/jetbrains-mono';

import { AppProvider } from '@/hooks/AppContext';
import { TEMA_OSCURO, PALETA } from '@/constants/tema';

export default function RootLayout() {
  const router = useRouter();

  // Cargamos las fuentes del design system con los nombres semanticos que usa
  // tema.ts (FUENTES.display / heading / body / mono). Si fallan se usa system font.
  const [fontsLoaded] = useFonts({
    BebasNeue: BebasNeue_400Regular,
    Rajdhani: Rajdhani_600SemiBold,
    'Rajdhani-Medium': Rajdhani_500Medium,
    'Rajdhani-Bold': Rajdhani_700Bold,
    DMSans: DMSans_400Regular,
    'DMSans-Medium': DMSans_500Medium,
    'DMSans-Bold': DMSans_700Bold,
    JetBrainsMono: JetBrainsMono_400Regular,
    'JetBrainsMono-Medium': JetBrainsMono_500Medium,
    'JetBrainsMono-Bold': JetBrainsMono_700Bold,
  });

  // Tap en notificacion -> abre la ruta correspondiente.
  useEffect(() => {
    const sub = Notifications.addNotificationResponseReceivedListener((resp) => {
      const data = resp.notification.request.content.data as { rutaDetalle?: string };
      if (data?.rutaDetalle) {
        router.push(data.rutaDetalle as never);
      }
    });
    return () => sub.remove();
  }, [router]);

  // Mientras las fuentes cargan, pintamos solo el fondo navy para evitar flash blanco.
  if (!fontsLoaded) {
    return <View style={{ flex: 1, backgroundColor: PALETA.background }} />;
  }

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: PALETA.background }}>
      <SafeAreaProvider>
        <PaperProvider theme={TEMA_OSCURO}>
          <AppProvider>
            <StatusBar style="light" backgroundColor={PALETA.background} />
            <Stack
              screenOptions={{
                headerShown: false,
                contentStyle: { backgroundColor: PALETA.background },
                headerStyle: { backgroundColor: PALETA.background },
                headerTintColor: PALETA.onSurface,
              }}
            >
              <Stack.Screen name="index" />
              <Stack.Screen name="(auth)" />
              <Stack.Screen name="(tabs)" />
              <Stack.Screen
                name="auto/[id]"
                options={{ headerShown: true, title: 'Auto' }}
              />
              <Stack.Screen
                name="auto/nuevo"
                options={{
                  headerShown: true,
                  title: 'Nuevo auto',
                  presentation: 'modal',
                }}
              />
              <Stack.Screen
                name="chofer/[id]"
                options={{ headerShown: true, title: 'Chofer' }}
              />
              <Stack.Screen
                name="chofer/nuevo"
                options={{
                  headerShown: true,
                  title: 'Nuevo chofer',
                  presentation: 'modal',
                }}
              />
            </Stack>
          </AppProvider>
        </PaperProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
