// AutoAlerta - Welcome / Login (tema oscuro Claude Design)
import { useState } from 'react';
import { View, StyleSheet, Alert, ScrollView } from 'react-native';
import { Button, Text, ActivityIndicator } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

import { useApp } from '@/hooks/AppContext';
import { loginConGoogle, oauthConfigurado } from '@/services/googleAuth';
import { PALETA, DS, ESPACIADO, TIPO, RADIO } from '@/constants/tema';

export default function Welcome() {
  const router = useRouter();
  const { iniciarSesion } = useApp();
  const [cargando, setCargando] = useState(false);
  const [configError, setConfigError] = useState<string | null>(null);

  const onLogin = async () => {
    if (!oauthConfigurado) {
      Alert.alert(
        'Configuracion pendiente',
        'Las credenciales OAuth de Google no estan configuradas (falta webClientId). Revisa README_OAUTH.md.',
      );
      return;
    }
    try {
      setCargando(true);
      setConfigError(null);
      const sesion = await loginConGoogle();
      await iniciarSesion(sesion.usuario);
      router.replace('/(tabs)');
    } catch (err: any) {
      if (err.code === 'SIGN_IN_CANCELLED') {
        return;
      }
      setConfigError(err?.message ?? 'Error desconocido');
      Alert.alert('Error al iniciar sesión', err?.message ?? 'No se pudo iniciar sesion con Google');
    } finally {
      setCargando(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Ilustracion */}
      <View style={styles.hero}>
        <View style={styles.heroBg}>
          <MaterialCommunityIcons name="car-cog" size={120} color={PALETA.primary} />
          <View style={styles.fabHero}>
            <MaterialCommunityIcons name="shield-check" size={32} color={DS.navy900} />
          </View>
        </View>
      </View>

      {/* Textos */}
      <View style={styles.contenido}>
        <Text style={styles.titulo}>AUTOALERTA</Text>
        <Text style={styles.subtitulo}>
          Registra tus autos y documentos. Te avisamos antes de que venzan.
        </Text>

        {/* Onboarding inline (3 puntos) */}
        <View style={styles.featureList}>
          <Feature icono="car-multiple" texto="Hasta 10 vehiculos y choferes" />
          <Feature icono="bell-ring" texto="Alertas de licencia, calcomania y mas" />
          <Feature icono="cloud-lock" texto="Tus datos en tu Google Drive" />
        </View>

        {/* Boton Google */}
        <Button
          mode="contained"
          onPress={onLogin}
          loading={cargando}
          disabled={cargando}
          icon={({ size }) => (
            <MaterialCommunityIcons name="google" size={size} color={DS.navy900} />
          )}
          contentStyle={styles.btnContent}
          style={styles.btnGoogle}
          labelStyle={styles.btnLabel}
          buttonColor="#FFFFFF"
          textColor={DS.navy900}
        >
          Continuar con Google
        </Button>

        {(configError || !oauthConfigurado) && (
          <Text style={styles.aviso}>
            {configError ?? 'OAuth no configurado. Ver README_OAUTH.md para activarlo.'}
          </Text>
        )}

        <View style={styles.privacidadRow}>
          <MaterialCommunityIcons name="cloud-check" size={16} color={DS.muted} />
          <Text style={styles.privacidad}>
            Tus datos se guardan en tu propio Google Drive
          </Text>
        </View>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerTxt}>
          by Technology Solutions and Services (TSS PTY)
        </Text>
        <Text style={styles.footerSub}>TECHSSPTY.COM</Text>
      </View>
    </ScrollView>
  );
}

function Feature({ icono, texto }: { icono: any; texto: string }) {
  return (
    <View style={styles.featureRow}>
      <MaterialCommunityIcons name={icono} size={22} color={PALETA.primary} />
      <Text style={styles.featureTxt}>{texto}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: DS.navy900,
    paddingHorizontal: ESPACIADO.marginMobile,
    paddingBottom: ESPACIADO.stackLg,
    paddingTop: 48,
  },
  hero: { alignItems: 'center', marginTop: ESPACIADO.stackLg },
  heroBg: {
    width: 200,
    height: 200,
    borderRadius: RADIO.full,
    backgroundColor: DS.surface2,
    borderWidth: 1.5,
    borderColor: DS.borderStrong,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: ESPACIADO.stackLg,
  },
  fabHero: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    backgroundColor: PALETA.primary,
    padding: 10,
    borderRadius: RADIO.full,
    elevation: 6,
  },
  contenido: { flex: 1, alignItems: 'center' },
  titulo: {
    ...TIPO.displayLg,
    color: PALETA.onSurface,
    letterSpacing: 3,
    textAlign: 'center',
    marginBottom: ESPACIADO.base,
  },
  subtitulo: {
    ...TIPO.bodyLg,
    color: DS.muted,
    textAlign: 'center',
    maxWidth: 320,
    marginBottom: ESPACIADO.stackLg,
  },
  featureList: {
    width: '100%',
    gap: ESPACIADO.gutter,
    marginBottom: ESPACIADO.stackLg,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: ESPACIADO.gutter,
    backgroundColor: DS.surface1,
    padding: ESPACIADO.cardPadding,
    borderRadius: RADIO.lg,
    borderLeftWidth: 3,
    borderLeftColor: PALETA.primary,
    borderTopWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderTopColor: DS.border,
    borderRightColor: DS.border,
    borderBottomColor: DS.border,
  },
  featureTxt: { ...TIPO.bodyMd, color: PALETA.onSurface, flex: 1 },
  btnGoogle: {
    width: '100%',
    borderRadius: RADIO.lg,
    marginTop: ESPACIADO.base,
    elevation: 4,
  },
  btnContent: { height: 52 },
  btnLabel: { ...TIPO.titleMd, color: DS.navy900 },
  aviso: {
    ...TIPO.labelLg,
    color: PALETA.error,
    marginTop: ESPACIADO.base,
    textAlign: 'center',
  },
  privacidadRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: ESPACIADO.stackMd,
  },
  privacidad: { ...TIPO.labelLg, color: DS.muted },
  footer: { alignItems: 'center', marginTop: ESPACIADO.stackLg, gap: 4 },
  footerTxt: { ...TIPO.labelLg, color: DS.muted },
  footerSub: { ...TIPO.labelSm, color: PALETA.primary, letterSpacing: 1.5 },
});
