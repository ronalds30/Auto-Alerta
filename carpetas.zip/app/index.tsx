// AutoAlerta - Splash + decision de ruta inicial
import { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { ActivityIndicator, Text } from 'react-native-paper';
import { Redirect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '@/hooks/AppContext';
import { PALETA, DS, ESPACIADO, TIPO } from '@/constants/tema';

export default function Index() {
  const { autenticado, cargandoSesion } = useApp();

  if (cargandoSesion) {
    return (
      <View style={styles.splash}>
        <View style={styles.iconWrap}>
          <MaterialCommunityIcons name="car-connected" size={80} color={PALETA.primary} />
        </View>
        <Text style={styles.titulo}>AUTOALERTA</Text>
        <Text style={styles.subtitulo}>Maneja con control, conduce tranquilo</Text>
        <View style={styles.loader}>
          <ActivityIndicator size="small" color={PALETA.primary} />
        </View>
        <Text style={styles.footer}>by Technology Solutions and Services (TSS PTY)</Text>
      </View>
    );
  }

  return <Redirect href={autenticado ? '/(tabs)' : '/(auth)/welcome'} />;
}

const styles = StyleSheet.create({
  splash: {
    flex: 1,
    backgroundColor: DS.navy900,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: ESPACIADO.marginMobile,
  },
  iconWrap: {
    width: 128,
    height: 128,
    borderRadius: 64,
    backgroundColor: DS.surface2,
    borderWidth: 1.5,
    borderColor: PALETA.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: ESPACIADO.stackLg,
  },
  titulo: {
    ...TIPO.displayLg,
    color: PALETA.onSurface,
    letterSpacing: 4,
    marginBottom: ESPACIADO.base,
  },
  subtitulo: {
    ...TIPO.bodyLg,
    color: DS.muted,
    textAlign: 'center',
  },
  loader: {
    marginTop: ESPACIADO.stackLg * 2,
  },
  footer: {
    ...TIPO.labelLg,
    color: DS.dim,
    position: 'absolute',
    bottom: 48,
  },
});
