// AutoAlerta - Tabs principales (tema oscuro Claude Design)
import { Tabs, Redirect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '@/hooks/AppContext';
import { PALETA, DS, FUENTES } from '@/constants/tema';

export default function TabsLayout() {
  const { autenticado, cargandoSesion } = useApp();
  const insets = useSafeAreaInsets();

  if (cargandoSesion) return null;
  if (!autenticado) return <Redirect href="/(auth)/welcome" />;

  const bottomInset = Math.max(insets.bottom, 8);

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: PALETA.primary,
        tabBarInactiveTintColor: DS.muted,
        tabBarStyle: {
          backgroundColor: DS.navy900,
          borderTopColor: DS.border,
          height: 56 + bottomInset,
          paddingBottom: bottomInset,
          paddingTop: 6,
        },
        tabBarItemStyle: { paddingVertical: 4 },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '700',
          fontFamily: FUENTES.heading,
          letterSpacing: 0.4,
          marginTop: 2,
        },
        tabBarIconStyle: { marginBottom: 0 },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Inicio',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="view-dashboard" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="autos"
        options={{
          title: 'Mis autos',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="car-multiple" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="choferes"
        options={{
          title: 'Choferes',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="account-group" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="reportes"
        options={{
          title: 'Reportes',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="chart-line" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="config"
        options={{
          title: 'Ajustes',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="cog" size={size} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}
