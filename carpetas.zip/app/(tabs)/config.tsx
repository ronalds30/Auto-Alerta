// AutoAlerta - Configuracion
import { useState } from 'react';
import {
  ScrollView,
  StyleSheet,
  View,
  Linking,
  Alert,
  Pressable,
} from 'react-native';
import {
  Text,
  Button,
  Switch,
  Divider,
  List,
  ActivityIndicator,
} from 'react-native-paper';
import { useRouter } from 'expo-router';
import { useApp } from '@/hooks/AppContext';
import { actualizarPerfil, actualizarPreferencias } from '@/services/mutations';
import { obtenerUrlCarpetaDrive } from '@/services/googleDrive';
import { TextField } from '@/components/Form';
import { SyncIndicator } from '@/components/SyncIndicator';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';

export default function Config() {
  const router = useRouter();
  const { usuario, datos, setDatos, sincronizar, cerrarSesion, syncStatus } = useApp();
  const [edit, setEdit] = useState(false);
  const [nombre, setNombre] = useState(usuario?.nombre ?? '');
  const [telefono, setTelefono] = useState(datos?.usuario.telefono ?? '');
  const [cerrando, setCerrando] = useState(false);

  if (!datos || !usuario) {
    return (
      <View style={styles.center}>
        <ActivityIndicator />
      </View>
    );
  }

  const prefs = datos.preferencias;

  const guardarPerfil = async () => {
    await setDatos((d) => actualizarPerfil(d, { nombre, telefono }));
    setEdit(false);
  };

  const togglePref = async (k: keyof typeof prefs, v: any) => {
    await setDatos((d) => actualizarPreferencias(d, { [k]: v }));
  };

  const abrirDrive = async () => {
    const url = await obtenerUrlCarpetaDrive();
    if (url) await Linking.openURL(url);
    else Alert.alert('Drive', 'Aun no hay carpeta creada. Sincroniza primero.');
  };

  const onCerrar = () => {
    Alert.alert(
      'Cerrar sesion',
      'Esto borrara tu sesion local. Tus datos en Drive permanecen intactos.',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Cerrar sesion',
          style: 'destructive',
          onPress: async () => {
            setCerrando(true);
            await cerrarSesion();
            router.replace('/(auth)/welcome');
          },
        },
      ],
    );
  };

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.contenido}>
      <Text style={styles.titulo}>Configuracion</Text>
      <SyncIndicator />

      {/* PERFIL */}
      <Text style={styles.seccion}>Perfil</Text>
      <View style={styles.card}>
        {!edit ? (
          <>
            <Row label="Nombre" value={datos.usuario.nombre} />
            <Row label="Email" value={datos.usuario.email} />
            <Row label="Telefono" value={datos.usuario.telefono || '-'} />
            <Button mode="contained-tonal" icon="pencil" onPress={() => setEdit(true)}>
              Editar
            </Button>
          </>
        ) : (
          <>
            <TextField label="Nombre" value={nombre} onChange={setNombre} />
            <TextField
              label="Telefono"
              value={telefono}
              onChange={setTelefono}
              keyboardType="phone-pad"
            />
            <View style={styles.btnRow}>
              <Button mode="outlined" onPress={() => setEdit(false)}>
                Cancelar
              </Button>
              <Button mode="contained" onPress={guardarPerfil}>
                Guardar
              </Button>
            </View>
          </>
        )}
      </View>

      {/* DRIVE */}
      <Text style={styles.seccion}>Almacenamiento</Text>
      <View style={styles.card}>
        <List.Item
          title="Sincronizar con Drive"
          description={
            syncStatus.estado === 'sincronizando' ? 'Sincronizando...' : 'Forzar lectura desde Drive'
          }
          left={(p) => <List.Icon {...p} icon="cloud-sync" />}
          onPress={sincronizar}
          right={(p) =>
            syncStatus.estado === 'sincronizando' ? (
              <ActivityIndicator />
            ) : (
              <List.Icon {...p} icon="chevron-right" />
            )
          }
        />
        <Divider />
        <List.Item
          title="Abrir carpeta en Drive"
          description="Ver tus archivos en el navegador"
          left={(p) => <List.Icon {...p} icon="folder-open" />}
          right={(p) => <List.Icon {...p} icon="open-in-new" />}
          onPress={abrirDrive}
        />
      </View>

      {/* NOTIFICACIONES */}
      <Text style={styles.seccion}>Notificaciones</Text>
      <View style={styles.card}>
        <View style={styles.switchRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.optTitulo}>Notificaciones activas</Text>
            <Text style={styles.optDesc}>
              Alertas locales de vencimiento de documentos y mantenimientos
            </Text>
          </View>
          <Switch
            value={prefs.notificacionesActivas}
            onValueChange={(v) => togglePref('notificacionesActivas', v)}
          />
        </View>
        <Divider />
        <PrefDias
          label="Calcomania"
          values={prefs.diasAlertaCalcomania}
          onChange={(v) => togglePref('diasAlertaCalcomania', v)}
        />
        <PrefDias
          label="Poliza"
          values={prefs.diasAlertaPoliza}
          onChange={(v) => togglePref('diasAlertaPoliza', v)}
        />
        <PrefDias
          label="Revisado vehicular"
          values={prefs.diasAlertaRevisado}
          onChange={(v) => togglePref('diasAlertaRevisado', v)}
        />
        <PrefDias
          label="Placa metalica"
          values={prefs.diasAlertaPlacaMetalica}
          onChange={(v) => togglePref('diasAlertaPlacaMetalica', v)}
        />
        <PrefDias
          label="Licencia"
          values={prefs.diasAlertaLicencia}
          onChange={(v) => togglePref('diasAlertaLicencia', v)}
        />
        <PrefDias
          label="Cedula"
          values={prefs.diasAlertaCedula}
          onChange={(v) => togglePref('diasAlertaCedula', v)}
        />
      </View>

      {/* INFO LEGAL */}
      <Text style={styles.seccion}>Info</Text>
      <View style={styles.card}>
        <List.Item
          title="ATTT (transito)"
          description="attt.gob.pa"
          left={(p) => <List.Icon {...p} icon="car-info" />}
          onPress={() => Linking.openURL('https://attt.gob.pa')}
        />
        <Divider />
        <List.Item
          title="Tribunal Electoral (cedula)"
          description="tribunalcontigo.com"
          left={(p) => <List.Icon {...p} icon="card-account-details" />}
          onPress={() => Linking.openURL('https://tribunalcontigo.com')}
        />
        <Divider />
        <List.Item
          title="Sertracen (licencia)"
          description="sertracen.com.pa"
          left={(p) => <List.Icon {...p} icon="card-bulleted" />}
          onPress={() => Linking.openURL('https://sertracen.com.pa')}
        />
      </View>

      {/* SESION */}
      <Button
        mode="outlined"
        icon="logout"
        onPress={onCerrar}
        loading={cerrando}
        disabled={cerrando}
        style={styles.btnCerrar}
        contentStyle={styles.btnCerrarContent}
        textColor={PALETA.error}
        compact
      >
        Cerrar sesion
      </Button>

      <View style={styles.brand}>
        <Text style={styles.brandTit}>AutoAlerta v1.0.0</Text>
        <Text style={styles.brandSub}>
          by Technology Solutions and Services (TSS PTY)
        </Text>
        <Pressable onPress={() => Linking.openURL('https://techsspty.com')}>
          <Text style={styles.brandLink}>TECHSSPTY.COM</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={styles.rowValue}>{value}</Text>
    </View>
  );
}

function PrefDias({
  label,
  values,
  onChange,
}: {
  label: string;
  values: number[];
  onChange: (v: number[]) => void;
}) {
  const [txt, setTxt] = useState(values.join(', '));
  return (
    <View style={{ padding: ESPACIADO.cardPadding }}>
      <Text style={styles.optTitulo}>{label}</Text>
      <Text style={styles.optDesc}>Dias de aviso (separar por coma)</Text>
      <TextField
        label=""
        value={txt}
        onChange={(t) => {
          setTxt(t);
          const arr = t
            .split(',')
            .map((s) => parseInt(s.trim(), 10))
            .filter((n) => Number.isFinite(n) && n > 0);
          if (arr.length > 0) onChange(arr);
        }}
        placeholder="30, 15, 7"
        keyboardType="numeric"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: PALETA.background },
  contenido: { padding: ESPACIADO.marginMobile, paddingBottom: 96 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  titulo: { ...TIPO.headlineMd, color: PALETA.primary, marginBottom: 4 },
  seccion: {
    ...TIPO.titleLg,
    color: PALETA.onSurface,
    fontSize: 16,
    marginTop: ESPACIADO.stackMd,
    marginBottom: ESPACIADO.gutter,
  },
  card: {
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    padding: ESPACIADO.cardPadding,
    elevation: 1,
    gap: 4,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: PALETA.outlineVariant,
  },
  rowLabel: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant },
  rowValue: { ...TIPO.bodyLg, color: PALETA.onSurface, maxWidth: '60%', textAlign: 'right' },
  btnRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: ESPACIADO.gutter,
    marginTop: ESPACIADO.gutter,
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: ESPACIADO.cardPadding,
  },
  optTitulo: { ...TIPO.bodyLg, color: PALETA.onSurface, fontWeight: '600' as const },
  optDesc: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant, marginBottom: 4 },
  btnCerrar: {
    marginTop: ESPACIADO.stackLg,
    borderColor: PALETA.error,
    borderWidth: 1.5,
    alignSelf: 'center',
    minWidth: 200,
  },
  btnCerrarContent: { height: 40, paddingHorizontal: 12 },
  brand: { alignItems: 'center', marginTop: ESPACIADO.stackLg, gap: 4 },
  brandTit: { ...TIPO.labelLg, color: PALETA.outline },
  brandSub: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant },
  brandLink: { ...TIPO.labelSm, color: PALETA.primary, marginTop: 4 },
});
