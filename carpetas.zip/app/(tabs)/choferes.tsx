// AutoAlerta - Lista de choferes
import { View, StyleSheet, ScrollView, Pressable, Image } from 'react-native';
import { Text, FAB } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useMemo } from 'react';
import { useApp } from '@/hooks/AppContext';
import { calcularAlertasChofer } from '@/services/alertEngine';
import { EmptyState } from '@/components/EmptyState';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';
import type { Chofer } from '@/types';

export default function ChoferesList() {
  const router = useRouter();
  const { datos } = useApp();
  const choferes = datos?.choferes ?? [];

  return (
    <View style={styles.root}>
      <View style={styles.headerBar}>
        <Text style={styles.headerTxt}>Mis choferes</Text>
        <Text style={styles.subTxt}>
          {choferes.filter((c) => c.activo).length} activo
          {choferes.filter((c) => c.activo).length === 1 ? '' : 's'}
        </Text>
      </View>

      {choferes.length === 0 ? (
        <EmptyState
          icono="account-group"
          titulo="Sin choferes aun"
          descripcion="Agrega un chofer para trackear cedula y licencia."
          ctaLabel="Agregar chofer"
          onCta={() => router.push('/chofer/nuevo')}
        />
      ) : (
        <ScrollView contentContainerStyle={styles.lista}>
          {choferes.map((c) => (
            <ChoferItem
              key={c.id}
              chofer={c}
              onPress={() => router.push(`/chofer/${c.id}`)}
            />
          ))}
        </ScrollView>
      )}

      <FAB
        icon="plus"
        style={styles.fab}
        color="#fff"
        onPress={() => router.push('/chofer/nuevo')}
      />
    </View>
  );
}

function ChoferItem({ chofer, onPress }: { chofer: Chofer; onPress: () => void }) {
  const alertas = useMemo(() => calcularAlertasChofer(chofer), [chofer]);
  const peor = useMemo(() => {
    if (alertas.some((a) => a.severidad === 'vencido')) return PALETA.semaforo.vencido;
    if (alertas.some((a) => a.severidad === 'urgente')) return PALETA.semaforo.urgente;
    if (alertas.some((a) => a.severidad === 'proximo')) return PALETA.semaforo.proximo;
    return PALETA.semaforo.aldia;
  }, [alertas]);

  return (
    <Pressable
      onPress={onPress}
      style={[styles.item, { borderLeftColor: peor }, !chofer.activo && { opacity: 0.6 }]}
    >
      <View style={styles.foto}>
        {chofer.foto?.uri ? (
          <Image source={{ uri: chofer.foto.uri }} style={styles.fotoImg} />
        ) : (
          <MaterialCommunityIcons name="account" size={36} color={PALETA.outline} />
        )}
      </View>
      <View style={styles.itemBody}>
        <Text style={styles.titulo}>
          {chofer.nombre} {chofer.apellido}
        </Text>
        {chofer.telefono ? (
          <Text style={styles.sub}>{chofer.telefono}</Text>
        ) : null}
        {chofer.licenciaConducir ? (
          <Text style={styles.licencia}>
            Lic. Cat. {chofer.licenciaConducir.categoria}
          </Text>
        ) : (
          <Text style={styles.licenciaSin}>Sin licencia registrada</Text>
        )}
      </View>
      <View style={styles.chevron}>
        {alertas.filter((a) => a.severidad !== 'aldia').length > 0 && (
          <View style={[styles.badge, { backgroundColor: peor }]}>
            <Text style={styles.badgeTxt}>
              {alertas.filter((a) => a.severidad !== 'aldia').length}
            </Text>
          </View>
        )}
        <MaterialCommunityIcons name="chevron-right" size={24} color={PALETA.outline} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: PALETA.background },
  headerBar: {
    paddingHorizontal: ESPACIADO.marginMobile,
    paddingTop: ESPACIADO.stackLg,
    paddingBottom: ESPACIADO.gutter,
  },
  headerTxt: { ...TIPO.headlineMd, color: PALETA.primary },
  subTxt: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant },
  lista: { padding: ESPACIADO.marginMobile, paddingBottom: 96, gap: ESPACIADO.gutter },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    borderLeftWidth: 3,
    padding: ESPACIADO.cardPadding,
    gap: ESPACIADO.gutter,
    elevation: 1,
  },
  foto: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: PALETA.surfaceContainer,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  fotoImg: { width: '100%', height: '100%' },
  itemBody: { flex: 1 },
  titulo: { ...TIPO.titleLg, color: PALETA.onSurface, fontSize: 16 },
  sub: { ...TIPO.bodyMd, color: PALETA.onSurfaceVariant },
  licencia: { ...TIPO.labelLg, color: PALETA.primary, marginTop: 2 },
  licenciaSin: { ...TIPO.labelLg, color: PALETA.outline, marginTop: 2 },
  chevron: { alignItems: 'center', gap: 4 },
  badge: {
    borderRadius: RADIO.full,
    paddingHorizontal: 8,
    paddingVertical: 2,
    minWidth: 24,
    alignItems: 'center',
  },
  badgeTxt: { ...TIPO.labelSm, color: '#fff' },
  fab: {
    position: 'absolute',
    right: 16,
    bottom: 16,
    backgroundColor: PALETA.secondaryContainer,
  },
});
