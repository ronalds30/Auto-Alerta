// AutoAlerta - Dashboard (Inicio)
import { ScrollView, StyleSheet, View, RefreshControl, Pressable } from 'react-native';
import { Text, ActivityIndicator } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useMemo, useState, useCallback } from 'react';
import { useApp } from '@/hooks/AppContext';
import { AlertGroup } from '@/components/AlertBanner';
import { SyncIndicator } from '@/components/SyncIndicator';
import { agruparPorSeveridad } from '@/services/alertEngine';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';

export default function Dashboard() {
  const router = useRouter();
  const { usuario, datos, alertas, cargandoDatos, sincronizar } = useApp();
  const [refreshing, setRefreshing] = useState(false);

  const grupos = useMemo(() => agruparPorSeveridad(alertas), [alertas]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await sincronizar();
    setRefreshing(false);
  }, [sincronizar]);

  if (cargandoDatos && !datos) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={PALETA.primary} />
        <Text style={{ marginTop: 12 }}>Cargando tus datos desde Drive...</Text>
      </View>
    );
  }

  const totalAutos = datos?.autos.length ?? 0;
  const totalChoferes = datos?.choferes.filter((c) => c.activo).length ?? 0;

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={styles.contenido}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.hola}>Hola, {usuario?.nombre.split(' ')[0] ?? ''}</Text>
          <SyncIndicator />
        </View>
        <Pressable
          onPress={() => router.push('/(tabs)/config')}
          style={styles.avatarBtn}
        >
          <MaterialCommunityIcons name="account-circle" size={36} color={PALETA.primary} />
        </Pressable>
      </View>

      {/* KPIs */}
      <View style={styles.kpiRow}>
        <KPI
          icono="car-multiple"
          valor={totalAutos}
          label="Autos"
          onPress={() => router.push('/(tabs)/autos')}
        />
        <KPI
          icono="account-group"
          valor={totalChoferes}
          label="Choferes"
          onPress={() => router.push('/(tabs)/choferes')}
        />
        <KPI
          icono="bell-alert"
          valor={grupos.vencido.length + grupos.urgente.length}
          label="Atencion"
          destacado
        />
      </View>

      {/* Alertas */}
      <Text style={styles.seccion}>Estado de tus documentos</Text>

      {alertas.length === 0 && (
        <View style={styles.vacio}>
          <MaterialCommunityIcons
            name="check-decagram"
            size={56}
            color={PALETA.semaforo.aldia}
          />
          <Text style={styles.vacioTxt}>Todo en orden</Text>
          <Text style={styles.vacioSub}>
            No tienes documentos por vencer. Agrega un auto o chofer para empezar.
          </Text>
        </View>
      )}

      <AlertGroup severidad="vencido" alertas={grupos.vencido} />
      <AlertGroup severidad="urgente" alertas={grupos.urgente} />
      <AlertGroup severidad="proximo" alertas={grupos.proximo} />

      {/* Acciones rapidas */}
      <Text style={styles.seccion}>Acciones rapidas</Text>
      <View style={styles.accionRow}>
        <AccionCard
          icono="car-arrow-right"
          label="Agregar auto"
          onPress={() => router.push('/auto/nuevo')}
        />
        <AccionCard
          icono="account-plus"
          label="Agregar chofer"
          onPress={() => router.push('/chofer/nuevo')}
        />
        <AccionCard
          icono="chart-bar"
          label="Ver reportes"
          onPress={() => router.push('/(tabs)/reportes')}
        />
      </View>
    </ScrollView>
  );
}

function KPI({
  icono,
  valor,
  label,
  onPress,
  destacado,
}: {
  icono: any;
  valor: number;
  label: string;
  onPress?: () => void;
  destacado?: boolean;
}) {
  const Comp = onPress ? Pressable : View;
  return (
    <Comp onPress={onPress} style={styles.kpi}>
      <View
        style={[
          styles.kpiIcon,
          destacado && { backgroundColor: PALETA.secondaryContainer },
        ]}
      >
        <MaterialCommunityIcons
          name={icono}
          size={22}
          color={destacado ? '#ffffff' : PALETA.primary}
        />
      </View>
      <Text style={styles.kpiValor}>{valor}</Text>
      <Text style={styles.kpiLabel}>{label}</Text>
    </Comp>
  );
}

function AccionCard({
  icono,
  label,
  onPress,
}: {
  icono: any;
  label: string;
  onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={styles.accion}>
      <MaterialCommunityIcons name={icono} size={28} color={PALETA.primary} />
      <Text style={styles.accionTxt}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: PALETA.background },
  contenido: { padding: ESPACIADO.marginMobile, paddingBottom: 80 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: ESPACIADO.stackMd,
  },
  hola: { ...TIPO.headlineMd, color: PALETA.primary, marginBottom: 4 },
  avatarBtn: { padding: 4 },
  kpiRow: {
    flexDirection: 'row',
    gap: ESPACIADO.gutter,
    marginBottom: ESPACIADO.stackMd,
  },
  kpi: {
    flex: 1,
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    padding: ESPACIADO.cardPadding,
    alignItems: 'center',
    gap: 4,
    elevation: 1,
  },
  kpiIcon: {
    width: 40,
    height: 40,
    borderRadius: RADIO.full,
    backgroundColor: 'rgba(255,111,0,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  kpiValor: { ...TIPO.headlineMd, color: PALETA.onSurface },
  kpiLabel: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant },
  seccion: {
    ...TIPO.titleLg,
    color: PALETA.onSurface,
    marginTop: ESPACIADO.stackMd,
    marginBottom: ESPACIADO.gutter,
  },
  vacio: {
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    padding: ESPACIADO.stackLg,
    alignItems: 'center',
    gap: 8,
  },
  vacioTxt: { ...TIPO.titleLg, color: PALETA.onSurface },
  vacioSub: {
    ...TIPO.bodyMd,
    color: PALETA.onSurfaceVariant,
    textAlign: 'center',
  },
  accionRow: { flexDirection: 'row', gap: ESPACIADO.gutter },
  accion: {
    flex: 1,
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    padding: ESPACIADO.cardPadding,
    alignItems: 'center',
    gap: 6,
    elevation: 1,
  },
  accionTxt: {
    ...TIPO.labelLg,
    color: PALETA.onSurface,
    textAlign: 'center',
  },
});
