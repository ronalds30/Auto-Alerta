// AutoAlerta - Lista de autos
import { useMemo } from 'react';
import { View, StyleSheet, ScrollView, Pressable, Image } from 'react-native';
import { Text, FAB } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useApp } from '@/hooks/AppContext';
import { calcularAlertasAuto } from '@/services/alertEngine';
import { EmptyState } from '@/components/EmptyState';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';
import type { Auto } from '@/types';

export default function AutosList() {
  const router = useRouter();
  const { datos } = useApp();
  const autos = datos?.autos ?? [];

  return (
    <View style={styles.root}>
      <View style={styles.headerBar}>
        <Text style={styles.headerTxt}>Mis autos</Text>
        <Text style={styles.subTxt}>{autos.length} registrado{autos.length === 1 ? '' : 's'}</Text>
      </View>

      {autos.length === 0 ? (
        <EmptyState
          icono="car-cog"
          titulo="Sin autos aun"
          descripcion="Agrega tu primer vehiculo para empezar a trackear documentos y mantenimientos."
          ctaLabel="Agregar auto"
          onCta={() => router.push('/auto/nuevo')}
        />
      ) : (
        <ScrollView contentContainerStyle={styles.lista}>
          {autos.map((a) => (
            <AutoItem key={a.id} auto={a} onPress={() => router.push(`/auto/${a.id}`)} />
          ))}
        </ScrollView>
      )}

      <FAB
        icon="plus"
        style={styles.fab}
        color="#fff"
        onPress={() => router.push('/auto/nuevo')}
      />
    </View>
  );
}

function AutoItem({ auto, onPress }: { auto: Auto; onPress: () => void }) {
  const alertas = useMemo(() => calcularAlertasAuto(auto), [auto]);
  const peor = useMemo(() => {
    if (alertas.some((a) => a.severidad === 'vencido')) return PALETA.semaforo.vencido;
    if (alertas.some((a) => a.severidad === 'urgente')) return PALETA.semaforo.urgente;
    if (alertas.some((a) => a.severidad === 'proximo')) return PALETA.semaforo.proximo;
    return PALETA.semaforo.aldia;
  }, [alertas]);

  return (
    <Pressable onPress={onPress} style={[styles.item, { borderLeftColor: peor }]}>
      <View style={styles.foto}>
        {auto.foto?.uri ? (
          <Image source={{ uri: auto.foto.uri }} style={styles.fotoImg} resizeMode="cover" />
        ) : (
          <MaterialCommunityIcons name="car" size={36} color={PALETA.outline} />
        )}
      </View>
      <View style={styles.itemBody}>
        <Text style={styles.titulo}>
          {auto.marca} {auto.modelo}
        </Text>
        <Text style={styles.sub}>
          {auto.anio} · {auto.color || 'sin color'} · {auto.placa || 'sin placa'}
        </Text>
        <Text style={styles.km}>{auto.kilometrajeActual.toLocaleString()} km</Text>
      </View>
      <View style={styles.chevron}>
        {alertas.filter((a) => a.severidad !== 'aldia').length > 0 && (
          <View style={[styles.badge, { backgroundColor: peor }]}>
            <Text style={styles.badgeTxt}>
              {alertas.filter((a) => a.severidad !== 'aldia').length}
            </Text>
          </View>
        )}
        <MaterialCommunityIcons name="chevron-right" size={24} color={PALETA.outline} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: PALETA.background },
  headerBar: {
    paddingHorizontal: ESPACIADO.marginMobile,
    paddingTop: ESPACIADO.stackLg,
    paddingBottom: ESPACIADO.gutter,
  },
  headerTxt: { ...TIPO.headlineMd, color: PALETA.primary },
  subTxt: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant },
  lista: { padding: ESPACIADO.marginMobile, paddingBottom: 96, gap: ESPACIADO.gutter },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    borderLeftWidth: 3,
    padding: ESPACIADO.cardPadding,
    gap: ESPACIADO.gutter,
    elevation: 1,
  },
  foto: {
    width: 64,
    height: 64,
    borderRadius: RADIO.md,
    backgroundColor: PALETA.surfaceContainer,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  fotoImg: { width: '100%', height: '100%' },
  itemBody: { flex: 1 },
  titulo: { ...TIPO.titleLg, color: PALETA.onSurface },
  sub: { ...TIPO.bodyMd, color: PALETA.onSurfaceVariant },
  km: { ...TIPO.labelLg, color: PALETA.primary, marginTop: 2 },
  chevron: { alignItems: 'center', gap: 4 },
  badge: {
    borderRadius: RADIO.full,
    paddingHorizontal: 8,
    paddingVertical: 2,
    minWidth: 24,
    alignItems: 'center',
  },
  badgeTxt: { ...TIPO.labelSm, color: '#fff' },
  fab: {
    position: 'absolute',
    right: 16,
    bottom: 16,
    backgroundColor: PALETA.secondaryContainer,
  },
});
