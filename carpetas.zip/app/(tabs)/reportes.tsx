// AutoAlerta - Tab de reportes globales
import React, { useMemo, useState } from 'react';
import { ScrollView, StyleSheet, View, Dimensions, Alert } from 'react-native';
import { Text, Button, Card } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import Svg, { Rect, Text as SvgText } from 'react-native-svg';
import { useApp } from '@/hooks/AppContext';
import { exportarPDFGlobal } from '@/services/reportes';
import { EmptyState } from '@/components/EmptyState';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';

const ANCHO = Dimensions.get('window').width - 64;

export default function Reportes() {
  const { datos } = useApp();
  const [exportando, setExportando] = useState(false);

  const stats = useMemo(() => {
    const autos = datos?.autos ?? [];
    const totalMant = autos.reduce(
      (s, a) => s + a.mantenimientos.reduce((x, m) => x + m.costo, 0),
      0,
    );
    const totalPiezas = autos.reduce(
      (s, a) => s + a.cambiosPiezas.reduce((x, p) => x + p.costo, 0),
      0,
    );
    const totalDocs = autos.reduce(
      (s, a) =>
        s +
        (a.polizaSeguro?.monto ?? 0) +
        (a.calcomania?.costo ?? 0) +
        (a.revisadoVehicular?.costo ?? 0) +
        (a.placaMetalica?.costo ?? 0),
      0,
    );

    // Gastos por mes (ultimos 12)
    const mensual: Record<string, number> = {};
    for (let i = 11; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      mensual[k] = 0;
    }
    const acumular = (iso: string, costo: number) => {
      if (!iso) return;
      const k = iso.slice(0, 7);
      if (k in mensual) mensual[k] += costo;
    };
    for (const a of autos) {
      for (const m of a.mantenimientos) acumular(m.fechaRealizado, m.costo);
      for (const p of a.cambiosPiezas) acumular(p.fechaCambio, p.costo);
      if (a.polizaSeguro) acumular(a.polizaSeguro.fechaInicio, a.polizaSeguro.monto);
      if (a.calcomania) acumular(a.calcomania.fechaPago, a.calcomania.costo);
    }

    return {
      totalMant,
      totalPiezas,
      totalDocs,
      total: totalMant + totalPiezas + totalDocs,
      mensual,
    };
  }, [datos]);

  const labels = Object.keys(stats.mensual).map((k) => k.slice(5));
  const values = Object.values(stats.mensual);
  const hayGastos = values.some((v) => v > 0);

  if (!datos || datos.autos.length === 0) {
    return (
      <EmptyState
        icono="chart-bar"
        titulo="Sin datos aun"
        descripcion="Agrega autos y registra gastos para ver reportes."
      />
    );
  }

  const exportar = async () => {
    try {
      setExportando(true);
      await exportarPDFGlobal(datos);
    } catch (err: any) {
      Alert.alert('Error', err?.message ?? 'No se pudo generar el PDF');
    } finally {
      setExportando(false);
    }
  };

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.contenido}>
      <Text style={styles.titulo}>Reportes</Text>
      <Text style={styles.sub}>Resumen de gastos de tu flota</Text>

      <View style={styles.kpiGrid}>
        <KPICard
          icono="wrench"
          label="Mantenimientos"
          valor={stats.totalMant}
          color={PALETA.primary}
        />
        <KPICard
          icono="cog"
          label="Piezas"
          valor={stats.totalPiezas}
          color={PALETA.secondaryContainer}
        />
        <KPICard
          icono="file-document"
          label="Documentos"
          valor={stats.totalDocs}
          color={PALETA.tertiaryContainer}
        />
        <KPICard
          icono="cash"
          label="TOTAL"
          valor={stats.total}
          color={PALETA.semaforo.aldia}
        />
      </View>

      {hayGastos ? (
        <Card style={styles.chartCard}>
          <Card.Title title="Gastos por mes" />
          <Card.Content>
            <BarChartSVG labels={labels} values={values} width={ANCHO} height={220} />
          </Card.Content>
        </Card>
      ) : (
        <View style={styles.vacioChart}>
          <MaterialCommunityIcons name="chart-line-variant" size={48} color={PALETA.outline} />
          <Text style={styles.vacioTxt}>
            Aun no hay gastos registrados en los ultimos 12 meses
          </Text>
        </View>
      )}

      <Text style={styles.subSeccion}>Por vehiculo</Text>
      {datos.autos.map((a) => {
        const m = a.mantenimientos.reduce((s, x) => s + x.costo, 0);
        const p = a.cambiosPiezas.reduce((s, x) => s + x.costo, 0);
        const d =
          (a.polizaSeguro?.monto ?? 0) +
          (a.calcomania?.costo ?? 0) +
          (a.revisadoVehicular?.costo ?? 0) +
          (a.placaMetalica?.costo ?? 0);
        const t = m + p + d;
        return (
          <View key={a.id} style={styles.autoFila}>
            <View style={{ flex: 1 }}>
              <Text style={styles.autoFilaTit}>
                {a.marca} {a.modelo}
              </Text>
              <Text style={styles.autoFilaSub}>{a.placa || 'sin placa'}</Text>
            </View>
            <Text style={styles.autoFilaCosto}>B/. {t.toFixed(2)}</Text>
          </View>
        );
      })}

      <Button
        mode="contained"
        icon="file-pdf-box"
        onPress={exportar}
        loading={exportando}
        disabled={exportando}
        style={styles.exportBtn}
        contentStyle={{ height: 52 }}
      >
        Exportar reporte global (PDF)
      </Button>
    </ScrollView>
  );
}

// ---- Gráfico de barras propio (sin react-native-chart-kit) ----
function BarChartSVG({
  labels,
  values,
  width,
  height,
}: {
  labels: string[];
  values: number[];
  width: number;
  height: number;
}) {
  const padLeft = 8;
  const padBottom = 28;
  const chartH = height - padBottom - 16;
  const maxVal = Math.max(...values, 1);
  const barW = Math.floor((width - padLeft) / (values.length || 1));
  const gap = Math.max(2, barW * 0.15);
  const bW = barW - gap;

  return (
    <Svg width={width} height={height}>
      {values.map((v, i) => {
        const barH = Math.max(2, (v / maxVal) * chartH);
        const x = padLeft + i * barW + gap / 2;
        const y = 16 + chartH - barH;
        return (
          <React.Fragment key={i}>
            <Rect x={x} y={y} width={bW} height={barH} fill={PALETA.primary} rx={3} />
            {v > 0 && (
              <SvgText
                x={x + bW / 2}
                y={y - 3}
                fontSize={9}
                fill={PALETA.onSurface}
                textAnchor="middle">
                {v.toFixed(0)}
              </SvgText>
            )}
            <SvgText
              x={x + bW / 2}
              y={height - 6}
              fontSize={9}
              fill={PALETA.onSurfaceVariant}
              textAnchor="middle">
              {labels[i]}
            </SvgText>
          </React.Fragment>
        );
      })}
    </Svg>
  );
}

function KPICard({
  icono,
  label,
  valor,
  color,
}: {
  icono: any;
  label: string;
  valor: number;
  color: string;
}) {
  return (
    <View style={[styles.kpiCard, { borderLeftColor: color }]}>
      <MaterialCommunityIcons name={icono} size={24} color={color} />
      <Text style={styles.kpiLabel}>{label}</Text>
      <Text style={styles.kpiValor}>B/. {valor.toFixed(2)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: PALETA.background },
  contenido: { padding: ESPACIADO.marginMobile, paddingBottom: 96 },
  titulo: { ...TIPO.headlineMd, color: PALETA.primary },
  sub: { ...TIPO.bodyMd, color: PALETA.onSurfaceVariant, marginBottom: ESPACIADO.stackMd },
  kpiGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: ESPACIADO.gutter,
    marginBottom: ESPACIADO.stackMd,
  },
  kpiCard: {
    flexBasis: '47%',
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    borderLeftWidth: 3,
    padding: ESPACIADO.cardPadding,
    gap: 4,
    elevation: 1,
  },
  kpiLabel: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant },
  kpiValor: { ...TIPO.titleLg, color: PALETA.onSurface },
  chartCard: {
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    elevation: 1,
    marginBottom: ESPACIADO.stackMd,
  },
  vacioChart: {
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    padding: ESPACIADO.stackLg,
    alignItems: 'center',
    gap: 8,
    marginBottom: ESPACIADO.stackMd,
  },
  vacioTxt: { ...TIPO.bodyMd, color: PALETA.outline, textAlign: 'center' },
  subSeccion: {
    ...TIPO.titleLg,
    color: PALETA.onSurface,
    fontSize: 16,
    marginBottom: ESPACIADO.gutter,
  },
  autoFila: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    padding: ESPACIADO.cardPadding,
    marginBottom: 8,
    elevation: 1,
  },
  autoFilaTit: { ...TIPO.bodyLg, color: PALETA.onSurface, fontWeight: '600' as const },
  autoFilaSub: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant },
  autoFilaCosto: { ...TIPO.titleLg, color: PALETA.primary, fontSize: 16 },
  exportBtn: {
    marginTop: ESPACIADO.stackMd,
    backgroundColor: PALETA.primary,
  },
});
