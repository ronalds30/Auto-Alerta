// AutoAlerta - Modelo de datos completo
// Toda la data persiste en Google Drive del usuario (datos.json)

export interface UsuarioPerfil {
  nombre: string;
  email: string;
  telefono: string;
  fotoPerfilUrl?: string;
}

export interface DocumentoFoto {
  fileId: string;          // ID del archivo en Google Drive
  uri?: string;            // URI local (cache)
  fechaSubida: string;     // ISO date
}

// ----- VEHICULO -----

export interface RegistroUnico {
  numero: string;
  fechaEmision: string;            // ISO date
  foto?: DocumentoFoto;
}

export interface PolizaSeguro {
  aseguradora: string;
  numeroPoliza: string;
  fechaInicio: string;             // ISO date
  fechaVencimiento: string;        // ISO date - ALERTA: 60/30/15 dias antes
  monto: number;
  cobertura: string;
  foto?: DocumentoFoto;
}

export interface RevisadoVehicular {
  fechaUltimoRevisado: string;     // ISO date
  fechaProximoRevisado: string;    // ISO date - ALERTA: 45/30/15 dias antes
  taller: string;
  costo: number;
  foto?: DocumentoFoto;
}

export interface Calcomania {
  mes: string;                     // Mes asignado (ej. "Enero")
  fechaPago: string;               // ISO date
  fechaVencimiento: string;        // ISO date - ALERTA: 30/15/7 dias antes
  costo: number;
  numeroRecibo?: string;
  foto?: DocumentoFoto;
}

export interface PlacaMetalica {
  fechaEmision: string;            // ISO date
  fechaVencimiento: string;        // ISO date (cada 5 anos) - ALERTA: 180/90/30 dias
  numero: string;
  costo: number;
  foto?: DocumentoFoto;
}

export interface Mantenimiento {
  id: string;
  tipo: string;                    // "Cambio de aceite", "Frenos", etc.
  descripcion?: string;
  fechaRealizado: string;          // ISO date
  kilometrajeRealizado: number;
  proximaFecha: string;            // ISO date - ALERTA
  proximoKilometraje: number;      // ALERTA al acercarse
  intervalMeses: number;           // 1-24 meses
  intervalKm: number;              // ej. 5000
  costo: number;
  taller: string;
  notas: string;
  completado: boolean;             // true si ya se hizo el proximo ciclo
  fotoRecibo?: DocumentoFoto;
}

export interface CambioPieza {
  id: string;
  pieza: string;                   // "Pastillas de freno", "Bateria", etc.
  marca: string;
  modelo?: string;
  fechaCambio: string;             // ISO date
  kilometrajeCambio: number;
  vidaUtilKm: number;
  vidaUtilMeses: number;
  proximoCambioFecha: string;      // ISO date - ALERTA
  proximoCambioKm: number;         // ALERTA
  costo: number;
  taller: string;
  notas: string;
  fotoRecibo?: DocumentoFoto;
}

export interface Auto {
  id: string;
  // Datos basicos
  marca: string;
  modelo: string;
  anio: number;
  color: string;
  placa: string;
  vin: string;
  kilometrajeActual: number;
  foto?: DocumentoFoto;

  // Documentos del vehiculo
  registroUnico?: RegistroUnico;
  polizaSeguro?: PolizaSeguro;
  revisadoVehicular?: RevisadoVehicular;
  calcomania?: Calcomania;
  placaMetalica?: PlacaMetalica;

  // Mantenimientos y piezas
  mantenimientos: Mantenimiento[];
  cambiosPiezas: CambioPieza[];

  // Choferes asignados
  choferesIds: string[];

  fechaCreacion: string;           // ISO date
  fechaActualizacion: string;      // ISO date
  notas: string;
}

// ----- CHOFER -----

export interface Cedula {
  numero: string;
  fechaEmision: string;            // ISO date
  fechaVencimiento: string;        // ISO date - ALERTA: 180/90/30 dias
  fotoFrontal?: DocumentoFoto;
  fotoTrasera?: DocumentoFoto;
}

export type CategoriaLicencia = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G';

export interface LicenciaConducir {
  numero: string;
  categoria: CategoriaLicencia;
  fechaEmision: string;            // ISO date
  fechaVencimiento: string;        // ISO date - ALERTA: 90/60/30 dias
  fotoFrontal?: DocumentoFoto;
  fotoTrasera?: DocumentoFoto;
}

export interface Chofer {
  id: string;
  nombre: string;
  apellido: string;
  telefono: string;
  email: string;
  fechaNacimiento?: string;        // ISO date - determina vigencia cedula/licencia
  direccion?: string;
  foto?: DocumentoFoto;

  cedula?: Cedula;
  licenciaConducir?: LicenciaConducir;

  autosAsignados: string[];        // IDs de Auto
  fechaCreacion: string;           // ISO date
  fechaActualizacion: string;      // ISO date
  notas: string;
  activo: boolean;
}

// ----- ESTRUCTURA RAIZ EN DRIVE -----

export interface DatosAutoAlerta {
  version: string;
  usuario: UsuarioPerfil;
  autos: Auto[];
  choferes: Chofer[];
  preferencias: PreferenciasUsuario;
  ultimaActualizacion: string;     // ISO date
  ultimaSincronizacion: string;    // ISO date
}

export interface PreferenciasUsuario {
  notificacionesActivas: boolean;
  diasAlertaCalcomania: number[];          // default [30, 15, 7]
  diasAlertaPoliza: number[];              // default [60, 30, 15]
  diasAlertaRevisado: number[];            // default [45, 30, 15]
  diasAlertaPlacaMetalica: number[];       // default [180, 90, 30]
  diasAlertaLicencia: number[];            // default [90, 60, 30]
  diasAlertaCedula: number[];              // default [180, 90, 30]
  diasAlertaMantenimiento: number[];       // default [30, 15, 7]
  diasAlertaPieza: number[];               // default [30, 15]
  kmAlertaPieza: number;                   // default 500
  kmAlertaMantenimiento: number;           // default 500
  modoOscuro: 'auto' | 'claro' | 'oscuro';
  idioma: 'es';
}

// ----- ALERTAS -----

export type SeveridadAlerta = 'vencido' | 'urgente' | 'proximo' | 'aldia';

export type TipoAlerta =
  | 'calcomania'
  | 'poliza'
  | 'revisado'
  | 'placa_metalica'
  | 'licencia'
  | 'cedula'
  | 'mantenimiento'
  | 'pieza';

export interface Alerta {
  id: string;
  tipo: TipoAlerta;
  severidad: SeveridadAlerta;
  titulo: string;
  descripcion: string;
  fechaVencimiento: string;        // ISO date
  diasRestantes: number;           // puede ser negativo (vencido)
  entidadId: string;               // id de auto o chofer
  entidadTipo: 'auto' | 'chofer';
  entidadNombre: string;           // "Toyota Yaris 2023" o "Juan Perez"
  rutaDetalle: string;             // ej. "/auto/abc123"
  notificationId?: string;         // id de la notificacion programada
}

// ----- DRIVE / SYNC -----

export interface DriveFileRef {
  id: string;
  name: string;
  mimeType: string;
}

export interface SyncStatus {
  estado: 'idle' | 'sincronizando' | 'error' | 'offline';
  ultimaSincronizacion?: string;   // ISO date
  mensaje?: string;
}
