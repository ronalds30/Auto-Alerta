// AutoAlerta - Tema visual derivado del AutoAlerta Design System (Claude Design).
// Tema oscuro: navy + naranja (Material 3 mapeado a tokens del design system).
import { MD3DarkTheme } from 'react-native-paper';

// -------------------- Tokens base del design system --------------------
export const DS = {
  navy900: '#050B14',
  navy800: '#0A1628',
  navy700: '#0D2144',
  navy600: '#1A237E',
  blue700: '#0D47A1',
  blue600: '#1565C0',
  blue300: '#90CAF9',

  accent: '#FF6F00',
  accentHover: '#FF8F00',
  orangeLight: '#FFB74D',

  green: '#2E7D32',
  green300: '#81C784',
  red: '#C62828',
  amber: '#F5B300',

  white: '#FFFFFF',
  muted: '#90CAF9',
  dim: 'rgba(255,255,255,0.55)',

  surface1: 'rgba(255,255,255,0.05)',
  surface2: 'rgba(255,255,255,0.07)',
  surface3: 'rgba(255,255,255,0.10)',
  border: 'rgba(255,255,255,0.10)',
  borderStrong: 'rgba(255,255,255,0.18)',
};

// -------------------- PALETA semantica (compat con codigo existente) --------------------
// Mantenemos los mismos nombres que ya usan las pantallas, pero apuntando al tema oscuro.
export const PALETA = {
  // Brand / acciones primarias = naranja (accent del design)
  primary: DS.accent,
  onPrimary: '#FFFFFF',
  primaryContainer: DS.accentHover,
  onPrimaryContainer: '#FFF1E0',
  inversePrimary: DS.navy600,
  primaryFixed: DS.orangeLight,
  primaryFixedDim: DS.accent,
  onPrimaryFixed: '#3A1A00',
  onPrimaryFixedVariant: '#7A3A00',

  // Secondary = navy (estructura/brand)
  secondary: DS.navy600,
  onSecondary: '#FFFFFF',
  secondaryContainer: DS.accent, // se mantiene como acento usable en chips
  onSecondaryContainer: '#FFF1E0',
  secondaryFixed: DS.blue300,
  secondaryFixedDim: DS.blue600,

  // Tertiary = blue accents
  tertiary: DS.blue600,
  onTertiary: '#FFFFFF',
  tertiaryContainer: DS.blue700,
  onTertiaryContainer: DS.blue300,

  // Errors
  error: DS.red,
  onError: '#FFFFFF',
  errorContainer: '#5C0A0A',
  onErrorContainer: '#FFB4AB',

  // Superficies (dark theme)
  background: DS.navy800,
  onBackground: DS.white,
  surface: DS.navy800,
  onSurface: DS.white,
  surfaceVariant: DS.surface2,
  onSurfaceVariant: DS.muted,
  surfaceContainerLowest: DS.surface1,
  surfaceContainerLow: DS.surface1,
  surfaceContainer: DS.surface2,
  surfaceContainerHigh: DS.surface3,
  surfaceContainerHighest: DS.surface3,
  inverseSurface: DS.white,
  inverseOnSurface: DS.navy800,
  surfaceTint: DS.accent,
  surfaceBright: DS.navy700,
  surfaceDim: DS.navy900,

  outline: DS.borderStrong,
  outlineVariant: DS.border,

  // Semaforo (validar documentos) - mapeo del design system
  semaforo: {
    vencido: DS.red,
    urgente: DS.accent,
    proximo: DS.amber,
    aldia: DS.green,
  },
};

export const ESPACIADO = {
  base: 8,
  stackSm: 4,
  stackMd: 16,
  stackLg: 24,
  cardPadding: 16,
  gutter: 12,
  marginMobile: 16,
};

// Radios del design system: md:8, lg:12, xl:16, pill:9999
export const RADIO = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  full: 9999,
};

// Fuentes del design system. fontFamily se aplica en TIPO; los .ttf se cargan
// en _layout.tsx mediante expo-font. Si la familia no esta cargada, RN cae al
// system font automaticamente.
export const FUENTES = {
  display: 'BebasNeue',
  heading: 'Rajdhani',
  body: 'DMSans',
  mono: 'JetBrainsMono',
};

export const TIPO = {
  displayLg: {
    fontFamily: FUENTES.display,
    fontSize: 40,
    lineHeight: 44,
    fontWeight: '400' as const,
    letterSpacing: 1,
  },
  displayMd: {
    fontFamily: FUENTES.display,
    fontSize: 32,
    lineHeight: 36,
    fontWeight: '400' as const,
    letterSpacing: 1,
  },
  headlineMd: {
    fontFamily: FUENTES.heading,
    fontSize: 24,
    lineHeight: 30,
    fontWeight: '700' as const,
    letterSpacing: 0.3,
  },
  titleLg: {
    fontFamily: FUENTES.heading,
    fontSize: 20,
    lineHeight: 26,
    fontWeight: '600' as const,
    letterSpacing: 0.2,
  },
  titleMd: {
    fontFamily: FUENTES.heading,
    fontSize: 16,
    lineHeight: 22,
    fontWeight: '600' as const,
  },
  bodyLg: {
    fontFamily: FUENTES.body,
    fontSize: 16,
    lineHeight: 24,
    fontWeight: '400' as const,
  },
  bodyMd: {
    fontFamily: FUENTES.body,
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '400' as const,
  },
  labelLg: {
    fontFamily: FUENTES.body,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500' as const,
    letterSpacing: 0.5,
  },
  labelSm: {
    fontFamily: FUENTES.heading,
    fontSize: 10,
    lineHeight: 12,
    fontWeight: '700' as const,
    letterSpacing: 1.2,
  },
};

// -------------------- Tema Paper (dark unicos) --------------------
// El design system es solo modo oscuro. Forzamos dark en _layout.
export const TEMA_OSCURO = {
  ...MD3DarkTheme,
  dark: true,
  colors: {
    ...MD3DarkTheme.colors,
    primary: PALETA.primary,
    onPrimary: PALETA.onPrimary,
    primaryContainer: PALETA.primaryContainer,
    onPrimaryContainer: PALETA.onPrimaryContainer,
    secondary: PALETA.secondary,
    onSecondary: PALETA.onSecondary,
    secondaryContainer: PALETA.secondaryContainer,
    onSecondaryContainer: PALETA.onSecondaryContainer,
    tertiary: PALETA.tertiary,
    onTertiary: PALETA.onTertiary,
    tertiaryContainer: PALETA.tertiaryContainer,
    onTertiaryContainer: PALETA.onTertiaryContainer,
    background: PALETA.background,
    onBackground: PALETA.onBackground,
    surface: PALETA.surface,
    onSurface: PALETA.onSurface,
    surfaceVariant: PALETA.surfaceVariant,
    onSurfaceVariant: PALETA.onSurfaceVariant,
    outline: PALETA.outline,
    outlineVariant: PALETA.outlineVariant,
    error: PALETA.error,
    onError: PALETA.onError,
    errorContainer: PALETA.errorContainer,
    onErrorContainer: PALETA.onErrorContainer,
    inverseSurface: PALETA.inverseSurface,
    inverseOnSurface: PALETA.inverseOnSurface,
    inversePrimary: PALETA.inversePrimary,
    elevation: {
      level0: 'transparent',
      level1: DS.surface1,
      level2: DS.surface2,
      level3: DS.surface3,
      level4: DS.surface3,
      level5: DS.borderStrong,
    },
  },
};

// Compatibilidad con codigo que aun importe TEMA_CLARO.
export const TEMA_CLARO = TEMA_OSCURO;

export type AppTheme = typeof TEMA_OSCURO;

// Compat con codigo anterior que importaba COLORES
export const COLORES = {
  primario: PALETA.primary,
  primarioClaro: PALETA.primaryFixedDim,
  primarioOscuro: PALETA.primaryContainer,
  acento: PALETA.secondaryContainer,
  acentoClaro: PALETA.secondaryFixedDim,
  acentoOscuro: PALETA.secondary,
  semaforo: PALETA.semaforo,
  fondo: PALETA.background,
  superficie: PALETA.surfaceContainerLowest,
  textoPrimario: PALETA.onSurface,
  textoSecundario: PALETA.onSurfaceVariant,
};
