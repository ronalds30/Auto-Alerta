// AutoAlerta - Constantes legales panamenas
// Fuentes: ATTT, Tribunal Electoral, Sertracen

export const VIGENCIAS_PANAMA = {
  calcomania: {
    meses: 12,
    ley: 'Ley 214 del 4 mayo 2021 - ATTT',
    multa: 'B/.25 base + B/.5-25 desacato por semana',
    alertasDias: [30, 15, 7],
    renovarEn: 'mupa.gob.pa',
    nota: 'Renovacion anual segun mes asignado al propietario',
  },
  placaMetalica: {
    meses: 60, // 5 anos
    ley: 'Ley 214 del 4 mayo 2021 - ATTT',
    alertasDias: [180, 90, 30],
    renovarEn: 'mupa.gob.pa',
    nota: 'Cambio cada 5 anos',
  },
  polizaSeguro: {
    meses: 12,
    alertasDias: [60, 30, 15],
    nota: 'Requerida para tramitar calcomania',
  },
  revisadoVehicular: {
    meses: 12,
    ley: 'ATTT',
    alertasDias: [45, 30, 15],
    nota: 'Requerido para tramitar calcomania',
  },
  licenciaConducir: {
    mesesMenor70: 48,  // 4 anos
    mesesMayor70: 24,  // 2 anos
    ley: 'Reglamento de Transito - ATTT / Sertracen',
    multa: 'B/.50 + posible retencion del vehiculo',
    alertasDias: [90, 60, 30],
    renovarEn: 'sertracen.com.pa',
  },
  cedulaIdentidad: {
    mesesMenor70: 180, // 15 anos
    mesesMayor70: 360, // 30 anos
    ley: 'Decreto n.4 del 5 de marzo de 2021 - Tribunal Electoral',
    alertasDias: [180, 90, 30],
    renovarEn: 'tribunalcontigo.com',
    costo: 'Gratuito',
  },
} as const;

export const MESES_CALCOMANIA = [
  'Enero',
  'Febrero',
  'Marzo',
  'Abril',
  'Mayo',
  'Junio',
  'Julio',
  'Agosto',
  'Septiembre',
  'Octubre',
  'Noviembre',
  'Diciembre',
] as const;

export const CATEGORIAS_LICENCIA = [
  { value: 'A', label: 'A - Motocicletas' },
  { value: 'B', label: 'B - Vehiculos livianos' },
  { value: 'C', label: 'C - Camiones pesados' },
  { value: 'D', label: 'D - Transporte colectivo' },
  { value: 'E', label: 'E - Articulados / tractocamiones' },
  { value: 'F', label: 'F - Personas con discapacidad' },
  { value: 'G', label: 'G - Profesional / instructor' },
] as const;
