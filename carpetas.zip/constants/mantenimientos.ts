// AutoAlerta - Tipos de mantenimiento predefinidos
// Cada uno con intervalos recomendados por defecto

export interface TipoMantenimientoPreset {
  tipo: string;
  icono: string;            // MaterialCommunityIcons
  intervalMesesDefault: number;
  intervalKmDefault: number;
  descripcion: string;
}

export const TIPOS_MANTENIMIENTO: TipoMantenimientoPreset[] = [
  {
    tipo: 'Cambio de aceite y filtro',
    icono: 'oil',
    intervalMesesDefault: 6,
    intervalKmDefault: 5000,
    descripcion: 'Aceite del motor y filtro de aceite',
  },
  {
    tipo: 'Filtro de aire',
    icono: 'air-filter',
    intervalMesesDefault: 12,
    intervalKmDefault: 15000,
    descripcion: 'Filtro de aire del motor',
  },
  {
    tipo: 'Filtro de combustible',
    icono: 'fuel',
    intervalMesesDefault: 24,
    intervalKmDefault: 30000,
    descripcion: 'Filtro de combustible',
  },
  {
    tipo: 'Filtro de habitaculo',
    icono: 'air-conditioner',
    intervalMesesDefault: 12,
    intervalKmDefault: 15000,
    descripcion: 'Filtro de cabina / aire acondicionado',
  },
  {
    tipo: 'Frenos (pastillas)',
    icono: 'car-brake-alert',
    intervalMesesDefault: 18,
    intervalKmDefault: 25000,
    descripcion: 'Pastillas de freno delanteras y traseras',
  },
  {
    tipo: 'Llantas / neumaticos',
    icono: 'tire',
    intervalMesesDefault: 36,
    intervalKmDefault: 50000,
    descripcion: 'Cambio de neumaticos',
  },
  {
    tipo: 'Alineacion y balanceo',
    icono: 'tire',
    intervalMesesDefault: 6,
    intervalKmDefault: 10000,
    descripcion: 'Alineacion de direccion y balanceo de ruedas',
  },
  {
    tipo: 'Bateria',
    icono: 'car-battery',
    intervalMesesDefault: 36,
    intervalKmDefault: 60000,
    descripcion: 'Bateria del vehiculo',
  },
  {
    tipo: 'Bujias',
    icono: 'spark-plug',
    intervalMesesDefault: 24,
    intervalKmDefault: 30000,
    descripcion: 'Bujias de encendido',
  },
  {
    tipo: 'Correa de distribucion',
    icono: 'engine',
    intervalMesesDefault: 60,
    intervalKmDefault: 90000,
    descripcion: 'Correa o cadena de distribucion',
  },
  {
    tipo: 'Liquido de frenos',
    icono: 'car-brake-fluid-level',
    intervalMesesDefault: 24,
    intervalKmDefault: 40000,
    descripcion: 'Cambio de liquido de frenos',
  },
  {
    tipo: 'Liquido refrigerante',
    icono: 'coolant-temperature',
    intervalMesesDefault: 24,
    intervalKmDefault: 40000,
    descripcion: 'Refrigerante del motor',
  },
  {
    tipo: 'Aceite de transmision',
    icono: 'cog',
    intervalMesesDefault: 36,
    intervalKmDefault: 60000,
    descripcion: 'Aceite de caja de cambios',
  },
  {
    tipo: 'Aceite de diferencial',
    icono: 'cog-outline',
    intervalMesesDefault: 36,
    intervalKmDefault: 60000,
    descripcion: 'Aceite del diferencial',
  },
  {
    tipo: 'Amortiguadores',
    icono: 'shock-absorber',
    intervalMesesDefault: 60,
    intervalKmDefault: 80000,
    descripcion: 'Amortiguadores y suspension',
  },
  {
    tipo: 'Luces',
    icono: 'car-light-high',
    intervalMesesDefault: 24,
    intervalKmDefault: 30000,
    descripcion: 'Focos, LEDs, luces del vehiculo',
  },
  {
    tipo: 'Revision general',
    icono: 'wrench',
    intervalMesesDefault: 12,
    intervalKmDefault: 15000,
    descripcion: 'Inspeccion general del vehiculo',
  },
];

export const COLORES_VEHICULO = [
  'Blanco',
  'Negro',
  'Gris',
  'Plata',
  'Rojo',
  'Azul',
  'Verde',
  'Amarillo',
  'Naranja',
  'Beige',
  'Marron',
  'Vinotinto',
  'Dorado',
  'Otro',
];
