// AutoAlerta - Configuracion global de servicios
import Constants from 'expo-constants';

// IDs OAuth (configurables via app.json -> extra, o via env)
// Se rellenan tras crear credenciales en Google Cloud Console.
export const GOOGLE_OAUTH = {
  androidClientId:
    process.env.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID ??
    (Constants.expoConfig?.extra?.googleAndroidClientId as string | undefined) ??
    '',
  iosClientId:
    process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID ??
    (Constants.expoConfig?.extra?.googleIosClientId as string | undefined) ??
    '',
  webClientId:
    process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID ??
    (Constants.expoConfig?.extra?.googleWebClientId as string | undefined) ??
    '',
};

export const SCOPES = [
  'openid',
  'profile',
  'email',
  'https://www.googleapis.com/auth/drive.file',
];

export const DRIVE = {
  rootFolderName: 'AutoAlerta',
  dataFileName: 'datos.json',
  fotosFolder: 'fotos',
  fotosAutos: 'fotos/autos',
  fotosChoferes: 'fotos/choferes',
  fotosDocumentos: 'fotos/documentos',
};

export const STORAGE_KEYS = {
  accessToken: 'autoalerta.accessToken',
  tokenExpiresAt: 'autoalerta.tokenExpiresAt',
  userInfo: 'autoalerta.userInfo',
  dataCache: 'autoalerta.dataCache',
  driveFolderIds: 'autoalerta.driveFolderIds',
  lastSync: 'autoalerta.lastSync',
};

export const APP_VERSION = '1.0.0';
