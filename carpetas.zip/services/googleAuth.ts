// AutoAlerta - Autenticacion nativa con Google Sign-In
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { GOOGLE_OAUTH, SCOPES } from './config';
import {
  guardarToken,
  obtenerToken,
  tokenVigente,
  eliminarToken,
} from './storage';
import type { UsuarioPerfil } from '@/types';

// Inicializar Google Sign-In
// El webClientId es requerido incluso en Android para obtener el idToken o accessToken
GoogleSignin.configure({
  webClientId: GOOGLE_OAUTH.webClientId,
  scopes: SCOPES,
  offlineAccess: false,
});

export const oauthConfigurado = !!GOOGLE_OAUTH.webClientId;

export async function loginConGoogle(): Promise<{ usuario: UsuarioPerfil }> {
  if (!oauthConfigurado) {
    throw new Error(
      'Google OAuth no configurado: falta EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID en el .env o googleWebClientId en app.json > extra.',
    );
  }

  // Asegura que Play Services esté disponible (Android)
  await GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
  
  // Realiza el login nativo
  const userInfo = await GoogleSignin.signIn();
  
  // Obtiene los tokens
  const tokens = await GoogleSignin.getTokens();
  
  const accessToken = tokens.accessToken;
  // Google no siempre devuelve expiresIn, asumimos 1h (3600s) por defecto
  const expiresInSec = 3600; 
  const expiresAt = Date.now() + expiresInSec * 1000;
  
  await guardarToken({ accessToken, expiresAt });

  const usuario: UsuarioPerfil = {
    nombre: userInfo.data?.user.name ?? '',
    email: userInfo.data?.user.email ?? '',
    telefono: '',
    fotoPerfilUrl: userInfo.data?.user.photo ?? undefined,
  };
  
  return { usuario };
}

export async function revocarToken(accessToken: string): Promise<void> {
  try {
    await GoogleSignin.revokeAccess();
    await GoogleSignin.signOut();
  } catch {
    // ignorar error si ya estaba deslogueado
  }
  await eliminarToken();
}

export async function getAccessToken(): Promise<string | null> {
  const token = await obtenerToken();
  if (!token) return null;
  if (!tokenVigente(token)) return null;
  return token.accessToken;
}
