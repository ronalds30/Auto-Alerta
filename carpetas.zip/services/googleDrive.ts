// AutoAlerta - API de Google Drive (datos.json + fotos)
import * as FileSystem from 'expo-file-system/legacy';
import { getAccessToken } from './googleAuth';
import { DRIVE } from './config';
import type { DatosAutoAlerta } from '@/types';

const DRIVE_API = 'https://www.googleapis.com/drive/v3';
const UPLOAD_API = 'https://www.googleapis.com/upload/drive/v3';

export type CarpetaFoto = 'autos' | 'choferes' | 'documentos';

let rootFolderIdCache: string | null = null;
const subfolderIdCache: Record<string, string> = {};

async function authHeaders(): Promise<Record<string, string>> {
  const token = await getAccessToken();
  if (!token) throw new Error('No hay token de Google activo');
  return { Authorization: `Bearer ${token}` };
}

async function buscarOcrearCarpeta(
  name: string,
  parentId?: string,
): Promise<string> {
  const cacheKey = `${parentId ?? 'root'}/${name}`;
  if (subfolderIdCache[cacheKey]) return subfolderIdCache[cacheKey];

  const headers = await authHeaders();
  const q = parentId
    ? `name='${name}' and '${parentId}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false`
    : `name='${name}' and mimeType='application/vnd.google-apps.folder' and trashed=false`;
  const searchRes = await fetch(
    `${DRIVE_API}/files?q=${encodeURIComponent(q)}&fields=files(id,name)`,
    { headers },
  );
  const searchData = await searchRes.json();
  if (searchData.files && searchData.files.length > 0) {
    const id = searchData.files[0].id as string;
    subfolderIdCache[cacheKey] = id;
    return id;
  }
  const body: Record<string, unknown> = {
    name,
    mimeType: 'application/vnd.google-apps.folder',
  };
  if (parentId) body.parents = [parentId];
  const createRes = await fetch(`${DRIVE_API}/files`, {
    method: 'POST',
    headers: { ...headers, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const createData = await createRes.json();
  const id = createData.id as string;
  subfolderIdCache[cacheKey] = id;
  return id;
}

async function getCarpetaRaiz(): Promise<string> {
  if (rootFolderIdCache) return rootFolderIdCache;
  const id = await buscarOcrearCarpeta(DRIVE.rootFolderName);
  rootFolderIdCache = id;
  return id;
}

async function getSubcarpetaFotos(carpeta: CarpetaFoto): Promise<string> {
  const root = await getCarpetaRaiz();
  const fotos = await buscarOcrearCarpeta('fotos', root);
  return buscarOcrearCarpeta(carpeta, fotos);
}

async function buscarFileIdDatos(root: string): Promise<string | null> {
  const headers = await authHeaders();
  const q = `'${root}' in parents and name='${DRIVE.dataFileName}' and trashed=false`;
  const res = await fetch(
    `${DRIVE_API}/files?q=${encodeURIComponent(q)}&fields=files(id)`,
    { headers },
  );
  const data = await res.json();
  if (data.files && data.files.length > 0) return data.files[0].id as string;
  return null;
}

function estructuraInicial(email: string, nombre: string): DatosAutoAlerta {
  const ahora = new Date().toISOString();
  return {
    version: '1.0.0',
    usuario: { nombre, email, telefono: '' },
    autos: [],
    choferes: [],
    preferencias: {
      notificacionesActivas: true,
      diasAlertaCalcomania: [30, 15, 7],
      diasAlertaPoliza: [60, 30, 15],
      diasAlertaRevisado: [45, 30, 15],
      diasAlertaPlacaMetalica: [180, 90, 30],
      diasAlertaLicencia: [90, 60, 30],
      diasAlertaCedula: [180, 90, 30],
      diasAlertaMantenimiento: [30, 15, 7],
      diasAlertaPieza: [30, 15],
      kmAlertaPieza: 500,
      kmAlertaMantenimiento: 500,
      modoOscuro: 'auto',
      idioma: 'es',
    },
    ultimaActualizacion: ahora,
    ultimaSincronizacion: ahora,
  };
}

export async function leerDatos(
  email: string,
  nombre: string,
): Promise<DatosAutoAlerta> {
  const headers = await authHeaders();
  const root = await getCarpetaRaiz();
  const fileId = await buscarFileIdDatos(root);
  if (!fileId) {
    const inicial = estructuraInicial(email, nombre);
    await guardarDatos(inicial);
    return inicial;
  }
  const res = await fetch(`${DRIVE_API}/files/${fileId}?alt=media`, { headers });
  if (!res.ok) throw new Error(`Drive: leerDatos fallo (${res.status})`);
  return (await res.json()) as DatosAutoAlerta;
}

export async function guardarDatos(datos: DatosAutoAlerta): Promise<void> {
  const headers = await authHeaders();
  const root = await getCarpetaRaiz();
  const fileId = await buscarFileIdDatos(root);
  const json = JSON.stringify({
    ...datos,
    ultimaActualizacion: new Date().toISOString(),
  });

  if (fileId) {
    const r = await fetch(
      `${UPLOAD_API}/files/${fileId}?uploadType=media`,
      {
        method: 'PATCH',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: json,
      },
    );
    if (!r.ok) throw new Error(`Drive: guardarDatos PATCH fallo (${r.status})`);
    return;
  }

  const boundary = '----autoalertaBoundary' + Date.now();
  const metadata = { name: DRIVE.dataFileName, parents: [root] };
  const body =
    `--${boundary}\r\n` +
    `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
    `${JSON.stringify(metadata)}\r\n` +
    `--${boundary}\r\n` +
    `Content-Type: application/json\r\n\r\n` +
    `${json}\r\n` +
    `--${boundary}--`;
  const r = await fetch(`${UPLOAD_API}/files?uploadType=multipart`, {
    method: 'POST',
    headers: {
      ...headers,
      'Content-Type': `multipart/related; boundary=${boundary}`,
    },
    body,
  });
  if (!r.ok) throw new Error(`Drive: guardarDatos POST fallo (${r.status})`);
}

export async function subirFoto(params: {
  localUri: string;
  nombre: string;
  carpeta: CarpetaFoto;
}): Promise<string> {
  const headers = await authHeaders();
  const subfolderId = await getSubcarpetaFotos(params.carpeta);

  const base64 = await FileSystem.readAsStringAsync(params.localUri, {
    encoding: FileSystem.EncodingType.Base64,
  });

  const boundary = '----autoalertaPhoto' + Date.now();
  const metadata = { name: params.nombre, parents: [subfolderId] };
  const body =
    `--${boundary}\r\n` +
    `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
    `${JSON.stringify(metadata)}\r\n` +
    `--${boundary}\r\n` +
    `Content-Type: image/jpeg\r\n` +
    `Content-Transfer-Encoding: base64\r\n\r\n` +
    `${base64}\r\n` +
    `--${boundary}--`;

  const r = await fetch(`${UPLOAD_API}/files?uploadType=multipart`, {
    method: 'POST',
    headers: {
      ...headers,
      'Content-Type': `multipart/related; boundary=${boundary}`,
    },
    body,
  });
  if (!r.ok) throw new Error(`Drive: subirFoto fallo (${r.status})`);
  const data = await r.json();
  return data.id as string;
}

export async function descargarFotoCacheLocal(fileId: string): Promise<string> {
  const token = await getAccessToken();
  if (!token) throw new Error('No hay token de Google activo');
  const dest = `${FileSystem.cacheDirectory}drive_${fileId}.jpg`;
  const info = await FileSystem.getInfoAsync(dest);
  if (info.exists) return dest;
  const res = await FileSystem.downloadAsync(
    `${DRIVE_API}/files/${fileId}?alt=media`,
    dest,
    { headers: { Authorization: `Bearer ${token}` } },
  );
  return res.uri;
}

export async function eliminarArchivo(fileId: string): Promise<void> {
  const headers = await authHeaders();
  await fetch(`${DRIVE_API}/files/${fileId}`, { method: 'DELETE', headers });
}

export async function obtenerUrlCarpetaDrive(): Promise<string | null> {
  try {
    const root = await getCarpetaRaiz();
    return `https://drive.google.com/drive/folders/${root}`;
  } catch {
    return null;
  }
}
