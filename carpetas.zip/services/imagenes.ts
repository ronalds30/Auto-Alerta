// AutoAlerta - Utilidades de imagenes (captura + compresion)
import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';

export interface ImagenLista {
  uri: string;
  width: number;
  height: number;
}

const MAX_DIM = 1280;
const QUALITY = 0.7; // jpeg quality

async function comprimir(uri: string): Promise<ImagenLista> {
  const result = await ImageManipulator.manipulateAsync(
    uri,
    [{ resize: { width: MAX_DIM } }],
    { compress: QUALITY, format: ImageManipulator.SaveFormat.JPEG },
  );
  return result;
}

export async function pedirPermisosCamara(): Promise<boolean> {
  const cam = await ImagePicker.requestCameraPermissionsAsync();
  return cam.granted;
}

export async function pedirPermisosGaleria(): Promise<boolean> {
  const lib = await ImagePicker.requestMediaLibraryPermissionsAsync();
  return lib.granted;
}

export async function tomarFotoCamara(): Promise<ImagenLista | null> {
  const ok = await pedirPermisosCamara();
  if (!ok) return null;
  const res = await ImagePicker.launchCameraAsync({
    mediaTypes: ['images'],
    quality: 0.9,
    allowsEditing: false,
    exif: false,
  });
  if (res.canceled || !res.assets[0]) return null;
  return comprimir(res.assets[0].uri);
}

export async function elegirFotoGaleria(): Promise<ImagenLista | null> {
  const ok = await pedirPermisosGaleria();
  if (!ok) return null;
  const res = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    quality: 0.9,
    allowsEditing: false,
    exif: false,
  });
  if (res.canceled || !res.assets[0]) return null;
  return comprimir(res.assets[0].uri);
}
