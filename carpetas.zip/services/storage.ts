// AutoAlerta - Storage local hibrido
// SecureStore para tokens y datos sensibles; AsyncStorage para cache grande.
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import { STORAGE_KEYS } from './config';
import type { DatosAutoAlerta, UsuarioPerfil } from '@/types';

// SecureStore solo funciona en device nativo; en web cae a AsyncStorage.
const useSecure = Platform.OS !== 'web';

async function secureSet(key: string, value: string) {
  if (useSecure) {
    await SecureStore.setItemAsync(key, value);
  } else {
    await AsyncStorage.setItem(key, value);
  }
}

async function secureGet(key: string): Promise<string | null> {
  if (useSecure) {
    return SecureStore.getItemAsync(key);
  }
  return AsyncStorage.getItem(key);
}

async function secureDelete(key: string) {
  if (useSecure) {
    await SecureStore.deleteItemAsync(key);
  } else {
    await AsyncStorage.removeItem(key);
  }
}

// ----- TOKEN -----

export interface TokenInfo {
  accessToken: string;
  expiresAt: number; // epoch ms
}

export async function guardarToken(token: TokenInfo) {
  await secureSet(STORAGE_KEYS.accessToken, token.accessToken);
  await secureSet(STORAGE_KEYS.tokenExpiresAt, String(token.expiresAt));
}

export async function obtenerToken(): Promise<TokenInfo | null> {
  const accessToken = await secureGet(STORAGE_KEYS.accessToken);
  const expiresAtStr = await secureGet(STORAGE_KEYS.tokenExpiresAt);
  if (!accessToken || !expiresAtStr) return null;
  const expiresAt = parseInt(expiresAtStr, 10);
  if (!Number.isFinite(expiresAt)) return null;
  return { accessToken, expiresAt };
}

export async function eliminarToken() {
  await secureDelete(STORAGE_KEYS.accessToken);
  await secureDelete(STORAGE_KEYS.tokenExpiresAt);
}

export function tokenVigente(token: TokenInfo | null, margenMs = 60_000) {
  if (!token) return false;
  return Date.now() + margenMs < token.expiresAt;
}

// ----- USUARIO -----

export async function guardarUsuario(usuario: UsuarioPerfil) {
  await AsyncStorage.setItem(STORAGE_KEYS.userInfo, JSON.stringify(usuario));
}

export async function obtenerUsuario(): Promise<UsuarioPerfil | null> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.userInfo);
  return raw ? (JSON.parse(raw) as UsuarioPerfil) : null;
}

export async function eliminarUsuario() {
  await AsyncStorage.removeItem(STORAGE_KEYS.userInfo);
}

// ----- CACHE DATOS -----

export async function guardarCacheDatos(datos: DatosAutoAlerta) {
  await AsyncStorage.setItem(STORAGE_KEYS.dataCache, JSON.stringify(datos));
}

export async function obtenerCacheDatos(): Promise<DatosAutoAlerta | null> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.dataCache);
  return raw ? (JSON.parse(raw) as DatosAutoAlerta) : null;
}

export async function eliminarCacheDatos() {
  await AsyncStorage.removeItem(STORAGE_KEYS.dataCache);
}

// ----- IDs DE CARPETAS DE DRIVE -----

export interface DriveFolderIds {
  root: string;
  fotosAutos: string;
  fotosChoferes: string;
  fotosDocumentos: string;
  datosFile?: string;
}

export async function guardarFolderIds(ids: DriveFolderIds) {
  await AsyncStorage.setItem(STORAGE_KEYS.driveFolderIds, JSON.stringify(ids));
}

export async function obtenerFolderIds(): Promise<DriveFolderIds | null> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.driveFolderIds);
  return raw ? (JSON.parse(raw) as DriveFolderIds) : null;
}

export async function eliminarFolderIds() {
  await AsyncStorage.removeItem(STORAGE_KEYS.driveFolderIds);
}

// ----- ULTIMA SINCRONIZACION -----

export async function guardarUltimaSync(iso: string) {
  await AsyncStorage.setItem(STORAGE_KEYS.lastSync, iso);
}

export async function obtenerUltimaSync(): Promise<string | null> {
  return AsyncStorage.getItem(STORAGE_KEYS.lastSync);
}

// ----- LOGOUT -----

export async function limpiarTodo() {
  await Promise.all([
    eliminarToken(),
    eliminarUsuario(),
    eliminarCacheDatos(),
    eliminarFolderIds(),
    AsyncStorage.removeItem(STORAGE_KEYS.lastSync),
  ]);
}
