// AutoAlerta - Mutators puros sobre DatosAutoAlerta
// Usados desde el contexto para mantener inmutabilidad y previsibilidad.

import { nanoid } from 'nanoid/non-secure';
import type {
  Auto,
  CambioPieza,
  Chofer,
  DatosAutoAlerta,
  Mantenimiento,
  PreferenciasUsuario,
  UsuarioPerfil,
} from '@/types';

export function nuevoId(): string {
  return nanoid(12);
}

function ahora(): string {
  return new Date().toISOString();
}

// ----- USUARIO -----

export function actualizarPerfil(
  datos: DatosAutoAlerta,
  parche: Partial<UsuarioPerfil>,
): DatosAutoAlerta {
  return { ...datos, usuario: { ...datos.usuario, ...parche } };
}

export function actualizarPreferencias(
  datos: DatosAutoAlerta,
  parche: Partial<PreferenciasUsuario>,
): DatosAutoAlerta {
  return { ...datos, preferencias: { ...datos.preferencias, ...parche } };
}

// ----- AUTO -----

export function autoNuevo(parche: Partial<Auto> = {}): Auto {
  const id = nuevoId();
  const fecha = ahora();
  return {
    id,
    marca: '',
    modelo: '',
    anio: new Date().getFullYear(),
    color: '',
    placa: '',
    vin: '',
    kilometrajeActual: 0,
    mantenimientos: [],
    cambiosPiezas: [],
    choferesIds: [],
    fechaCreacion: fecha,
    fechaActualizacion: fecha,
    notas: '',
    ...parche,
  };
}

export function agregarAuto(datos: DatosAutoAlerta, auto: Auto): DatosAutoAlerta {
  return { ...datos, autos: [...datos.autos, auto] };
}

export function actualizarAuto(
  datos: DatosAutoAlerta,
  id: string,
  parche: Partial<Auto>,
): DatosAutoAlerta {
  return {
    ...datos,
    autos: datos.autos.map((a) =>
      a.id === id ? { ...a, ...parche, fechaActualizacion: ahora() } : a,
    ),
  };
}

export function eliminarAuto(datos: DatosAutoAlerta, id: string): DatosAutoAlerta {
  return {
    ...datos,
    autos: datos.autos.filter((a) => a.id !== id),
    choferes: datos.choferes.map((c) => ({
      ...c,
      autosAsignados: c.autosAsignados.filter((aid) => aid !== id),
    })),
  };
}

// ----- MANTENIMIENTO -----

export function agregarMantenimiento(
  datos: DatosAutoAlerta,
  autoId: string,
  m: Mantenimiento,
): DatosAutoAlerta {
  return actualizarAuto(datos, autoId, {
    mantenimientos: [
      ...(datos.autos.find((a) => a.id === autoId)?.mantenimientos ?? []),
      m,
    ],
  });
}

export function actualizarMantenimiento(
  datos: DatosAutoAlerta,
  autoId: string,
  mantId: string,
  parche: Partial<Mantenimiento>,
): DatosAutoAlerta {
  const auto = datos.autos.find((a) => a.id === autoId);
  if (!auto) return datos;
  return actualizarAuto(datos, autoId, {
    mantenimientos: auto.mantenimientos.map((m) =>
      m.id === mantId ? { ...m, ...parche } : m,
    ),
  });
}

export function eliminarMantenimiento(
  datos: DatosAutoAlerta,
  autoId: string,
  mantId: string,
): DatosAutoAlerta {
  const auto = datos.autos.find((a) => a.id === autoId);
  if (!auto) return datos;
  return actualizarAuto(datos, autoId, {
    mantenimientos: auto.mantenimientos.filter((m) => m.id !== mantId),
  });
}

// ----- CAMBIO DE PIEZA -----

export function agregarCambioPieza(
  datos: DatosAutoAlerta,
  autoId: string,
  p: CambioPieza,
): DatosAutoAlerta {
  return actualizarAuto(datos, autoId, {
    cambiosPiezas: [
      ...(datos.autos.find((a) => a.id === autoId)?.cambiosPiezas ?? []),
      p,
    ],
  });
}

export function actualizarCambioPieza(
  datos: DatosAutoAlerta,
  autoId: string,
  piezaId: string,
  parche: Partial<CambioPieza>,
): DatosAutoAlerta {
  const auto = datos.autos.find((a) => a.id === autoId);
  if (!auto) return datos;
  return actualizarAuto(datos, autoId, {
    cambiosPiezas: auto.cambiosPiezas.map((p) =>
      p.id === piezaId ? { ...p, ...parche } : p,
    ),
  });
}

export function eliminarCambioPieza(
  datos: DatosAutoAlerta,
  autoId: string,
  piezaId: string,
): DatosAutoAlerta {
  const auto = datos.autos.find((a) => a.id === autoId);
  if (!auto) return datos;
  return actualizarAuto(datos, autoId, {
    cambiosPiezas: auto.cambiosPiezas.filter((p) => p.id !== piezaId),
  });
}

// ----- CHOFER -----

export function choferNuevo(parche: Partial<Chofer> = {}): Chofer {
  const id = nuevoId();
  const fecha = ahora();
  return {
    id,
    nombre: '',
    apellido: '',
    telefono: '',
    email: '',
    autosAsignados: [],
    fechaCreacion: fecha,
    fechaActualizacion: fecha,
    notas: '',
    activo: true,
    ...parche,
  };
}

export function agregarChofer(datos: DatosAutoAlerta, c: Chofer): DatosAutoAlerta {
  return { ...datos, choferes: [...datos.choferes, c] };
}

export function actualizarChofer(
  datos: DatosAutoAlerta,
  id: string,
  parche: Partial<Chofer>,
): DatosAutoAlerta {
  return {
    ...datos,
    choferes: datos.choferes.map((c) =>
      c.id === id ? { ...c, ...parche, fechaActualizacion: ahora() } : c,
    ),
  };
}

export function eliminarChofer(datos: DatosAutoAlerta, id: string): DatosAutoAlerta {
  return {
    ...datos,
    choferes: datos.choferes.filter((c) => c.id !== id),
    autos: datos.autos.map((a) => ({
      ...a,
      choferesIds: a.choferesIds.filter((cid) => cid !== id),
    })),
  };
}

// ----- ASIGNACIONES -----

export function asignarChoferAuto(
  datos: DatosAutoAlerta,
  autoId: string,
  choferId: string,
): DatosAutoAlerta {
  let d = datos;
  d = actualizarAuto(d, autoId, {
    choferesIds: Array.from(
      new Set([...(d.autos.find((a) => a.id === autoId)?.choferesIds ?? []), choferId]),
    ),
  });
  d = actualizarChofer(d, choferId, {
    autosAsignados: Array.from(
      new Set([
        ...(d.choferes.find((c) => c.id === choferId)?.autosAsignados ?? []),
        autoId,
      ]),
    ),
  });
  return d;
}

export function desasignarChoferAuto(
  datos: DatosAutoAlerta,
  autoId: string,
  choferId: string,
): DatosAutoAlerta {
  let d = datos;
  const auto = d.autos.find((a) => a.id === autoId);
  if (auto) {
    d = actualizarAuto(d, autoId, {
      choferesIds: auto.choferesIds.filter((id) => id !== choferId),
    });
  }
  const chofer = d.choferes.find((c) => c.id === choferId);
  if (chofer) {
    d = actualizarChofer(d, choferId, {
      autosAsignados: chofer.autosAsignados.filter((id) => id !== autoId),
    });
  }
  return d;
}
