// AutoAlerta - Motor de calculo de vencimientos
// Recorre autos y choferes para producir la lista de Alertas con severidad.

import { differenceInCalendarDays, parseISO, isValid } from 'date-fns';
import type {
  Alerta,
  Auto,
  Chofer,
  DatosAutoAlerta,
  SeveridadAlerta,
  TipoAlerta,
} from '@/types';

function diasHasta(isoDate: string): number | null {
  if (!isoDate) return null;
  const d = parseISO(isoDate);
  if (!isValid(d)) return null;
  return differenceInCalendarDays(d, new Date());
}

function severidad(diasRestantes: number): SeveridadAlerta {
  if (diasRestantes < 0) return 'vencido';
  if (diasRestantes <= 7) return 'urgente';
  if (diasRestantes <= 30) return 'proximo';
  return 'aldia';
}

function pushAlerta(
  arr: Alerta[],
  base: Omit<Alerta, 'id' | 'severidad' | 'diasRestantes'> & {
    diasRestantes: number;
  },
): void {
  const sev = severidad(base.diasRestantes);
  arr.push({
    ...base,
    id: `${base.tipo}-${base.entidadTipo}-${base.entidadId}-${base.fechaVencimiento}`,
    severidad: sev,
  });
}

function nombreAuto(a: Auto): string {
  const partes = [a.marca, a.modelo, a.anio ? String(a.anio) : ''].filter(Boolean);
  const placa = a.placa ? ` (${a.placa})` : '';
  return `${partes.join(' ').trim()}${placa}`.trim() || 'Vehiculo';
}

function nombreChofer(c: Chofer): string {
  return `${c.nombre} ${c.apellido}`.trim() || 'Chofer';
}

export function calcularAlertasAuto(auto: Auto): Alerta[] {
  const out: Alerta[] = [];
  const nombre = nombreAuto(auto);
  const rutaBase = `/auto/${auto.id}`;

  if (auto.polizaSeguro?.fechaVencimiento) {
    const d = diasHasta(auto.polizaSeguro.fechaVencimiento);
    if (d !== null) {
      pushAlerta(out, {
        tipo: 'poliza',
        titulo: 'Poliza de seguro',
        descripcion:
          d < 0
            ? `Vencida hace ${Math.abs(d)} dias`
            : `Vence en ${d} dias - ${auto.polizaSeguro.aseguradora}`,
        fechaVencimiento: auto.polizaSeguro.fechaVencimiento,
        diasRestantes: d,
        entidadId: auto.id,
        entidadTipo: 'auto',
        entidadNombre: nombre,
        rutaDetalle: rutaBase,
      });
    }
  }

  if (auto.revisadoVehicular?.fechaProximoRevisado) {
    const d = diasHasta(auto.revisadoVehicular.fechaProximoRevisado);
    if (d !== null) {
      pushAlerta(out, {
        tipo: 'revisado',
        titulo: 'Revisado vehicular',
        descripcion:
          d < 0 ? `Vencido hace ${Math.abs(d)} dias` : `Vence en ${d} dias`,
        fechaVencimiento: auto.revisadoVehicular.fechaProximoRevisado,
        diasRestantes: d,
        entidadId: auto.id,
        entidadTipo: 'auto',
        entidadNombre: nombre,
        rutaDetalle: rutaBase,
      });
    }
  }

  if (auto.calcomania?.fechaVencimiento) {
    const d = diasHasta(auto.calcomania.fechaVencimiento);
    if (d !== null) {
      pushAlerta(out, {
        tipo: 'calcomania',
        titulo: 'Calcomania vehicular',
        descripcion:
          d < 0
            ? `Vencida hace ${Math.abs(d)} dias`
            : `Vence en ${d} dias (mes: ${auto.calcomania.mes})`,
        fechaVencimiento: auto.calcomania.fechaVencimiento,
        diasRestantes: d,
        entidadId: auto.id,
        entidadTipo: 'auto',
        entidadNombre: nombre,
        rutaDetalle: rutaBase,
      });
    }
  }

  if (auto.placaMetalica?.fechaVencimiento) {
    const d = diasHasta(auto.placaMetalica.fechaVencimiento);
    if (d !== null) {
      pushAlerta(out, {
        tipo: 'placa_metalica',
        titulo: 'Placa metalica (renovacion 5 anos)',
        descripcion:
          d < 0
            ? `Renovacion vencida hace ${Math.abs(d)} dias`
            : `Renovar en ${d} dias`,
        fechaVencimiento: auto.placaMetalica.fechaVencimiento,
        diasRestantes: d,
        entidadId: auto.id,
        entidadTipo: 'auto',
        entidadNombre: nombre,
        rutaDetalle: rutaBase,
      });
    }
  }

  // Mantenimientos no completados
  for (const m of auto.mantenimientos.filter((x) => !x.completado)) {
    const d = diasHasta(m.proximaFecha);
    if (d !== null) {
      pushAlerta(out, {
        tipo: 'mantenimiento',
        titulo: m.tipo,
        descripcion:
          d < 0
            ? `Atrasado ${Math.abs(d)} dias`
            : `Programado en ${d} dias - ${m.taller || 'sin taller'}`,
        fechaVencimiento: m.proximaFecha,
        diasRestantes: d,
        entidadId: auto.id,
        entidadTipo: 'auto',
        entidadNombre: nombre,
        rutaDetalle: rutaBase,
      });
    }
  }

  // Cambios de pieza (proximo fin de vida util por fecha)
  for (const p of auto.cambiosPiezas) {
    const d = diasHasta(p.proximoCambioFecha);
    if (d !== null) {
      pushAlerta(out, {
        tipo: 'pieza',
        titulo: `Cambio: ${p.pieza}`,
        descripcion:
          d < 0
            ? `Vida util superada hace ${Math.abs(d)} dias`
            : `Cambio recomendado en ${d} dias`,
        fechaVencimiento: p.proximoCambioFecha,
        diasRestantes: d,
        entidadId: auto.id,
        entidadTipo: 'auto',
        entidadNombre: nombre,
        rutaDetalle: rutaBase,
      });
    }
  }

  return out;
}

export function calcularAlertasChofer(chofer: Chofer): Alerta[] {
  const out: Alerta[] = [];
  const nombre = nombreChofer(chofer);
  const rutaBase = `/chofer/${chofer.id}`;

  if (chofer.cedula?.fechaVencimiento) {
    const d = diasHasta(chofer.cedula.fechaVencimiento);
    if (d !== null) {
      pushAlerta(out, {
        tipo: 'cedula',
        titulo: 'Cedula de identidad',
        descripcion:
          d < 0 ? `Vencida hace ${Math.abs(d)} dias` : `Vence en ${d} dias`,
        fechaVencimiento: chofer.cedula.fechaVencimiento,
        diasRestantes: d,
        entidadId: chofer.id,
        entidadTipo: 'chofer',
        entidadNombre: nombre,
        rutaDetalle: rutaBase,
      });
    }
  }

  if (chofer.licenciaConducir?.fechaVencimiento) {
    const d = diasHasta(chofer.licenciaConducir.fechaVencimiento);
    if (d !== null) {
      pushAlerta(out, {
        tipo: 'licencia',
        titulo: 'Licencia de conducir',
        descripcion:
          d < 0
            ? `Vencida hace ${Math.abs(d)} dias`
            : `Vence en ${d} dias - Cat ${chofer.licenciaConducir.categoria}`,
        fechaVencimiento: chofer.licenciaConducir.fechaVencimiento,
        diasRestantes: d,
        entidadId: chofer.id,
        entidadTipo: 'chofer',
        entidadNombre: nombre,
        rutaDetalle: rutaBase,
      });
    }
  }

  return out;
}

export function calcularTodasAlertas(datos: DatosAutoAlerta): Alerta[] {
  const todas: Alerta[] = [];
  datos.autos.forEach((a) => todas.push(...calcularAlertasAuto(a)));
  datos.choferes.filter((c) => c.activo !== false).forEach((c) => {
    todas.push(...calcularAlertasChofer(c));
  });
  // Orden: por diasRestantes asc (vencidos primero)
  todas.sort((a, b) => a.diasRestantes - b.diasRestantes);
  return todas;
}

export function agruparPorSeveridad(alertas: Alerta[]) {
  return {
    vencido: alertas.filter((a) => a.severidad === 'vencido'),
    urgente: alertas.filter((a) => a.severidad === 'urgente'),
    proximo: alertas.filter((a) => a.severidad === 'proximo'),
    aldia: alertas.filter((a) => a.severidad === 'aldia'),
  };
}

export function filtrarRelevantes(alertas: Alerta[], diasUmbral = 60): Alerta[] {
  return alertas.filter(
    (a) => a.severidad !== 'aldia' || a.diasRestantes <= diasUmbral,
  );
}

export const SEVERIDAD_LABELS: Record<SeveridadAlerta, string> = {
  vencido: 'Vencido',
  urgente: 'Urgente',
  proximo: 'Proximo',
  aldia: 'Al dia',
};

export const TIPO_LABELS: Record<TipoAlerta, string> = {
  calcomania: 'Calcomania',
  poliza: 'Poliza',
  revisado: 'Revisado',
  placa_metalica: 'Placa metalica',
  licencia: 'Licencia',
  cedula: 'Cedula',
  mantenimiento: 'Mantenimiento',
  pieza: 'Pieza',
};
