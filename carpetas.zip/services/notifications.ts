// AutoAlerta - Notificaciones locales (expo-notifications)
// Sin servidor: todas las notificaciones se programan localmente segun fechas de vencimiento.

import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import type { Alerta } from '@/types';
import { COLORES } from '@/constants/tema';

let canalConfigurado = false;

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowAlert: true,
  }),
});

export async function pedirPermisos(): Promise<boolean> {
  if (!Device.isDevice) {
    // Emulador: no se muestran banners pero igual programa.
    return false;
  }
  const settings = await Notifications.getPermissionsAsync();
  let status = settings.status;
  if (status !== 'granted') {
    const req = await Notifications.requestPermissionsAsync();
    status = req.status;
  }

  if (Platform.OS === 'android' && !canalConfigurado) {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'AutoAlerta',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: COLORES.primario,
      sound: 'default',
    });
    canalConfigurado = true;
  }

  return status === 'granted';
}

export async function cancelarTodas() {
  await Notifications.cancelAllScheduledNotificationsAsync();
}

export async function cancelar(notificationId: string) {
  await Notifications.cancelScheduledNotificationAsync(notificationId);
}

// Programa la notificacion para X dias antes de la fechaVencimiento.
// Si la hora calculada ya pasó, programa para los próximos 10 segundos (recordatorio inmediato).
export async function programarAlerta(
  alerta: Alerta,
  diasAntes: number,
): Promise<string | null> {
  const venc = new Date(alerta.fechaVencimiento).getTime();
  const trigger = new Date(venc - diasAntes * 24 * 60 * 60 * 1000);
  trigger.setHours(9, 0, 0, 0); // 9am

  const ahora = Date.now();
  let segundos = Math.floor((trigger.getTime() - ahora) / 1000);
  if (segundos < 10) {
    // si la fecha ya paso o esta muy proxima, no programar segunda vez
    if (venc < ahora) return null;
    segundos = 10;
  }

  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: alerta.titulo,
      body: `${alerta.descripcion} (${alerta.entidadNombre})`,
      data: {
        rutaDetalle: alerta.rutaDetalle,
        tipo: alerta.tipo,
        entidadId: alerta.entidadId,
      },
      sound: 'default',
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
      seconds: segundos,
      repeats: false,
    },
  });
  return id;
}

export async function programarParaAlertas(
  alertas: Alerta[],
  diasPorTipo: Record<string, number[]>,
): Promise<void> {
  // Re-programa todo: cancela y vuelve a registrar.
  await cancelarTodas();

  for (const alerta of alertas) {
    const dias = diasPorTipo[alerta.tipo] ?? [30, 15, 7];
    for (const d of dias) {
      await programarAlerta(alerta, d);
    }
  }
}

export function obtenerListenerNotificacion(
  callback: (data: Notifications.NotificationResponse) => void,
) {
  return Notifications.addNotificationResponseReceivedListener(callback);
}
