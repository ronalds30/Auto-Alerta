// AutoAlerta - Generacion de reportes (PDF/CSV)
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system/legacy';
import type { Auto, DatosAutoAlerta } from '@/types';

function escapeCsv(s: any): string {
  const v = String(s ?? '');
  if (/[",\n]/.test(v)) return `"${v.replace(/"/g, '""')}"`;
  return v;
}

export async function exportarCSVAuto(auto: Auto) {
  const lineas: string[] = [];
  lineas.push('Categoria,Concepto,Fecha,Kilometraje,Costo (B/.),Taller,Notas');

  for (const m of auto.mantenimientos) {
    lineas.push(
      [
        'Mantenimiento',
        m.tipo,
        m.fechaRealizado,
        m.kilometrajeRealizado,
        m.costo.toFixed(2),
        m.taller,
        m.notas,
      ]
        .map(escapeCsv)
        .join(','),
    );
  }
  for (const p of auto.cambiosPiezas) {
    lineas.push(
      [
        'Pieza',
        `${p.pieza} ${p.marca}`,
        p.fechaCambio,
        p.kilometrajeCambio,
        p.costo.toFixed(2),
        p.taller,
        p.notas,
      ]
        .map(escapeCsv)
        .join(','),
    );
  }
  if (auto.polizaSeguro) {
    lineas.push(
      [
        'Documento',
        `Poliza ${auto.polizaSeguro.aseguradora}`,
        auto.polizaSeguro.fechaInicio,
        '',
        auto.polizaSeguro.monto.toFixed(2),
        '',
        '',
      ]
        .map(escapeCsv)
        .join(','),
    );
  }
  if (auto.calcomania) {
    lineas.push(
      [
        'Documento',
        `Calcomania ${auto.calcomania.mes}`,
        auto.calcomania.fechaPago,
        '',
        auto.calcomania.costo.toFixed(2),
        '',
        '',
      ]
        .map(escapeCsv)
        .join(','),
    );
  }

  const csv = lineas.join('\n');
  const path = `${FileSystem.cacheDirectory}autoalerta_${auto.id}_${Date.now()}.csv`;
  await FileSystem.writeAsStringAsync(path, csv, {
    encoding: FileSystem.EncodingType.UTF8,
  });
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(path, {
      mimeType: 'text/csv',
      dialogTitle: 'Exportar reporte CSV',
      UTI: 'public.comma-separated-values-text',
    });
  }
}

function htmlReporteAuto(auto: Auto): string {
  const totalMant = auto.mantenimientos.reduce((s, m) => s + m.costo, 0);
  const totalPiezas = auto.cambiosPiezas.reduce((s, p) => s + p.costo, 0);
  const totalDocs =
    (auto.polizaSeguro?.monto ?? 0) +
    (auto.calcomania?.costo ?? 0) +
    (auto.revisadoVehicular?.costo ?? 0) +
    (auto.placaMetalica?.costo ?? 0);
  const total = totalMant + totalPiezas + totalDocs;

  const filasMant = auto.mantenimientos
    .map(
      (m) =>
        `<tr><td>${m.tipo}</td><td>${m.fechaRealizado}</td><td>${m.kilometrajeRealizado}</td><td>B/. ${m.costo.toFixed(2)}</td><td>${m.taller}</td></tr>`,
    )
    .join('');
  const filasPiezas = auto.cambiosPiezas
    .map(
      (p) =>
        `<tr><td>${p.pieza}</td><td>${p.fechaCambio}</td><td>${p.kilometrajeCambio}</td><td>B/. ${p.costo.toFixed(2)}</td><td>${p.taller}</td></tr>`,
    )
    .join('');

  return `<!doctype html><html><head><meta charset="utf-8"><style>
    body{font-family:Arial,sans-serif;color:#1b1b21;padding:24px;}
    h1{color:#000666;border-bottom:2px solid #fb6d00;padding-bottom:8px;}
    h2{color:#000666;margin-top:24px;}
    table{width:100%;border-collapse:collapse;margin-top:8px;}
    th,td{border:1px solid #c6c5d4;padding:6px 8px;text-align:left;font-size:12px;}
    th{background:#1a237e;color:#fff;}
    .totales{display:flex;justify-content:space-between;background:#f5f2fb;padding:12px;border-radius:4px;margin-top:16px;}
    .totales .item{text-align:center;}
    .totales .val{font-size:18px;font-weight:bold;color:#000666;}
    .footer{margin-top:32px;font-size:10px;color:#767683;text-align:center;}
  </style></head><body>
    <h1>Reporte AutoAlerta - ${auto.marca} ${auto.modelo} ${auto.anio}</h1>
    <p><b>Placa:</b> ${auto.placa || '-'} &nbsp; <b>VIN:</b> ${auto.vin || '-'} &nbsp; <b>KM actual:</b> ${auto.kilometrajeActual.toLocaleString()}</p>
    <div class="totales">
      <div class="item"><div>Mantenimientos</div><div class="val">B/. ${totalMant.toFixed(2)}</div></div>
      <div class="item"><div>Piezas</div><div class="val">B/. ${totalPiezas.toFixed(2)}</div></div>
      <div class="item"><div>Documentos</div><div class="val">B/. ${totalDocs.toFixed(2)}</div></div>
      <div class="item"><div>TOTAL</div><div class="val">B/. ${total.toFixed(2)}</div></div>
    </div>
    <h2>Mantenimientos (${auto.mantenimientos.length})</h2>
    <table><thead><tr><th>Tipo</th><th>Fecha</th><th>KM</th><th>Costo</th><th>Taller</th></tr></thead><tbody>${filasMant || '<tr><td colspan="5">Sin registros</td></tr>'}</tbody></table>
    <h2>Cambios de piezas (${auto.cambiosPiezas.length})</h2>
    <table><thead><tr><th>Pieza</th><th>Fecha</th><th>KM</th><th>Costo</th><th>Taller</th></tr></thead><tbody>${filasPiezas || '<tr><td colspan="5">Sin registros</td></tr>'}</tbody></table>
    <div class="footer">AutoAlerta by Technology Solutions and Services (TSS PTY) - techsspty.com</div>
  </body></html>`;
}

export async function exportarPDFAuto(auto: Auto) {
  const html = htmlReporteAuto(auto);
  const { uri } = await Print.printToFileAsync({ html });
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(uri, {
      mimeType: 'application/pdf',
      dialogTitle: 'Reporte PDF',
      UTI: 'com.adobe.pdf',
    });
  }
}

// Reporte global de toda la flota
export async function exportarPDFGlobal(datos: DatosAutoAlerta) {
  const totales = datos.autos.reduce(
    (acc, a) => {
      const mant = a.mantenimientos.reduce((s, m) => s + m.costo, 0);
      const piezas = a.cambiosPiezas.reduce((s, p) => s + p.costo, 0);
      const docs =
        (a.polizaSeguro?.monto ?? 0) +
        (a.calcomania?.costo ?? 0) +
        (a.revisadoVehicular?.costo ?? 0) +
        (a.placaMetalica?.costo ?? 0);
      acc.mant += mant;
      acc.piezas += piezas;
      acc.docs += docs;
      return acc;
    },
    { mant: 0, piezas: 0, docs: 0 },
  );
  const total = totales.mant + totales.piezas + totales.docs;

  const filasAutos = datos.autos
    .map((a) => {
      const m = a.mantenimientos.reduce((s, x) => s + x.costo, 0);
      const p = a.cambiosPiezas.reduce((s, x) => s + x.costo, 0);
      const d =
        (a.polizaSeguro?.monto ?? 0) +
        (a.calcomania?.costo ?? 0) +
        (a.revisadoVehicular?.costo ?? 0) +
        (a.placaMetalica?.costo ?? 0);
      return `<tr><td>${a.marca} ${a.modelo}</td><td>${a.placa || '-'}</td><td>${a.kilometrajeActual.toLocaleString()}</td><td>B/. ${m.toFixed(2)}</td><td>B/. ${p.toFixed(2)}</td><td>B/. ${d.toFixed(2)}</td><td><b>B/. ${(m + p + d).toFixed(2)}</b></td></tr>`;
    })
    .join('');

  const html = `<!doctype html><html><head><meta charset="utf-8"><style>
    body{font-family:Arial,sans-serif;color:#1b1b21;padding:24px;}
    h1{color:#000666;border-bottom:2px solid #fb6d00;padding-bottom:8px;}
    table{width:100%;border-collapse:collapse;margin-top:16px;}
    th,td{border:1px solid #c6c5d4;padding:6px 8px;font-size:12px;}
    th{background:#1a237e;color:#fff;}
    .totales{display:flex;justify-content:space-between;background:#f5f2fb;padding:12px;border-radius:4px;margin-top:16px;}
    .val{font-size:18px;font-weight:bold;color:#000666;}
    .footer{margin-top:32px;font-size:10px;color:#767683;text-align:center;}
  </style></head><body>
    <h1>Reporte AutoAlerta - Flota completa</h1>
    <p><b>Usuario:</b> ${datos.usuario.nombre} (${datos.usuario.email})</p>
    <p><b>Generado:</b> ${new Date().toLocaleString('es-PA')}</p>
    <div class="totales">
      <div><div>Mantenimientos</div><div class="val">B/. ${totales.mant.toFixed(2)}</div></div>
      <div><div>Piezas</div><div class="val">B/. ${totales.piezas.toFixed(2)}</div></div>
      <div><div>Documentos</div><div class="val">B/. ${totales.docs.toFixed(2)}</div></div>
      <div><div>TOTAL</div><div class="val">B/. ${total.toFixed(2)}</div></div>
    </div>
    <table><thead><tr><th>Auto</th><th>Placa</th><th>KM</th><th>Mant.</th><th>Piezas</th><th>Docs.</th><th>Total</th></tr></thead><tbody>${filasAutos || '<tr><td colspan="7">Sin autos</td></tr>'}</tbody></table>
    <div class="footer">AutoAlerta by Technology Solutions and Services (TSS PTY) - techsspty.com</div>
  </body></html>`;

  const { uri } = await Print.printToFileAsync({ html });
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(uri, {
      mimeType: 'application/pdf',
      dialogTitle: 'Reporte global PDF',
    });
  }
}
