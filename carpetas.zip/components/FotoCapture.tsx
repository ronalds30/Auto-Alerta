// AutoAlerta - Captura/seleccion de foto + subida a Drive
import { useState } from 'react';
import { View, StyleSheet, Image, Alert, Pressable } from 'react-native';
import { Text, ActivityIndicator } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Sharing from 'expo-sharing';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';
import { tomarFotoCamara, elegirFotoGaleria } from '@/services/imagenes';
import {
  subirFoto,
  descargarFotoCacheLocal,
  eliminarArchivo,
  type CarpetaFoto,
} from '@/services/googleDrive';
import type { DocumentoFoto } from '@/types';

export interface FotoCaptureProps {
  foto?: DocumentoFoto;
  carpeta: CarpetaFoto;
  prefijo: string;                    // ej. "auto_<id>" o "cedula_<id>_frontal"
  etiqueta: string;
  onChange: (f: DocumentoFoto | undefined) => void;
  ratio?: number;                      // ej. 16/9. Por defecto 4/3
}

export function FotoCapture(props: FotoCaptureProps) {
  const [cargando, setCargando] = useState(false);
  const [uri, setUri] = useState<string | undefined>(props.foto?.uri);
  const ratio = props.ratio ?? 4 / 3;

  const resolverUri = async () => {
    if (uri) return uri;
    if (props.foto?.fileId) {
      try {
        const local = await descargarFotoCacheLocal(props.foto.fileId);
        setUri(local);
        return local;
      } catch {
        return undefined;
      }
    }
    return undefined;
  };

  const subir = async (localUri: string) => {
    try {
      setCargando(true);
      const nombre = `${props.prefijo}_${Date.now()}.jpg`;
      const fileId = await subirFoto({ localUri, nombre, carpeta: props.carpeta });
      const nueva: DocumentoFoto = {
        fileId,
        uri: localUri,
        fechaSubida: new Date().toISOString(),
      };
      setUri(localUri);
      props.onChange(nueva);
    } catch (err: any) {
      Alert.alert('Error', err?.message ?? 'No se pudo subir la foto');
    } finally {
      setCargando(false);
    }
  };

  const onCamara = async () => {
    const img = await tomarFotoCamara();
    if (img) await subir(img.uri);
  };

  const onGaleria = async () => {
    const img = await elegirFotoGaleria();
    if (img) await subir(img.uri);
  };

  const onEliminar = () => {
    if (!props.foto) return;
    Alert.alert('Eliminar foto', '?Estas seguro?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Eliminar',
        style: 'destructive',
        onPress: async () => {
          try {
            await eliminarArchivo(props.foto!.fileId);
          } catch {
            // no fatal
          }
          setUri(undefined);
          props.onChange(undefined);
        },
      },
    ]);
  };

  const onVer = async () => {
    const u = await resolverUri();
    if (u && (await Sharing.isAvailableAsync())) {
      await Sharing.shareAsync(u);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>{props.etiqueta}</Text>
      <View style={[styles.frame, { aspectRatio: ratio }]}>
        {cargando ? (
          <View style={styles.placeholder}>
            <ActivityIndicator size="large" color={PALETA.primary} />
            <Text style={styles.cargandoTxt}>Subiendo a Drive...</Text>
          </View>
        ) : uri || props.foto ? (
          <Pressable onPress={onVer} style={styles.imageWrap}>
            {uri ? (
              <Image source={{ uri }} style={styles.image} resizeMode="cover" />
            ) : (
              <View style={styles.placeholder}>
                <MaterialCommunityIcons
                  name="cloud-download"
                  size={32}
                  color={PALETA.outline}
                />
                <Text style={styles.cargandoTxt}>Toca para descargar</Text>
              </View>
            )}
          </Pressable>
        ) : (
          <View style={styles.placeholder}>
            <MaterialCommunityIcons
              name="camera-plus"
              size={32}
              color={PALETA.outline}
            />
            <Text style={styles.cargandoTxt}>Sin foto</Text>
          </View>
        )}
      </View>
      <View style={styles.actions}>
        <ActionBtn icono="camera" label="Camara" onPress={onCamara} />
        <ActionBtn icono="image" label="Galeria" onPress={onGaleria} />
        {props.foto && (
          <ActionBtn icono="trash-can" label="Borrar" onPress={onEliminar} danger />
        )}
      </View>
    </View>
  );
}

function ActionBtn({
  icono,
  label,
  onPress,
  danger,
}: {
  icono: any;
  label: string;
  onPress: () => void;
  danger?: boolean;
}) {
  return (
    <Pressable onPress={onPress} style={styles.actionBtn}>
      <MaterialCommunityIcons
        name={icono}
        size={20}
        color={danger ? PALETA.error : PALETA.primary}
      />
      <Text
        style={[
          styles.actionTxt,
          { color: danger ? PALETA.error : PALETA.primary },
        ]}
      >
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: ESPACIADO.stackMd },
  label: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant, marginBottom: 6 },
  frame: {
    backgroundColor: PALETA.surfaceContainer,
    borderRadius: RADIO.md,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: PALETA.outlineVariant,
  },
  imageWrap: { width: '100%', height: '100%' },
  image: { width: '100%', height: '100%' },
  placeholder: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  cargandoTxt: { ...TIPO.labelLg, color: PALETA.outline },
  actions: {
    flexDirection: 'row',
    gap: ESPACIADO.gutter,
    marginTop: ESPACIADO.base,
  },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  actionTxt: { ...TIPO.labelLg },
});
