// AutoAlerta - Indicador de estado de sincronizacion con Drive
import { View, StyleSheet } from 'react-native';
import { ActivityIndicator, Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '@/hooks/AppContext';
import { PALETA, TIPO } from '@/constants/tema';

function relativo(iso?: string | null): string {
  if (!iso) return 'sin sincronizar';
  const ms = Date.now() - new Date(iso).getTime();
  if (ms < 60_000) return 'hace instantes';
  if (ms < 3_600_000) return `hace ${Math.floor(ms / 60_000)} min`;
  if (ms < 86_400_000) return `hace ${Math.floor(ms / 3_600_000)} h`;
  return `hace ${Math.floor(ms / 86_400_000)} dias`;
}

export function SyncIndicator() {
  const { syncStatus, ultimaSync } = useApp();

  let icono: keyof typeof MaterialCommunityIcons.glyphMap = 'cloud-check';
  let color = PALETA.semaforo.aldia;
  let texto = `Drive: ${relativo(ultimaSync)}`;

  if (syncStatus.estado === 'sincronizando') {
    color = PALETA.primary;
    texto = 'Sincronizando con Drive...';
    return (
      <View style={styles.row}>
        <ActivityIndicator size={14} color={color} />
        <Text style={[styles.txt, { color }]}>{texto}</Text>
      </View>
    );
  }

  if (syncStatus.estado === 'error') {
    icono = 'cloud-alert';
    color = PALETA.semaforo.vencido;
    texto = syncStatus.mensaje ?? 'Error de sincronizacion';
  }

  return (
    <View style={styles.row}>
      <MaterialCommunityIcons name={icono} size={14} color={color} />
      <Text style={[styles.txt, { color }]}>{texto}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  txt: { ...TIPO.labelLg },
});
