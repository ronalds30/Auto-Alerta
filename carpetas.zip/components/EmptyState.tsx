// AutoAlerta - Estado vacio reutilizable
import { View, StyleSheet } from 'react-native';
import { Text, Button } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { PALETA, ESPACIADO, TIPO } from '@/constants/tema';

export interface EmptyStateProps {
  icono: keyof typeof MaterialCommunityIcons.glyphMap;
  titulo: string;
  descripcion?: string;
  ctaLabel?: string;
  onCta?: () => void;
}

export function EmptyState({
  icono,
  titulo,
  descripcion,
  ctaLabel,
  onCta,
}: EmptyStateProps) {
  return (
    <View style={styles.container}>
      <MaterialCommunityIcons name={icono} size={80} color={PALETA.outline} />
      <Text style={styles.titulo}>{titulo}</Text>
      {descripcion && <Text style={styles.descripcion}>{descripcion}</Text>}
      {ctaLabel && onCta && (
        <Button mode="contained" onPress={onCta} style={styles.btn}>
          {ctaLabel}
        </Button>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: ESPACIADO.stackLg,
    gap: ESPACIADO.gutter,
  },
  titulo: {
    ...TIPO.headlineMd,
    color: PALETA.onSurface,
    marginTop: ESPACIADO.stackMd,
    textAlign: 'center',
  },
  descripcion: {
    ...TIPO.bodyLg,
    color: PALETA.onSurfaceVariant,
    textAlign: 'center',
    maxWidth: 280,
  },
  btn: { marginTop: ESPACIADO.stackMd },
});
