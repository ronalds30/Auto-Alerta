// AutoAlerta - Inputs reutilizables (TextField, DateField, NumberField)
import { useState } from 'react';
import { View, StyleSheet, Pressable, Platform } from 'react-native';
import { Text, TextInput, HelperText } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';

interface FieldBaseProps {
  label: string;
  helper?: string;
  error?: string;
}

interface TextFieldProps extends FieldBaseProps {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  keyboardType?: 'default' | 'numeric' | 'email-address' | 'phone-pad';
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  multiline?: boolean;
  maxLength?: number;
}

export function TextField(p: TextFieldProps) {
  return (
    <View style={styles.wrap}>
      <TextInput
        mode="outlined"
        label={p.label}
        value={p.value}
        onChangeText={p.onChange}
        placeholder={p.placeholder}
        keyboardType={p.keyboardType}
        autoCapitalize={p.autoCapitalize}
        multiline={p.multiline}
        maxLength={p.maxLength}
        error={!!p.error}
        outlineColor={PALETA.outlineVariant}
        activeOutlineColor={PALETA.primary}
        style={styles.input}
      />
      {(p.helper || p.error) && (
        <HelperText type={p.error ? 'error' : 'info'} visible>
          {p.error ?? p.helper}
        </HelperText>
      )}
    </View>
  );
}

interface NumberFieldProps extends FieldBaseProps {
  value: number;
  onChange: (v: number) => void;
  placeholder?: string;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
}

export function NumberField(p: NumberFieldProps) {
  const [raw, setRaw] = useState(String(p.value));
  return (
    <View style={styles.wrap}>
      <TextInput
        mode="outlined"
        label={p.label}
        value={raw}
        onChangeText={(t) => {
          setRaw(t);
          const num = parseFloat(t.replace(',', '.'));
          if (!Number.isNaN(num)) p.onChange(num);
          else if (t === '' || t === '-') p.onChange(0);
        }}
        keyboardType="numeric"
        placeholder={p.placeholder}
        error={!!p.error}
        outlineColor={PALETA.outlineVariant}
        activeOutlineColor={PALETA.primary}
        right={p.suffix ? <TextInput.Affix text={p.suffix} /> : undefined}
        style={styles.input}
      />
      {(p.helper || p.error) && (
        <HelperText type={p.error ? 'error' : 'info'} visible>
          {p.error ?? p.helper}
        </HelperText>
      )}
    </View>
  );
}

interface DateFieldProps extends FieldBaseProps {
  value: string; // ISO yyyy-mm-dd
  onChange: (v: string) => void;
  placeholder?: string;
}

// Implementacion simple: input de texto con formato DD/MM/YYYY y conversion a ISO.
// Sin libreria nativa de calendario para evitar mas dependencias; el usuario puede tipear o pegar.
export function DateField(p: DateFieldProps) {
  const ddmmyyyy = isoToDisplay(p.value);
  const [raw, setRaw] = useState(ddmmyyyy);

  return (
    <View style={styles.wrap}>
      <TextInput
        mode="outlined"
        label={p.label}
        value={raw}
        onChangeText={(t) => {
          const norm = autoFormatFecha(t);
          setRaw(norm);
          const iso = displayToIso(norm);
          if (iso) p.onChange(iso);
        }}
        placeholder={p.placeholder ?? 'DD/MM/AAAA'}
        keyboardType="numeric"
        maxLength={10}
        error={!!p.error}
        outlineColor={PALETA.outlineVariant}
        activeOutlineColor={PALETA.primary}
        right={<TextInput.Icon icon="calendar" />}
        style={styles.input}
      />
      {(p.helper || p.error) && (
        <HelperText type={p.error ? 'error' : 'info'} visible>
          {p.error ?? p.helper ?? 'Formato: DD/MM/AAAA'}
        </HelperText>
      )}
    </View>
  );
}

function autoFormatFecha(t: string): string {
  const d = t.replace(/\D/g, '').slice(0, 8);
  if (d.length <= 2) return d;
  if (d.length <= 4) return `${d.slice(0, 2)}/${d.slice(2)}`;
  return `${d.slice(0, 2)}/${d.slice(2, 4)}/${d.slice(4)}`;
}

function displayToIso(s: string): string | null {
  const m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!m) return null;
  const dd = parseInt(m[1], 10);
  const mm = parseInt(m[2], 10);
  const yyyy = parseInt(m[3], 10);
  if (mm < 1 || mm > 12 || dd < 1 || dd > 31) return null;
  const date = new Date(yyyy, mm - 1, dd);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString().slice(0, 10);
}

export function isoToDisplay(iso?: string): string {
  if (!iso) return '';
  const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!m) return iso;
  return `${m[3]}/${m[2]}/${m[1]}`;
}

// Selector simple tipo dropdown a partir de opciones (lista bottom-sheet ligera).
import { Modal, Portal } from 'react-native-paper';

export interface SelectOption<T = string> {
  value: T;
  label: string;
  icon?: keyof typeof MaterialCommunityIcons.glyphMap;
}

interface SelectFieldProps<T> extends FieldBaseProps {
  value: T | null | undefined;
  onChange: (v: T) => void;
  options: SelectOption<T>[];
}

export function SelectField<T extends string | number>(p: SelectFieldProps<T>) {
  const [open, setOpen] = useState(false);
  const seleccion = p.options.find((o) => o.value === p.value);

  return (
    <View style={styles.wrap}>
      <Text style={styles.selectLabel}>{p.label}</Text>
      <Pressable
        onPress={() => setOpen(true)}
        style={[styles.selectBtn, p.error && { borderColor: PALETA.error }]}
      >
        <Text
          style={[
            styles.selectVal,
            !seleccion && { color: PALETA.outline },
          ]}
        >
          {seleccion?.label ?? 'Seleccionar...'}
        </Text>
        <MaterialCommunityIcons name="chevron-down" size={20} color={PALETA.outline} />
      </Pressable>
      {(p.helper || p.error) && (
        <HelperText type={p.error ? 'error' : 'info'} visible>
          {p.error ?? p.helper}
        </HelperText>
      )}
      <Portal>
        <Modal
          visible={open}
          onDismiss={() => setOpen(false)}
          contentContainerStyle={styles.modal}
        >
          <Text style={styles.modalTitulo}>{p.label}</Text>
          {p.options.map((o) => (
            <Pressable
              key={String(o.value)}
              onPress={() => {
                p.onChange(o.value);
                setOpen(false);
              }}
              style={[
                styles.opt,
                p.value === o.value && { backgroundColor: PALETA.primaryFixed },
              ]}
            >
              {o.icon && (
                <MaterialCommunityIcons name={o.icon} size={20} color={PALETA.primary} />
              )}
              <Text style={styles.optTxt}>{o.label}</Text>
              {p.value === o.value && (
                <MaterialCommunityIcons name="check" size={20} color={PALETA.primary} />
              )}
            </Pressable>
          ))}
        </Modal>
      </Portal>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { marginBottom: 4 },
  input: { backgroundColor: PALETA.surfaceContainerLowest },
  selectLabel: {
    ...TIPO.labelLg,
    color: PALETA.onSurfaceVariant,
    marginBottom: 4,
    marginLeft: 4,
  },
  selectBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.md,
    borderWidth: 1,
    borderColor: PALETA.outlineVariant,
    paddingHorizontal: ESPACIADO.cardPadding,
    paddingVertical: 14,
  },
  selectVal: { ...TIPO.bodyLg, color: PALETA.onSurface, flex: 1 },
  modal: {
    backgroundColor: PALETA.surfaceContainerLowest,
    margin: 24,
    borderRadius: RADIO.md,
    padding: ESPACIADO.cardPadding,
    maxHeight: '70%',
  },
  modalTitulo: {
    ...TIPO.titleLg,
    color: PALETA.primary,
    marginBottom: ESPACIADO.gutter,
  },
  opt: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 12,
    borderRadius: RADIO.md,
  },
  optTxt: { ...TIPO.bodyLg, color: PALETA.onSurface, flex: 1 },
});
