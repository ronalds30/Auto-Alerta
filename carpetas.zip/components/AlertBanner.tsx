// AutoAlerta - Banner agrupador de alertas por severidad
import { View, StyleSheet, Pressable } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';
import type { Alerta, SeveridadAlerta } from '@/types';

const COLORS: Record<SeveridadAlerta, string> = {
  vencido: PALETA.semaforo.vencido,
  urgente: PALETA.semaforo.urgente,
  proximo: PALETA.semaforo.proximo,
  aldia: PALETA.semaforo.aldia,
};

const LABELS: Record<SeveridadAlerta, string> = {
  vencido: 'Vencidos',
  urgente: 'Urgentes',
  proximo: 'Proximos',
  aldia: 'Al dia',
};

const ICONOS: Record<SeveridadAlerta, keyof typeof MaterialCommunityIcons.glyphMap> = {
  vencido: 'alert-octagon',
  urgente: 'alert',
  proximo: 'clock-alert',
  aldia: 'check-circle',
};

export function AlertGroup({
  severidad,
  alertas,
}: {
  severidad: SeveridadAlerta;
  alertas: Alerta[];
}) {
  const router = useRouter();
  if (alertas.length === 0) return null;
  const color = COLORS[severidad];

  return (
    <View style={[styles.container, { borderLeftColor: color }]}>
      <View style={styles.header}>
        <MaterialCommunityIcons name={ICONOS[severidad]} size={20} color={color} />
        <Text style={[styles.headerTxt, { color }]}>
          {LABELS[severidad]} ({alertas.length})
        </Text>
      </View>
      {alertas.slice(0, 4).map((a) => (
        <Pressable
          key={a.id}
          onPress={() => router.push(a.rutaDetalle as never)}
          style={styles.row}
        >
          <View style={styles.rowBody}>
            <Text style={styles.titulo} numberOfLines={1}>
              {a.titulo}
            </Text>
            <Text style={styles.detalle} numberOfLines={1}>
              {a.entidadNombre} - {a.descripcion}
            </Text>
          </View>
          <MaterialCommunityIcons
            name="chevron-right"
            size={20}
            color={PALETA.outline}
          />
        </Pressable>
      ))}
      {alertas.length > 4 && (
        <Text style={styles.mas}>+{alertas.length - 4} mas</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.lg,
    borderLeftWidth: 3,
    borderTopWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderTopColor: PALETA.outlineVariant,
    borderRightColor: PALETA.outlineVariant,
    borderBottomColor: PALETA.outlineVariant,
    padding: ESPACIADO.cardPadding,
    marginBottom: ESPACIADO.gutter,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: ESPACIADO.gutter,
  },
  headerTxt: { ...TIPO.titleLg, fontSize: 16 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderTopWidth: 1,
    borderTopColor: PALETA.outlineVariant,
  },
  rowBody: { flex: 1 },
  titulo: { ...TIPO.bodyLg, color: PALETA.onSurface, fontWeight: '600' as const },
  detalle: { ...TIPO.bodyMd, color: PALETA.onSurfaceVariant },
  mas: {
    ...TIPO.labelLg,
    color: PALETA.primary,
    marginTop: 6,
    textAlign: 'center',
  },
});
