// AutoAlerta - Tarjeta de documento con semaforo
import { View, StyleSheet, Pressable } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { PALETA, ESPACIADO, RADIO, TIPO } from '@/constants/tema';
import type { SeveridadAlerta } from '@/types';

function colorSemaforo(s: SeveridadAlerta) {
  return PALETA.semaforo[s];
}

function labelSemaforo(s: SeveridadAlerta, diasRestantes?: number) {
  if (s === 'vencido') return 'VENCIDO';
  if (s === 'urgente') return 'URGENTE';
  if (s === 'proximo') return 'PROXIMO';
  if (diasRestantes !== undefined && diasRestantes > 60) return 'AL DIA';
  return 'AL DIA';
}

export interface DocumentCardProps {
  icono: keyof typeof MaterialCommunityIcons.glyphMap;
  titulo: string;
  detalle?: string;
  fechaVencimiento?: string;        // ISO o legible
  diasRestantes?: number;
  severidad: SeveridadAlerta;
  onPress?: () => void;
  derechaExtra?: React.ReactNode;
}

export function DocumentCard(props: DocumentCardProps) {
  const color = colorSemaforo(props.severidad);

  const Tag = props.onPress ? Pressable : View;

  return (
    <Tag onPress={props.onPress} style={[styles.card, { borderLeftColor: color }]}>
      <View style={styles.iconWrap}>
        <MaterialCommunityIcons name={props.icono} size={28} color={PALETA.primary} />
      </View>
      <View style={styles.body}>
        <Text style={styles.titulo}>{props.titulo}</Text>
        {props.detalle && <Text style={styles.detalle}>{props.detalle}</Text>}
        {props.fechaVencimiento && (
          <Text style={styles.fecha}>
            {props.diasRestantes !== undefined && props.diasRestantes < 0
              ? `Vencido hace ${Math.abs(props.diasRestantes)} dias`
              : props.diasRestantes !== undefined
                ? `${props.diasRestantes} dias restantes`
                : props.fechaVencimiento}
          </Text>
        )}
      </View>
      <View style={[styles.badge, { backgroundColor: color }]}>
        <Text style={styles.badgeTxt}>
          {labelSemaforo(props.severidad, props.diasRestantes)}
        </Text>
      </View>
      {props.derechaExtra}
    </Tag>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: PALETA.surfaceContainerLowest,
    borderRadius: RADIO.lg,
    borderLeftWidth: 3,
    borderTopWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderTopColor: PALETA.outlineVariant,
    borderRightColor: PALETA.outlineVariant,
    borderBottomColor: PALETA.outlineVariant,
    padding: ESPACIADO.cardPadding,
    marginBottom: ESPACIADO.gutter,
    gap: ESPACIADO.gutter,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: RADIO.lg,
    backgroundColor: 'rgba(255,111,0,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: { flex: 1 },
  titulo: { ...TIPO.titleLg, color: PALETA.onSurface, fontSize: 16 },
  detalle: { ...TIPO.bodyMd, color: PALETA.onSurfaceVariant },
  fecha: { ...TIPO.labelLg, color: PALETA.onSurfaceVariant, marginTop: 2 },
  badge: {
    borderRadius: RADIO.full,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  badgeTxt: { ...TIPO.labelSm, color: '#ffffff' },
});
