// AutoAlerta - Contexto global: sesion + datos.json + sincronizacion
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type {
  DatosAutoAlerta,
  UsuarioPerfil,
  Auto,
  Chofer,
  Alerta,
  SyncStatus,
} from '@/types';
import {
  obtenerToken,
  obtenerUsuario,
  obtenerCacheDatos,
  guardarCacheDatos,
  guardarUsuario,
  guardarUltimaSync,
  obtenerUltimaSync,
  limpiarTodo,
  tokenVigente,
} from '@/services/storage';
import { leerDatos, guardarDatos } from '@/services/googleDrive';
import { revocarToken } from '@/services/googleAuth';
import { calcularTodasAlertas } from '@/services/alertEngine';
import {
  pedirPermisos as pedirPermisosNotif,
  programarParaAlertas,
} from '@/services/notifications';

export interface AppContextValue {
  // Sesion
  usuario: UsuarioPerfil | null;
  autenticado: boolean;
  cargandoSesion: boolean;
  iniciarSesion: (usuario: UsuarioPerfil) => Promise<void>;
  cerrarSesion: () => Promise<void>;

  // Datos
  datos: DatosAutoAlerta | null;
  cargandoDatos: boolean;
  sincronizar: () => Promise<void>;
  setDatos: (mutator: (prev: DatosAutoAlerta) => DatosAutoAlerta) => Promise<void>;

  // Derivados
  alertas: Alerta[];

  // Sync
  syncStatus: SyncStatus;
  ultimaSync: string | null;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [usuario, setUsuario] = useState<UsuarioPerfil | null>(null);
  const [datos, setDatosState] = useState<DatosAutoAlerta | null>(null);
  const [cargandoSesion, setCargandoSesion] = useState(true);
  const [cargandoDatos, setCargandoDatos] = useState(false);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({ estado: 'idle' });
  const [ultimaSync, setUltimaSync] = useState<string | null>(null);

  // Bootstrap: carga desde cache local al montar.
  useEffect(() => {
    (async () => {
      try {
        const [token, user, cache, last] = await Promise.all([
          obtenerToken(),
          obtenerUsuario(),
          obtenerCacheDatos(),
          obtenerUltimaSync(),
        ]);
        if (user && tokenVigente(token)) {
          setUsuario(user);
        }
        if (cache) setDatosState(cache);
        if (last) setUltimaSync(last);
      } finally {
        setCargandoSesion(false);
      }
    })();
  }, []);

  // Sincroniza con Drive (al login, manual, o tras cambios).
  const sincronizar = useCallback(async () => {
    if (!usuario) return;
    setSyncStatus({ estado: 'sincronizando' });
    try {
      const remoto = await leerDatos(usuario.email, usuario.nombre);
      setDatosState(remoto);
      await guardarCacheDatos(remoto);
      const ahora = new Date().toISOString();
      await guardarUltimaSync(ahora);
      setUltimaSync(ahora);
      setSyncStatus({ estado: 'idle', ultimaSincronizacion: ahora });
    } catch (err: any) {
      setSyncStatus({ estado: 'error', mensaje: err?.message ?? 'Error de sincronizacion' });
    }
  }, [usuario]);

  // setDatos: aplica mutator, persiste local Y en Drive.
  // Lock simple para evitar escrituras paralelas.
  const writeLock = useRef<Promise<void>>(Promise.resolve());

  const setDatos = useCallback(
    async (mutator: (prev: DatosAutoAlerta) => DatosAutoAlerta) => {
      const prev = await new Promise<DatosAutoAlerta | null>((r) => r(datos));
      if (!prev) return;
      const next = { ...mutator(prev), ultimaActualizacion: new Date().toISOString() };
      setDatosState(next);
      await guardarCacheDatos(next);

      writeLock.current = writeLock.current.then(async () => {
        setSyncStatus({ estado: 'sincronizando' });
        try {
          await guardarDatos(next);
          const ahora = new Date().toISOString();
          await guardarUltimaSync(ahora);
          setUltimaSync(ahora);
          setSyncStatus({ estado: 'idle', ultimaSincronizacion: ahora });
        } catch (err: any) {
          setSyncStatus({
            estado: 'error',
            mensaje: err?.message ?? 'Error guardando en Drive',
          });
        }
      });
      await writeLock.current;
    },
    [datos],
  );

  const iniciarSesion = useCallback(
    async (u: UsuarioPerfil) => {
      setUsuario(u);
      await guardarUsuario(u);
      setCargandoDatos(true);
      try {
        // Cargar datos desde Drive (crea estructura si hace falta).
        const remoto = await leerDatos(u.email, u.nombre);
        // Si el remoto trae usuario vacio, completar con info de Google.
        if (!remoto.usuario.email) remoto.usuario.email = u.email;
        if (!remoto.usuario.nombre) remoto.usuario.nombre = u.nombre;
        setDatosState(remoto);
        await guardarCacheDatos(remoto);
        const ahora = new Date().toISOString();
        await guardarUltimaSync(ahora);
        setUltimaSync(ahora);
        await pedirPermisosNotif();
      } catch (err: any) {
        setSyncStatus({ estado: 'error', mensaje: err?.message ?? 'Error cargando datos' });
      } finally {
        setCargandoDatos(false);
      }
    },
    [],
  );

  const cerrarSesion = useCallback(async () => {
    const token = await obtenerToken();
    if (token) await revocarToken(token.accessToken);
    await limpiarTodo();
    setUsuario(null);
    setDatosState(null);
    setUltimaSync(null);
    setSyncStatus({ estado: 'idle' });
  }, []);

  // Re-programar notificaciones cuando datos cambien (debounced).
  const reprogTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!datos) return;
    if (!datos.preferencias.notificacionesActivas) return;
    if (reprogTimer.current) clearTimeout(reprogTimer.current);
    reprogTimer.current = setTimeout(() => {
      const alertas = calcularTodasAlertas(datos);
      const dias = {
        calcomania: datos.preferencias.diasAlertaCalcomania,
        poliza: datos.preferencias.diasAlertaPoliza,
        revisado: datos.preferencias.diasAlertaRevisado,
        placa_metalica: datos.preferencias.diasAlertaPlacaMetalica,
        licencia: datos.preferencias.diasAlertaLicencia,
        cedula: datos.preferencias.diasAlertaCedula,
        mantenimiento: datos.preferencias.diasAlertaMantenimiento,
        pieza: datos.preferencias.diasAlertaPieza,
      };
      programarParaAlertas(alertas, dias).catch(() => {});
    }, 1500);
    return () => {
      if (reprogTimer.current) clearTimeout(reprogTimer.current);
    };
  }, [datos]);

  const alertas = useMemo<Alerta[]>(
    () => (datos ? calcularTodasAlertas(datos) : []),
    [datos],
  );

  const value: AppContextValue = useMemo(
    () => ({
      usuario,
      autenticado: !!usuario,
      cargandoSesion,
      iniciarSesion,
      cerrarSesion,
      datos,
      cargandoDatos,
      sincronizar,
      setDatos,
      alertas,
      syncStatus,
      ultimaSync,
    }),
    [
      usuario,
      cargandoSesion,
      datos,
      cargandoDatos,
      alertas,
      syncStatus,
      ultimaSync,
      iniciarSesion,
      cerrarSesion,
      sincronizar,
      setDatos,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp debe usarse dentro de AppProvider');
  return ctx;
}

// Convenience hooks

export function useAuto(id: string | undefined): Auto | undefined {
  const { datos } = useApp();
  return datos?.autos.find((a) => a.id === id);
}

export function useChofer(id: string | undefined): Chofer | undefined {
  const { datos } = useApp();
  return datos?.choferes.find((c) => c.id === id);
}
