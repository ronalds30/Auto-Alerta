// ============================================================================
//  AutoAlerta Web Dashboard - Configuracion
//  Editar SOLO la constante CLIENT_ID con el Web Client ID de Google Cloud.
// ============================================================================

window.AUTOALERTA_CONFIG = {
  // >>> PEGA AQUI TU OAUTH WEB CLIENT ID <<<
  // Formato: '1234567890-xxxxxxxxxxxxxxxxxxxxxxxxxxxx.apps.googleusercontent.com'
  CLIENT_ID: '856777328728-qnbm8rd92jtm2hqsa5f15226r60nrnf7.apps.googleusercontent.com',

  // Scope identico al que usa el APK -> comparte el mismo espacio de archivos en Drive.
  SCOPES: 'https://www.googleapis.com/auth/drive.file profile email',

  // Nombre de la carpeta y archivo en Drive (DEBE coincidir con services/config.ts del APK).
  FOLDER_NAME: 'AutoAlerta',
  FILE_NAME: 'datos.json',

  // Claves de localStorage
  STORAGE: {
    TOKEN: 'autoalerta.web.token',
    EXPIRES_AT: 'autoalerta.web.expiresAt',
    USER: 'autoalerta.web.user',
  },
};
