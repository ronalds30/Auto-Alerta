// ============================================================================
//  AutoAlerta Web - Lectura/Escritura en Google Drive (scope drive.file)
//  Compatible con el APK: misma carpeta "AutoAlerta" y archivo "datos.json".
// ============================================================================

(function () {
  const CFG = window.AUTOALERTA_CONFIG;
  const DRIVE_API = 'https://www.googleapis.com/drive/v3';
  const UPLOAD_API = 'https://www.googleapis.com/upload/drive/v3';

  let folderIdCache = null;
  let datosFileIdCache = null;

  function authHeaders() {
    const token = window.AutoAlertaAuth.getToken();
    if (!token) throw new Error('No hay sesion activa con Google');
    return { Authorization: `Bearer ${token}` };
  }

  async function buscarCarpetaRaiz() {
    if (folderIdCache) return folderIdCache;
    const q = `name='${CFG.FOLDER_NAME}' and mimeType='application/vnd.google-apps.folder' and trashed=false`;
    const resp = await fetch(
      `${DRIVE_API}/files?q=${encodeURIComponent(q)}&fields=files(id,name)`,
      { headers: authHeaders() }
    );
    if (!resp.ok) throw new Error(`Drive search fallo (${resp.status})`);
    const data = await resp.json();
    if (data.files && data.files.length > 0) {
      folderIdCache = data.files[0].id;
      return folderIdCache;
    }
    return null;
  }

  async function buscarFileDatos(folderId) {
    if (datosFileIdCache) return datosFileIdCache;
    const q = `'${folderId}' in parents and name='${CFG.FILE_NAME}' and trashed=false`;
    const resp = await fetch(
      `${DRIVE_API}/files?q=${encodeURIComponent(q)}&fields=files(id,name,modifiedTime)`,
      { headers: authHeaders() }
    );
    if (!resp.ok) throw new Error(`Drive search datos fallo (${resp.status})`);
    const data = await resp.json();
    if (data.files && data.files.length > 0) {
      datosFileIdCache = data.files[0].id;
      return datosFileIdCache;
    }
    return null;
  }

  async function cargarDatos() {
    const folderId = await buscarCarpetaRaiz();
    if (!folderId) {
      const err = new Error('CARPETA_NO_ENCONTRADA');
      err.code = 'CARPETA_NO_ENCONTRADA';
      throw err;
    }
    const fileId = await buscarFileDatos(folderId);
    if (!fileId) {
      const err = new Error('ARCHIVO_NO_ENCONTRADO');
      err.code = 'ARCHIVO_NO_ENCONTRADO';
      throw err;
    }
    const resp = await fetch(
      `${DRIVE_API}/files/${fileId}?alt=media`,
      { headers: authHeaders() }
    );
    if (!resp.ok) throw new Error(`Drive get datos fallo (${resp.status})`);
    return resp.json();
  }

  async function obtenerUrlCarpetaDrive() {
    const folderId = await buscarCarpetaRaiz();
    return folderId ? `https://drive.google.com/drive/folders/${folderId}` : null;
  }

  function resetCache() {
    folderIdCache = null;
    datosFileIdCache = null;
  }

  window.AutoAlertaDrive = {
    cargarDatos,
    obtenerUrlCarpetaDrive,
    resetCache,
  };
})();
