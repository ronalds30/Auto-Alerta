// ============================================================================
//  AutoAlerta Web - Autenticacion via Google Identity Services (GIS)
// ============================================================================

(function () {
  const CFG = window.AUTOALERTA_CONFIG;
  let tokenClient = null;
  let readyCallback = null;

  function getStored(key) {
    return localStorage.getItem(key);
  }
  function setStored(key, val) {
    localStorage.setItem(key, val);
  }
  function clearStored() {
    localStorage.removeItem(CFG.STORAGE.TOKEN);
    localStorage.removeItem(CFG.STORAGE.EXPIRES_AT);
    localStorage.removeItem(CFG.STORAGE.USER);
  }

  function isTokenVigente() {
    const expStr = getStored(CFG.STORAGE.EXPIRES_AT);
    if (!expStr) return false;
    const exp = parseInt(expStr, 10);
    if (!Number.isFinite(exp)) return false;
    return Date.now() + 60_000 < exp;
  }

  function getToken() {
    if (!isTokenVigente()) return null;
    return getStored(CFG.STORAGE.TOKEN);
  }

  function getUser() {
    const raw = getStored(CFG.STORAGE.USER);
    return raw ? JSON.parse(raw) : null;
  }

  async function fetchUserProfile(accessToken) {
    const resp = await fetch(
      'https://www.googleapis.com/oauth2/v3/userinfo',
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    if (!resp.ok) throw new Error('No se pudo obtener el perfil de Google');
    return resp.json();
  }

  function initTokenClient() {
    if (!window.google || !window.google.accounts || !window.google.accounts.oauth2) {
      console.error('[auth] Google Identity Services no esta cargado todavia');
      return false;
    }
    tokenClient = window.google.accounts.oauth2.initTokenClient({
      client_id: CFG.CLIENT_ID,
      scope: CFG.SCOPES,
      callback: async (resp) => {
        if (resp.error) {
          console.error('[auth] error en token client:', resp);
          window.dispatchEvent(new CustomEvent('autoalerta:auth-error', { detail: resp }));
          return;
        }
        const expiresInSec = resp.expires_in || 3600;
        const expiresAt = Date.now() + expiresInSec * 1000;
        setStored(CFG.STORAGE.TOKEN, resp.access_token);
        setStored(CFG.STORAGE.EXPIRES_AT, String(expiresAt));

        try {
          const profile = await fetchUserProfile(resp.access_token);
          const user = {
            nombre: profile.name || '',
            email: profile.email || '',
            picture: profile.picture || '',
          };
          setStored(CFG.STORAGE.USER, JSON.stringify(user));
          window.dispatchEvent(new CustomEvent('autoalerta:logged-in', { detail: user }));
        } catch (err) {
          console.error('[auth] error obteniendo perfil:', err);
        }
      },
    });
    return true;
  }

  function login() {
    if (CFG.CLIENT_ID.startsWith('REEMPLAZAR')) {
      alert(
        'OAuth no configurado.\n\n' +
        'Edita web/js/config.js y reemplaza CLIENT_ID con tu OAuth Web Client ID de Google Cloud Console.\n\n' +
        'Tambien debes agregar http://localhost:5500 y http://127.0.0.1:5500 como "Authorized JavaScript origins" en ese OAuth Client.'
      );
      return;
    }
    if (!tokenClient) {
      if (!initTokenClient()) return;
    }
    tokenClient.requestAccessToken({ prompt: '' });
  }

  function logout() {
    const token = getToken();
    if (token && window.google?.accounts?.oauth2) {
      window.google.accounts.oauth2.revoke(token, () => {});
    }
    clearStored();
    window.dispatchEvent(new CustomEvent('autoalerta:logged-out'));
  }

  function onReady(cb) {
    if (window.google?.accounts?.oauth2) {
      cb();
    } else {
      readyCallback = cb;
    }
  }

  window.onGoogleIdentityReady = function () {
    initTokenClient();
    if (readyCallback) readyCallback();
  };

  window.AutoAlertaAuth = {
    login,
    logout,
    getToken,
    getUser,
    isLoggedIn: () => isTokenVigente(),
    onReady,
  };
})();
