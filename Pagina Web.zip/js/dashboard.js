// ============================================================================
//  AutoAlerta Web Dashboard - Orquestacion, render, filtros, graficos y modal
// ============================================================================

(function () {
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  let datosCache = null;
  let alertasCache = [];

  const filtros = {
    autos: '',
    choferes: '',
    alertas: '',
    severidadAlertas: 'todas',
  };

  // ===========================================================================
  // Utilidades
  // ===========================================================================

  function parseFecha(iso) {
    if (!iso) return null;
    const d = new Date(iso);
    return isNaN(d.getTime()) ? null : d;
  }

  function diasEntre(fechaIso) {
    const f = parseFecha(fechaIso);
    if (!f) return null;
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    f.setHours(0, 0, 0, 0);
    return Math.floor((f.getTime() - hoy.getTime()) / 86400000);
  }

  function severidad(dias) {
    if (dias === null || dias === undefined) return 'sindata';
    if (dias < 0) return 'vencido';
    if (dias <= 15) return 'urgente';
    if (dias <= 45) return 'proximo';
    return 'aldia';
  }

  function fmtMoneda(n) {
    if (n === null || n === undefined || isNaN(n)) return 'B/. 0.00';
    return `B/. ${Number(n).toFixed(2)}`;
  }

  function fmtFecha(iso) {
    const d = parseFecha(iso);
    if (!d) return '-';
    return d.toLocaleDateString('es-PA', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  function iniciales(nombre, apellido) {
    const n = (nombre || '').trim().charAt(0).toUpperCase();
    const a = (apellido || '').trim().charAt(0).toUpperCase();
    return n + a || '?';
  }

  function escapeHTML(s) {
    if (s === null || s === undefined) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function debounce(fn, ms) {
    let t;
    return (...a) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...a), ms);
    };
  }

  function iconoTipo(tipo) {
    return {
      poliza: '🛡️',
      calcomania: '🏷️',
      revisado: '🔍',
      placa_metalica: '🔢',
      licencia: '🚦',
      cedula: '🪪',
      mantenimiento: '🔧',
      pieza: '🔩',
    }[tipo] || '⚠️';
  }

  // ===========================================================================
  // Calculo de alertas
  // ===========================================================================

  function alertasDeAuto(auto) {
    const out = [];
    const nombreEntidad = `${auto.marca || ''} ${auto.modelo || ''}`.trim() || 'Sin nombre';

    const docs = [
      { fecha: auto.polizaSeguro?.fechaVencimiento, titulo: 'Poliza de seguro', tipo: 'poliza' },
      { fecha: auto.calcomania?.fechaVencimiento, titulo: 'Calcomania', tipo: 'calcomania' },
      { fecha: auto.revisadoVehicular?.fechaProximoRevisado, titulo: 'Revisado vehicular', tipo: 'revisado' },
      { fecha: auto.placaMetalica?.fechaVencimiento, titulo: 'Placa metalica', tipo: 'placa_metalica' },
    ];

    for (const d of docs) {
      const dias = diasEntre(d.fecha);
      if (dias === null) continue;
      out.push({
        tipo: d.tipo, titulo: d.titulo, entidadId: auto.id, entidadTipo: 'auto',
        entidadNombre: nombreEntidad, fechaVencimiento: d.fecha,
        diasRestantes: dias, severidad: severidad(dias), icono: iconoTipo(d.tipo),
      });
    }

    for (const m of auto.mantenimientos || []) {
      const dias = diasEntre(m.proximaFecha);
      if (dias === null || m.completado) continue;
      out.push({
        tipo: 'mantenimiento', titulo: `Mantenimiento: ${m.tipo || 'tipo no especificado'}`,
        entidadId: auto.id, entidadTipo: 'auto', entidadNombre: nombreEntidad,
        fechaVencimiento: m.proximaFecha, diasRestantes: dias,
        severidad: severidad(dias), icono: '🔧',
      });
    }

    for (const p of auto.cambiosPiezas || []) {
      const dias = diasEntre(p.proximoCambioFecha);
      if (dias === null) continue;
      out.push({
        tipo: 'pieza', titulo: `Cambio de pieza: ${p.pieza || 'pieza no especificada'}`,
        entidadId: auto.id, entidadTipo: 'auto', entidadNombre: nombreEntidad,
        fechaVencimiento: p.proximoCambioFecha, diasRestantes: dias,
        severidad: severidad(dias), icono: '🔩',
      });
    }
    return out;
  }

  function alertasDeChofer(c) {
    const out = [];
    const nombre = `${c.nombre || ''} ${c.apellido || ''}`.trim() || 'Sin nombre';
    if (c.cedula?.fechaVencimiento) {
      const dias = diasEntre(c.cedula.fechaVencimiento);
      if (dias !== null) out.push({
        tipo: 'cedula', titulo: 'Cedula de identidad', entidadId: c.id, entidadTipo: 'chofer',
        entidadNombre: nombre, fechaVencimiento: c.cedula.fechaVencimiento,
        diasRestantes: dias, severidad: severidad(dias), icono: '🪪',
      });
    }
    if (c.licenciaConducir?.fechaVencimiento) {
      const dias = diasEntre(c.licenciaConducir.fechaVencimiento);
      if (dias !== null) out.push({
        tipo: 'licencia', titulo: 'Licencia de conducir', entidadId: c.id, entidadTipo: 'chofer',
        entidadNombre: nombre, fechaVencimiento: c.licenciaConducir.fechaVencimiento,
        diasRestantes: dias, severidad: severidad(dias), icono: '🚦',
      });
    }
    return out;
  }

  function calcularAlertas(datos) {
    const out = [];
    for (const a of datos.autos || []) out.push(...alertasDeAuto(a));
    for (const c of datos.choferes || []) out.push(...alertasDeChofer(c));
    out.sort((x, y) => x.diasRestantes - y.diasRestantes);
    return out;
  }

  // ===========================================================================
  // Calculo de gastos por mes y por categoria
  // ===========================================================================

  function calcularGastos(datos) {
    const autos = datos.autos || [];
    let totMant = 0, totPiezas = 0, totDocs = 0;
    const mensual = {};
    const labels = [];

    for (let i = 11; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      mensual[k] = 0;
      labels.push(d.toLocaleDateString('es-PA', { month: 'short' }));
    }

    const acumular = (iso, costo) => {
      if (!iso) return;
      const k = iso.slice(0, 7);
      if (k in mensual) mensual[k] += Number(costo) || 0;
    };

    for (const a of autos) {
      for (const m of a.mantenimientos || []) {
        const c = Number(m.costo) || 0;
        totMant += c;
        acumular(m.fechaRealizado, c);
      }
      for (const p of a.cambiosPiezas || []) {
        const c = Number(p.costo) || 0;
        totPiezas += c;
        acumular(p.fechaCambio, c);
      }
      if (a.polizaSeguro) {
        const c = Number(a.polizaSeguro.monto) || 0;
        totDocs += c;
        acumular(a.polizaSeguro.fechaInicio, c);
      }
      if (a.calcomania) {
        const c = Number(a.calcomania.costo) || 0;
        totDocs += c;
        acumular(a.calcomania.fechaPago, c);
      }
      if (a.revisadoVehicular) {
        const c = Number(a.revisadoVehicular.costo) || 0;
        totDocs += c;
        acumular(a.revisadoVehicular.fechaUltimoRevisado, c);
      }
      if (a.placaMetalica) {
        const c = Number(a.placaMetalica.costo) || 0;
        totDocs += c;
        acumular(a.placaMetalica.fechaEmision, c);
      }
    }

    return {
      mensual: Object.values(mensual),
      mensualLabels: labels,
      categorias: { Mantenimientos: totMant, Piezas: totPiezas, Documentos: totDocs },
      total: totMant + totPiezas + totDocs,
    };
  }

  // ===========================================================================
  // Render: User pill + greeting
  // ===========================================================================

  function renderUserPill() {
    const user = window.AutoAlertaAuth.getUser();
    const container = $('#user-pill-container');
    if (!user) { container.innerHTML = ''; return; }
    const pic = user.picture
      ? `<img src="${user.picture}" alt="" referrerpolicy="no-referrer">`
      : `<div class="chofer-avatar" style="width:36px;height:36px;font-size:1rem;">${iniciales(user.nombre, '')}</div>`;
    container.innerHTML = `
      <div class="user-pill">
        ${pic}
        <span class="user-name">${escapeHTML(user.nombre.split(' ')[0])}</span>
        <button class="logout-btn" id="logout-btn">Salir</button>
      </div>`;
    $('#logout-btn').addEventListener('click', () => window.AutoAlertaAuth.logout());
    $('#greeting-name').textContent = (user.nombre || '').split(' ')[0] || 'conductor';
    $('#print-user').textContent = user.email || '';
  }

  // ===========================================================================
  // Render: KPIs
  // ===========================================================================

  function renderKPIs(datos, alertas) {
    $('#kpi-autos').textContent = (datos.autos || []).length;
    $('#kpi-choferes').textContent = (datos.choferes || []).length;
    const vencidos = alertas.filter(a => a.severidad === 'vencido').length;
    const activas = alertas.filter(a => a.severidad !== 'aldia' && a.severidad !== 'sindata').length;
    $('#kpi-alertas').textContent = activas;
    $('#kpi-vencidos').textContent = vencidos;
    $('#count-autos').textContent = (datos.autos || []).length;
    $('#count-choferes').textContent = (datos.choferes || []).length;
    $('#count-alertas').textContent = alertas.filter(a => a.severidad !== 'aldia').length;
  }

  // ===========================================================================
  // Render: graficos SVG
  // ===========================================================================

  function renderGraficos(datos) {
    const g = calcularGastos(datos);
    renderBarChart(g.mensual, g.mensualLabels);
    renderDonut(g.categorias);
    $('#chart-mensual-total').textContent = `Total: ${fmtMoneda(g.total)}`;
  }

  function renderBarChart(values, labels) {
    const wrap = $('#chart-mensual');
    const W = wrap.clientWidth || 600;
    const H = 220;
    const padL = 36, padR = 12, padT = 16, padB = 32;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;
    const n = values.length;
    const max = Math.max(...values, 1);
    const barW = innerW / n;
    const gap = Math.max(2, barW * 0.18);
    const bw = barW - gap;

    // Yaxis ticks 0, max/2, max
    const ticks = [0, max / 2, max];

    let svg = `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" aria-label="Gastos por mes">`;

    // gridlines
    for (const t of ticks) {
      const y = padT + innerH - (t / max) * innerH;
      svg += `<line x1="${padL}" y1="${y}" x2="${W - padR}" y2="${y}" stroke="rgba(255,255,255,0.06)" stroke-dasharray="2 4"/>`;
      svg += `<text x="${padL - 6}" y="${y + 3}" font-size="9" fill="rgba(255,255,255,0.5)" text-anchor="end" font-family="DM Sans">${t.toFixed(0)}</text>`;
    }

    for (let i = 0; i < n; i++) {
      const v = values[i];
      const h = Math.max(2, (v / max) * innerH);
      const x = padL + i * barW + gap / 2;
      const y = padT + innerH - h;
      const color = v > 0 ? 'url(#barGrad)' : 'rgba(255,255,255,0.05)';
      svg += `<rect class="bar" x="${x}" y="${y}" width="${bw}" height="${h}" rx="3" fill="${color}">
                <title>${labels[i]}: ${fmtMoneda(v)}</title>
              </rect>`;
      if (v > 0) {
        svg += `<text x="${x + bw / 2}" y="${y - 4}" font-size="9" fill="rgba(255,255,255,0.7)" text-anchor="middle" font-family="DM Sans">${v.toFixed(0)}</text>`;
      }
      svg += `<text x="${x + bw / 2}" y="${H - 10}" font-size="10" fill="rgba(255,255,255,0.5)" text-anchor="middle" font-family="Rajdhani" font-weight="600">${escapeHTML(labels[i])}</text>`;
    }

    svg += `
      <defs>
        <linearGradient id="barGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#fb6d00" stop-opacity="1"/>
          <stop offset="100%" stop-color="#1565C0" stop-opacity="0.7"/>
        </linearGradient>
      </defs>
    </svg>`;

    wrap.innerHTML = svg;
  }

  function renderDonut(cats) {
    const wrap = $('#chart-donut');
    const legend = $('#chart-donut-legend');
    const entries = Object.entries(cats).filter(([, v]) => v > 0);
    const total = entries.reduce((s, [, v]) => s + v, 0);

    if (total === 0) {
      wrap.innerHTML = `
        <svg viewBox="0 0 180 180" xmlns="http://www.w3.org/2000/svg">
          <circle cx="90" cy="90" r="60" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="22"/>
          <text x="90" y="95" font-size="14" fill="rgba(255,255,255,0.5)" text-anchor="middle" font-family="Rajdhani">Sin gastos</text>
        </svg>`;
      legend.innerHTML = `<div class="legend-row"><span class="legend-label">Aun no hay gastos registrados</span></div>`;
      return;
    }

    const colors = ['var(--donut-1)', 'var(--donut-2)', 'var(--donut-3)', 'var(--donut-4)', 'var(--donut-5)'];
    const colorHex = ['#1565C0', '#FF6F00', '#f5b300', '#2E7D32', '#9c27b0'];
    const C = 2 * Math.PI * 60;
    let offset = 0;
    let svg = `<svg viewBox="0 0 180 180" xmlns="http://www.w3.org/2000/svg" aria-label="Distribucion de gastos">
                 <circle cx="90" cy="90" r="60" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="22"/>`;

    entries.forEach(([cat, v], i) => {
      const pct = v / total;
      const len = C * pct;
      svg += `<circle cx="90" cy="90" r="60" fill="none"
                stroke="${colorHex[i % colorHex.length]}"
                stroke-width="22"
                stroke-dasharray="${len} ${C - len}"
                stroke-dashoffset="${-offset}"
                transform="rotate(-90 90 90)">
                <title>${escapeHTML(cat)}: ${fmtMoneda(v)} (${(pct * 100).toFixed(1)}%)</title>
              </circle>`;
      offset += len;
    });

    svg += `
      <text x="90" y="84" font-size="11" fill="rgba(255,255,255,0.5)" text-anchor="middle" font-family="Rajdhani" font-weight="600" letter-spacing="1">TOTAL</text>
      <text x="90" y="104" font-size="18" fill="#FF6F00" text-anchor="middle" font-family="Bebas Neue" letter-spacing="1">${fmtMoneda(total).replace('B/. ', '')}</text>
    </svg>`;
    wrap.innerHTML = svg;

    legend.innerHTML = entries.map(([cat, v], i) => `
      <div class="legend-row">
        <span class="legend-dot" style="background:${colorHex[i % colorHex.length]}"></span>
        <span class="legend-label">${escapeHTML(cat)}</span>
        <span class="legend-value">${fmtMoneda(v)}</span>
      </div>
    `).join('');
  }

  // ===========================================================================
  // Render: Auto cards (con filtro)
  // ===========================================================================

  function autoCard(auto) {
    const docs = [
      { label: 'Poliza', fecha: auto.polizaSeguro?.fechaVencimiento },
      { label: 'Calcomania', fecha: auto.calcomania?.fechaVencimiento },
      { label: 'Revisado', fecha: auto.revisadoVehicular?.fechaProximoRevisado },
      { label: 'Placa met.', fecha: auto.placaMetalica?.fechaVencimiento },
    ];
    const chips = docs.map((d) => {
      const dias = diasEntre(d.fecha);
      const sev = severidad(dias);
      const subtxt = dias === null ? 'sin datos' : (dias < 0 ? `vencida hace ${-dias}d` : `en ${dias}d`);
      return `<div class="doc-chip ${sev}" title="${escapeHTML(d.label)}: ${subtxt}">${escapeHTML(d.label)} · ${subtxt}</div>`;
    }).join('');

    return `
      <div class="auto-card" data-auto-id="${escapeHTML(auto.id)}">
        <div class="auto-header">
          <div>
            <div class="auto-title">${escapeHTML(auto.marca || '')} ${escapeHTML(auto.modelo || '')}</div>
            <div class="auto-anio">${escapeHTML(String(auto.anio || ''))}</div>
          </div>
        </div>
        <div class="auto-placa">${escapeHTML(auto.placa || 'SIN PLACA')}</div>
        <div class="auto-meta">
          <div class="auto-meta-item">🎨 ${escapeHTML(auto.color || '—')}</div>
          <div class="auto-meta-item">📏 ${escapeHTML(String((auto.kilometrajeActual || 0).toLocaleString()))} km</div>
          ${auto.vin ? `<div class="auto-meta-item">🆔 ${escapeHTML(auto.vin)}</div>` : ''}
        </div>
        <div class="auto-docs">${chips}</div>
        <div class="auto-card-hint">Click para ver detalle →</div>
      </div>`;
  }

  function filtrarAutos(autos, q) {
    if (!q) return autos;
    const qq = q.toLowerCase().trim();
    return autos.filter((a) => {
      const txt = `${a.marca || ''} ${a.modelo || ''} ${a.placa || ''} ${a.vin || ''} ${a.color || ''} ${a.anio || ''}`.toLowerCase();
      return txt.includes(qq);
    });
  }

  function renderAutos() {
    const grid = $('#autos-grid');
    if (!datosCache) return;
    const autos = filtrarAutos(datosCache.autos || [], filtros.autos);
    if (autos.length === 0) {
      const msg = filtros.autos
        ? `Ningun auto coincide con "${escapeHTML(filtros.autos)}".`
        : 'Aun no tienes autos registrados. Agrega tu primer auto desde la app movil de AutoAlerta y aparecera aqui.';
      grid.innerHTML = `
        <div class="state-block" style="grid-column: 1/-1;">
          <div class="state-icon">🚗</div>
          <h3>${filtros.autos ? 'Sin resultados' : 'Aun no tienes autos registrados'}</h3>
          <p>${msg}</p>
        </div>`;
      return;
    }
    grid.innerHTML = autos.map(autoCard).join('');
    // Click handler
    grid.querySelectorAll('.auto-card').forEach((card) => {
      card.addEventListener('click', () => {
        const id = card.dataset.autoId;
        const auto = (datosCache.autos || []).find((x) => x.id === id);
        if (auto) abrirModalAuto(auto);
      });
    });
  }

  // ===========================================================================
  // Render: Choferes (con filtro)
  // ===========================================================================

  function choferCard(c) {
    return `
      <div class="chofer-card">
        <div class="chofer-avatar">${iniciales(c.nombre, c.apellido)}</div>
        <div class="chofer-info">
          <div class="chofer-name">${escapeHTML(c.nombre || '')} ${escapeHTML(c.apellido || '')}</div>
          <div class="chofer-meta">
            ${c.telefono ? `<span>📞 ${escapeHTML(c.telefono)}</span>` : ''}
            ${c.email ? `<span>📧 ${escapeHTML(c.email)}</span>` : ''}
            ${c.licenciaConducir?.fechaVencimiento ? `<span>🚦 Licencia vence ${fmtFecha(c.licenciaConducir.fechaVencimiento)}</span>` : ''}
          </div>
        </div>
      </div>`;
  }

  function filtrarChoferes(choferes, q) {
    if (!q) return choferes;
    const qq = q.toLowerCase().trim();
    return choferes.filter((c) => {
      const txt = `${c.nombre || ''} ${c.apellido || ''} ${c.telefono || ''} ${c.email || ''}`.toLowerCase();
      return txt.includes(qq);
    });
  }

  function renderChoferes() {
    const list = $('#chofer-list');
    if (!datosCache) return;
    const choferes = filtrarChoferes(datosCache.choferes || [], filtros.choferes);
    if (choferes.length === 0) {
      const msg = filtros.choferes
        ? `Ningun chofer coincide con "${escapeHTML(filtros.choferes)}".`
        : 'Aun no tienes choferes registrados. Agrega los choferes desde la app movil y apareceran aqui.';
      list.innerHTML = `
        <div class="state-block" style="grid-column: 1/-1;">
          <div class="state-icon">👤</div>
          <h3>${filtros.choferes ? 'Sin resultados' : 'Aun no tienes choferes registrados'}</h3>
          <p>${msg}</p>
        </div>`;
      return;
    }
    list.innerHTML = choferes.map(choferCard).join('');
  }

  // ===========================================================================
  // Render: Alertas (con filtros)
  // ===========================================================================

  function alertaItem(a) {
    const dias = a.diasRestantes;
    const diasTxt = dias < 0 ? `${-dias}` : `${dias}`;
    const diasLabel = dias < 0 ? 'vencido' : 'restantes';
    return `
      <div class="alerta-item severidad-${a.severidad}">
        <div class="alerta-icon">${a.icono}</div>
        <div class="alerta-body">
          <div class="alerta-title">${escapeHTML(a.titulo)}</div>
          <div class="alerta-sub">${escapeHTML(a.entidadNombre)} · vence ${fmtFecha(a.fechaVencimiento)}</div>
        </div>
        <div class="alerta-dias">${diasTxt}<span class="unit">${diasLabel}</span></div>
      </div>`;
  }

  function filtrarAlertas(alertas) {
    let out = alertas.filter(a => a.severidad !== 'aldia' && a.severidad !== 'sindata');
    if (filtros.severidadAlertas !== 'todas') {
      out = out.filter(a => a.severidad === filtros.severidadAlertas);
    }
    if (filtros.alertas) {
      const qq = filtros.alertas.toLowerCase().trim();
      out = out.filter(a => `${a.titulo} ${a.entidadNombre} ${a.tipo}`.toLowerCase().includes(qq));
    }
    return out;
  }

  function renderAlertas() {
    const lista = $('#alertas-list');
    const activas = filtrarAlertas(alertasCache);
    if (activas.length === 0) {
      const hayFiltros = filtros.severidadAlertas !== 'todas' || filtros.alertas;
      lista.innerHTML = `
        <div class="state-block">
          <div class="state-icon">${hayFiltros ? '🔎' : '✅'}</div>
          <h3>${hayFiltros ? 'Sin resultados' : 'Todo al dia'}</h3>
          <p>${hayFiltros ? 'Ninguna alerta coincide con el filtro.' : 'No hay vencimientos proximos en los proximos 45 dias. Buen trabajo.'}</p>
        </div>`;
    } else {
      lista.innerHTML = activas.map(alertaItem).join('');
    }
    // Preview en Resumen (siempre top 5 sin filtros)
    const preview = $('#alertas-preview');
    const top = alertasCache
      .filter(a => a.severidad !== 'aldia' && a.severidad !== 'sindata')
      .slice(0, 5);
    if (top.length === 0) {
      preview.innerHTML = `<div class="state-block"><div class="state-icon">✅</div><h3>Sin vencimientos proximos</h3></div>`;
    } else {
      preview.innerHTML = top.map(alertaItem).join('');
    }
  }

  // ===========================================================================
  // Modal detalle de auto
  // ===========================================================================

  function abrirModalAuto(auto) {
    const dlg = $('#auto-modal');
    const body = $('#auto-modal-body');

    const totalMant = (auto.mantenimientos || []).reduce((s, m) => s + (Number(m.costo) || 0), 0);
    const totalPiezas = (auto.cambiosPiezas || []).reduce((s, p) => s + (Number(p.costo) || 0), 0);
    const totalDocs =
      (Number(auto.polizaSeguro?.monto) || 0) +
      (Number(auto.calcomania?.costo) || 0) +
      (Number(auto.revisadoVehicular?.costo) || 0) +
      (Number(auto.placaMetalica?.costo) || 0);
    const grandTotal = totalMant + totalPiezas + totalDocs;

    const docs = [
      { label: 'Poliza', obj: auto.polizaSeguro, dateField: 'fechaVencimiento', amount: 'monto', extra: auto.polizaSeguro?.aseguradora },
      { label: 'Calcomania', obj: auto.calcomania, dateField: 'fechaVencimiento', amount: 'costo', extra: auto.calcomania?.mes },
      { label: 'Revisado', obj: auto.revisadoVehicular, dateField: 'fechaProximoRevisado', amount: 'costo', extra: auto.revisadoVehicular?.taller },
      { label: 'Placa metalica', obj: auto.placaMetalica, dateField: 'fechaVencimiento', amount: 'costo', extra: auto.placaMetalica?.numero },
    ];

    const docsHTML = docs.map((d) => {
      if (!d.obj) {
        return `<div class="modal-doc-row">
                  <div class="doc-label">${escapeHTML(d.label)}</div>
                  <div class="doc-value">Sin registro</div>
                  <div class="doc-value">—</div>
                  <div class="item-cost">—</div>
                </div>`;
      }
      const dias = diasEntre(d.obj[d.dateField]);
      const sev = severidad(dias);
      const subtxt = dias === null ? 'sin fecha' : (dias < 0 ? `vencida hace ${-dias}d` : `en ${dias}d`);
      const costo = Number(d.obj[d.amount]) || 0;
      return `
        <div class="modal-doc-row">
          <div class="doc-label">${escapeHTML(d.label)}</div>
          <div class="doc-value">${d.extra ? escapeHTML(d.extra) : '—'}</div>
          <div class="doc-value">
            <span class="doc-chip ${sev}" style="display:inline-block">${subtxt}</span><br>
            <small>${fmtFecha(d.obj[d.dateField])}</small>
          </div>
          <div class="item-cost" style="font-family: var(--font-display); color: var(--orange-accent); font-size: 1.1rem;">${fmtMoneda(costo)}</div>
        </div>`;
    }).join('');

    const mants = (auto.mantenimientos || []).slice().sort((a, b) => {
      return new Date(b.fechaRealizado || 0) - new Date(a.fechaRealizado || 0);
    });
    const mantsHTML = mants.length === 0 ? `<p style="color: var(--text-secondary); padding: 8px 0;">Sin mantenimientos registrados.</p>` : mants.map((m) => `
      <div class="modal-history-item">
        <div class="item-info">
          <div class="item-title">🔧 ${escapeHTML(m.tipo || 'Mantenimiento')}</div>
          <div class="item-sub">${fmtFecha(m.fechaRealizado)} · ${escapeHTML(m.taller || 'sin taller')} · KM ${(m.kilometrajeRealizado || 0).toLocaleString()}</div>
        </div>
        <div class="item-cost">${fmtMoneda(m.costo)}</div>
      </div>
    `).join('');

    const piezas = (auto.cambiosPiezas || []).slice().sort((a, b) => {
      return new Date(b.fechaCambio || 0) - new Date(a.fechaCambio || 0);
    });
    const piezasHTML = piezas.length === 0 ? `<p style="color: var(--text-secondary); padding: 8px 0;">Sin cambios de piezas registrados.</p>` : piezas.map((p) => `
      <div class="modal-history-item">
        <div class="item-info">
          <div class="item-title">🔩 ${escapeHTML(p.pieza || 'Pieza')} ${p.marca ? `· ${escapeHTML(p.marca)}` : ''}</div>
          <div class="item-sub">${fmtFecha(p.fechaCambio)} · ${escapeHTML(p.taller || 'sin taller')} · KM ${(p.kilometrajeCambio || 0).toLocaleString()}</div>
        </div>
        <div class="item-cost">${fmtMoneda(p.costo)}</div>
      </div>
    `).join('');

    body.innerHTML = `
      <button class="modal-close" id="modal-close-btn" aria-label="Cerrar">✕</button>
      <div class="modal-title">${escapeHTML(auto.marca || '')} ${escapeHTML(auto.modelo || '')}</div>
      <div class="modal-subtitle">${escapeHTML(String(auto.anio || ''))} · Placa <strong>${escapeHTML(auto.placa || 'SIN PLACA')}</strong></div>

      <div class="modal-section">
        <h4>Datos del vehiculo</h4>
        <div class="modal-grid-2">
          <div class="modal-field"><div class="label">Color</div><div class="value">${escapeHTML(auto.color || '—')}</div></div>
          <div class="modal-field"><div class="label">VIN</div><div class="value">${escapeHTML(auto.vin || '—')}</div></div>
          <div class="modal-field"><div class="label">Kilometraje actual</div><div class="value">${(auto.kilometrajeActual || 0).toLocaleString()} km</div></div>
          <div class="modal-field"><div class="label">Registro unico</div><div class="value">${escapeHTML(auto.registroUnico?.numero || '—')}</div></div>
        </div>
      </div>

      <div class="modal-section">
        <h4>Documentos</h4>
        ${docsHTML}
      </div>

      <div class="modal-section">
        <h4>Historial de mantenimientos (${mants.length})</h4>
        ${mantsHTML}
      </div>

      <div class="modal-section">
        <h4>Historial de cambios de piezas (${piezas.length})</h4>
        ${piezasHTML}
      </div>

      <div class="modal-totales">
        <div class="total-item"><div class="total-label">Mantenimientos</div><div class="total-val">${fmtMoneda(totalMant)}</div></div>
        <div class="total-item"><div class="total-label">Piezas</div><div class="total-val">${fmtMoneda(totalPiezas)}</div></div>
        <div class="total-item"><div class="total-label">Documentos</div><div class="total-val">${fmtMoneda(totalDocs)}</div></div>
        <div class="total-item"><div class="total-label">TOTAL</div><div class="total-val grand">${fmtMoneda(grandTotal)}</div></div>
      </div>
    `;

    if (typeof dlg.showModal === 'function') {
      dlg.showModal();
    } else {
      dlg.setAttribute('open', '');
    }
    $('#modal-close-btn').addEventListener('click', () => dlg.close());
    dlg.addEventListener('click', (e) => {
      if (e.target === dlg) dlg.close();
    }, { once: true });
  }

  // ===========================================================================
  // Estados
  // ===========================================================================

  function setEstado(estado) {
    $('#state-loading').style.display = estado === 'loading' ? 'block' : 'none';
    $('#state-empty').style.display = estado === 'empty' ? 'block' : 'none';
    $('#state-error').style.display = estado === 'error' ? 'block' : 'none';
    const tabs = $('.dashboard-tabs');
    const sections = $$('.tab-section');
    if (estado === 'ready') {
      tabs.style.display = '';
      sections.forEach((s) => { s.style.display = ''; });
    } else {
      tabs.style.display = 'none';
      sections.forEach((s) => { s.style.display = 'none'; });
    }
  }

  function mostrarToast(msg, tipo = 'info') {
    const el = document.createElement('div');
    el.className = `toast ${tipo}`;
    el.textContent = msg;
    $('#toast-container').appendChild(el);
    setTimeout(() => el.remove(), 5000);
  }

  // ===========================================================================
  // Carga principal
  // ===========================================================================

  async function cargarYRender() {
    setEstado('loading');
    try {
      const datos = await window.AutoAlertaDrive.cargarDatos();
      datosCache = datos;
      alertasCache = calcularAlertas(datos);

      renderKPIs(datos, alertasCache);
      renderGraficos(datos);
      renderAutos();
      renderChoferes();
      renderAlertas();

      const url = await window.AutoAlertaDrive.obtenerUrlCarpetaDrive();
      if (url) {
        const link = $('#drive-link');
        link.href = url;
        link.style.display = 'inline-flex';
      }

      setEstado('ready');
    } catch (err) {
      console.error('[dashboard] error cargando datos:', err);
      if (err.code === 'CARPETA_NO_ENCONTRADA' || err.code === 'ARCHIVO_NO_ENCONTRADO') {
        setEstado('empty');
      } else {
        setEstado('error');
        $('#state-error-msg').textContent = err.message || 'Error desconocido al conectar con Drive';
      }
    }
  }

  // ===========================================================================
  // UI: tabs, filtros, print
  // ===========================================================================

  function initTabs() {
    $$('.tab-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        $$('.tab-btn').forEach((b) => b.classList.toggle('active', b === btn));
        $$('.tab-section').forEach((s) => {
          s.classList.toggle('active', s.dataset.tabContent === tab);
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });
  }

  function initFiltros() {
    const sAutos = $('#search-autos');
    const sChof = $('#search-choferes');
    const sAle = $('#search-alertas');

    sAutos.addEventListener('input', debounce((e) => {
      filtros.autos = e.target.value;
      renderAutos();
    }, 200));

    sChof.addEventListener('input', debounce((e) => {
      filtros.choferes = e.target.value;
      renderChoferes();
    }, 200));

    sAle.addEventListener('input', debounce((e) => {
      filtros.alertas = e.target.value;
      renderAlertas();
    }, 200));

    $$('.filter-chip').forEach((chip) => {
      chip.addEventListener('click', () => {
        filtros.severidadAlertas = chip.dataset.severidad;
        $$('.filter-chip').forEach((c) => c.classList.toggle('active', c === chip));
        renderAlertas();
      });
    });
  }

  function initPrint() {
    $('#print-btn').addEventListener('click', () => {
      $('#print-date').textContent = new Date().toLocaleString('es-PA');
      window.print();
    });
  }

  // ===========================================================================
  // Bootstrap
  // ===========================================================================

  function mostrarLogin() {
    $('#login-overlay').style.display = 'flex';
    $('#dashboard-content').style.display = 'none';
  }

  function mostrarDashboard() {
    $('#login-overlay').style.display = 'none';
    $('#dashboard-content').style.display = 'block';
    renderUserPill();
    cargarYRender();
  }

  function init() {
    initTabs();
    initFiltros();
    initPrint();

    $('#login-btn').addEventListener('click', () => window.AutoAlertaAuth.login());
    $('#retry-btn').addEventListener('click', () => {
      window.AutoAlertaDrive.resetCache();
      cargarYRender();
    });

    window.addEventListener('autoalerta:logged-in', () => {
      mostrarDashboard();
      mostrarToast('Sesion iniciada correctamente', 'success');
    });
    window.addEventListener('autoalerta:logged-out', () => {
      window.AutoAlertaDrive.resetCache();
      mostrarLogin();
    });
    window.addEventListener('autoalerta:auth-error', (e) => {
      console.error('[dashboard] auth error', e.detail);
      mostrarToast('Error de autenticacion: ' + (e.detail?.error || 'desconocido'), 'error');
    });

    // ESC cierra el modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const dlg = $('#auto-modal');
        if (dlg && dlg.open) dlg.close();
      }
    });

    if (window.AutoAlertaAuth.isLoggedIn()) mostrarDashboard();
    else mostrarLogin();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
